﻿namespace LcDevPack_TeamDamonA
{
    internal class cAnimFile
    {
        public cAnimation[] Animation { get; set; }

        public cAnimHeader Header { get; set; }
    }
}
