﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.pwBoneIndex
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public struct pwBoneIndex
    {
        public byte A;
        public byte B;
        public byte C;
        public byte D;

        public pwBoneIndex(byte A, byte B, byte C, byte D)
        {
            this.A = A;
            this.B = B;
            this.C = C;
            this.D = D;
        }
    }
}
