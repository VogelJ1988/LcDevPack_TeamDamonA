﻿namespace LcDevPack_TeamDamonA
{
    partial class LangSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LangSelect));
            this.GbLangSelect = new System.Windows.Forms.GroupBox();
            this.BtnSave = new System.Windows.Forms.Button();
            this.RbMEX = new System.Windows.Forms.RadioButton();
            this.RbBRA = new System.Windows.Forms.RadioButton();
            this.RbESP = new System.Windows.Forms.RadioButton();
            this.RbPOL = new System.Windows.Forms.RadioButton();
            this.RbTHA = new System.Windows.Forms.RadioButton();
            this.RbRUS = new System.Windows.Forms.RadioButton();
            this.RbITA = new System.Windows.Forms.RadioButton();
            this.RbFRA = new System.Windows.Forms.RadioButton();
            this.RbGER = new System.Windows.Forms.RadioButton();
            this.RbUSA = new System.Windows.Forms.RadioButton();
            this.GbLangSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // GbLangSelect
            // 
            this.GbLangSelect.Controls.Add(this.BtnSave);
            this.GbLangSelect.Controls.Add(this.RbMEX);
            this.GbLangSelect.Controls.Add(this.RbBRA);
            this.GbLangSelect.Controls.Add(this.RbESP);
            this.GbLangSelect.Controls.Add(this.RbPOL);
            this.GbLangSelect.Controls.Add(this.RbTHA);
            this.GbLangSelect.Controls.Add(this.RbRUS);
            this.GbLangSelect.Controls.Add(this.RbITA);
            this.GbLangSelect.Controls.Add(this.RbFRA);
            this.GbLangSelect.Controls.Add(this.RbGER);
            this.GbLangSelect.Controls.Add(this.RbUSA);
            this.GbLangSelect.Location = new System.Drawing.Point(7, 12);
            this.GbLangSelect.Name = "GbLangSelect";
            this.GbLangSelect.Size = new System.Drawing.Size(369, 77);
            this.GbLangSelect.TabIndex = 0;
            this.GbLangSelect.TabStop = false;
            this.GbLangSelect.Text = "Language";
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(318, 19);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(45, 52);
            this.BtnSave.TabIndex = 10;
            this.BtnSave.Text = "Save";
            this.BtnSave.UseVisualStyleBackColor = true;
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // RbMEX
            // 
            this.RbMEX.AutoSize = true;
            this.RbMEX.Location = new System.Drawing.Point(264, 54);
            this.RbMEX.Name = "RbMEX";
            this.RbMEX.Size = new System.Drawing.Size(48, 17);
            this.RbMEX.TabIndex = 9;
            this.RbMEX.Text = "MEX";
            this.RbMEX.UseVisualStyleBackColor = true;
            // 
            // RbBRA
            // 
            this.RbBRA.AutoSize = true;
            this.RbBRA.Location = new System.Drawing.Point(264, 20);
            this.RbBRA.Name = "RbBRA";
            this.RbBRA.Size = new System.Drawing.Size(47, 17);
            this.RbBRA.TabIndex = 8;
            this.RbBRA.Text = "BRA";
            this.RbBRA.UseVisualStyleBackColor = true;
            // 
            // RbESP
            // 
            this.RbESP.AutoSize = true;
            this.RbESP.Location = new System.Drawing.Point(204, 54);
            this.RbESP.Name = "RbESP";
            this.RbESP.Size = new System.Drawing.Size(46, 17);
            this.RbESP.TabIndex = 7;
            this.RbESP.Text = "ESP";
            this.RbESP.UseVisualStyleBackColor = true;
            // 
            // RbPOL
            // 
            this.RbPOL.AutoSize = true;
            this.RbPOL.Location = new System.Drawing.Point(204, 20);
            this.RbPOL.Name = "RbPOL";
            this.RbPOL.Size = new System.Drawing.Size(46, 17);
            this.RbPOL.TabIndex = 6;
            this.RbPOL.Text = "POL";
            this.RbPOL.UseVisualStyleBackColor = true;
            // 
            // RbTHA
            // 
            this.RbTHA.AutoSize = true;
            this.RbTHA.Location = new System.Drawing.Point(149, 54);
            this.RbTHA.Name = "RbTHA";
            this.RbTHA.Size = new System.Drawing.Size(47, 17);
            this.RbTHA.TabIndex = 5;
            this.RbTHA.Text = "THA";
            this.RbTHA.UseVisualStyleBackColor = true;
            // 
            // RbRUS
            // 
            this.RbRUS.AutoSize = true;
            this.RbRUS.Location = new System.Drawing.Point(149, 20);
            this.RbRUS.Name = "RbRUS";
            this.RbRUS.Size = new System.Drawing.Size(48, 17);
            this.RbRUS.TabIndex = 4;
            this.RbRUS.Text = "RUS";
            this.RbRUS.UseVisualStyleBackColor = true;
            // 
            // RbITA
            // 
            this.RbITA.AutoSize = true;
            this.RbITA.Location = new System.Drawing.Point(84, 54);
            this.RbITA.Name = "RbITA";
            this.RbITA.Size = new System.Drawing.Size(42, 17);
            this.RbITA.TabIndex = 3;
            this.RbITA.Text = "ITA";
            this.RbITA.UseVisualStyleBackColor = true;
            // 
            // RbFRA
            // 
            this.RbFRA.AutoSize = true;
            this.RbFRA.Location = new System.Drawing.Point(84, 20);
            this.RbFRA.Name = "RbFRA";
            this.RbFRA.Size = new System.Drawing.Size(46, 17);
            this.RbFRA.TabIndex = 2;
            this.RbFRA.Text = "FRA";
            this.RbFRA.UseVisualStyleBackColor = true;
            // 
            // RbGER
            // 
            this.RbGER.AutoSize = true;
            this.RbGER.Location = new System.Drawing.Point(20, 54);
            this.RbGER.Name = "RbGER";
            this.RbGER.Size = new System.Drawing.Size(48, 17);
            this.RbGER.TabIndex = 1;
            this.RbGER.Text = "GER";
            this.RbGER.UseVisualStyleBackColor = true;
            // 
            // RbUSA
            // 
            this.RbUSA.AutoSize = true;
            this.RbUSA.Location = new System.Drawing.Point(20, 20);
            this.RbUSA.Name = "RbUSA";
            this.RbUSA.Size = new System.Drawing.Size(47, 17);
            this.RbUSA.TabIndex = 0;
            this.RbUSA.Text = "USA";
            this.RbUSA.UseVisualStyleBackColor = true;
            // 
            // LangSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 101);
            this.Controls.Add(this.GbLangSelect);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LangSelect";
            this.Text = "LangSelect";
            this.Load += new System.EventHandler(this.LangSelect_Load);
            this.GbLangSelect.ResumeLayout(false);
            this.GbLangSelect.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GbLangSelect;
        private System.Windows.Forms.Button BtnSave;
        private System.Windows.Forms.RadioButton RbMEX;
        private System.Windows.Forms.RadioButton RbBRA;
        private System.Windows.Forms.RadioButton RbESP;
        private System.Windows.Forms.RadioButton RbPOL;
        private System.Windows.Forms.RadioButton RbTHA;
        private System.Windows.Forms.RadioButton RbRUS;
        private System.Windows.Forms.RadioButton RbITA;
        private System.Windows.Forms.RadioButton RbFRA;
        private System.Windows.Forms.RadioButton RbGER;
        private System.Windows.Forms.RadioButton RbUSA;
    }
}