﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.tMeshShaderInfo
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public class tMeshShaderInfo
    {
        public uint cParam1 { get; set; }

        public uint cParam2 { get; set; }

        public uint cParamFloats { get; set; }

        public uint cTextureUnits { get; set; }
    }
}
