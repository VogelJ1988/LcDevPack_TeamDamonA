﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.tHeader
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public class tHeader
    {
        public int AnimOffset { get; set; }

        public uint Bits { get; set; }

        public byte[] DataChunk { get; set; }

        public string Format { get; set; }

        public uint Height { get; set; }

        public uint MipMap { get; set; }

        public uint Shift { get; set; }

        public uint Unknown { get; set; }

        public int Version { get; set; }

        public byte[] VersionChunk { get; set; }

        public uint Width { get; set; }
    }
}
