﻿using System.Windows.Forms;

namespace LcDevPack_TeamDamonA.Tools
{
    public partial class Lacaball_Editor : Form
    {
        public Lacaball_Editor()
        {
            InitializeComponent();
        }
    }
}
