﻿using System.Windows.Forms;

namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.SetItem
{
    public partial class SetItem : Form
    {
        public SetItem()
        {
            InitializeComponent();
        }
    }
}
