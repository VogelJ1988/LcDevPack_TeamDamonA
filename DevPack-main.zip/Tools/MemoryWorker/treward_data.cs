﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.Tools.MemoryWorker.treward_data
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA.Tools.MemoryWorker
{
    public class treward_data
    {
        public int PrimaryKey;
        public int RewardID;
        public int Type;
        public int ItemID;
        public int Value1;
        public int Value2;
        public int Value3;
        public int JobFlag;
        public int MinLevel;
        public int MaxLevel;
        public int Prob;
    }
}
