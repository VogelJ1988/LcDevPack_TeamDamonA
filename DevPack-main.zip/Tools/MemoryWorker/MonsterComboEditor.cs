﻿using System;
using System.Windows.Forms;

namespace LcDevPack_TeamDamonA.Tools.MemoryWorker
{
    public partial class MonsterComboEditor : Form
    {
        public MonsterComboEditor()
        {
            InitializeComponent();
        }

        private void CbEnable_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
