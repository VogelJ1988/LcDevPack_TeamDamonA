﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.Item
{
    partial class ItemAll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemnameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hTMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertQueryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateQueryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iconViewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemFlagBuilderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mySQLConnectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEThisRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNSERTThisRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configConnectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.massActionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNSERTALLNotExistingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEINSERTThisRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gETALLFromDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateAllNamesToDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateAllFlagsToDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateAllPicsToDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateAllNamesInDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.getRecordsFromOtherFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateAllPricesInDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getPhpItemlistToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeAllIconsAbove9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeAllIconsAbove14ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getAllFlagsFromOtherFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getIconsFromOtherFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.btnPercent2Add = new System.Windows.Forms.Button();
            this.btnPercent1Add = new System.Windows.Forms.Button();
            this.btnPercentAdd = new System.Windows.Forms.Button();
            this.TbPercent2 = new System.Windows.Forms.TextBox();
            this.TbPercent1 = new System.Windows.Forms.TextBox();
            this.TbPercent = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.t_Num4 = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.t_Num0 = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.t_Num1 = new System.Windows.Forms.TextBox();
            this.t_Num3 = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.t_Num2 = new System.Windows.Forms.TextBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.t_quest_tigger = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.t_quest_tigger_count = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.label92 = new System.Windows.Forms.Label();
            this.t_rvr_Grade = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.t_rvr_Value = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.t_SMC = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.t_Description = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.t_ItemName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.t_ItemID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.t_Icon = new System.Windows.Forms.PictureBox();
            this.t_iconpick = new System.Windows.Forms.LinkLabel();
            this.t_IconColumn = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.t_IconRow = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.t_IconID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.t_EffectDamage = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.t_EffectAttack = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.t_EffectNormal = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.t_Set5 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.t_Set4 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.t_Set3 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.t_Set2 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.t_Set1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.t_Level2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.t_Price = new System.Windows.Forms.TextBox();
            this.t_Weight = new System.Windows.Forms.TextBox();
            this.t_Level = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.t_RareOptionRate = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.t_RareOptionID = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox_class8 = new System.Windows.Forms.CheckBox();
            this.checkBox_class7 = new System.Windows.Forms.CheckBox();
            this.checkBox_class6 = new System.Windows.Forms.CheckBox();
            this.checkBox_class5 = new System.Windows.Forms.CheckBox();
            this.checkBox_class4 = new System.Windows.Forms.CheckBox();
            this.checkBox_class3 = new System.Windows.Forms.CheckBox();
            this.checkBox_class2 = new System.Windows.Forms.CheckBox();
            this.checkBox_class1 = new System.Windows.Forms.CheckBox();
            this.checkBox_class0 = new System.Windows.Forms.CheckBox();
            this.t_maxuse = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.t_Flag = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.t_WearingPosCombo = new System.Windows.Forms.ComboBox();
            this.t_WearingPos = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.t_Class = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.t_SubTypeCombo = new System.Windows.Forms.ComboBox();
            this.t_SubType = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.t_TypeCombo = new System.Windows.Forms.ComboBox();
            this.t_Type = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CraftGrid = new System.Windows.Forms.DataGridView();
            this.ItemIcon = new System.Windows.Forms.DataGridViewImageColumn();
            this.ItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.t_CraftItemSearch10 = new System.Windows.Forms.Button();
            this.t_CraftItemAmount10 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID10 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount9 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID9 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount8 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID8 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount7 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID7 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount6 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID6 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount5 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID5 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount4 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID4 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount3 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID3 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount2 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID2 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.t_CraftItemAmount1 = new System.Windows.Forms.TextBox();
            this.t_CraftItemID1 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.t_CraftItemSearch9 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch8 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch7 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch6 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch5 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch4 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch3 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch2 = new System.Windows.Forms.Button();
            this.t_CraftItemSearch1 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.t_CraftSkill2Level = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.t_CraftSkill1Level = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.t_CraftSkill2ID = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.t_CraftSkill1ID = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btnRareSearch9 = new System.Windows.Forms.Button();
            this.tbRareOpt9 = new System.Windows.Forms.TextBox();
            this.tbRareChance9 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.btnRareSearch8 = new System.Windows.Forms.Button();
            this.tbRareOpt8 = new System.Windows.Forms.TextBox();
            this.tbRareChance8 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.btnRareSearch7 = new System.Windows.Forms.Button();
            this.tbRareOpt7 = new System.Windows.Forms.TextBox();
            this.tbRareChance7 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.btnRareSearch6 = new System.Windows.Forms.Button();
            this.tbRareOpt6 = new System.Windows.Forms.TextBox();
            this.tbRareChance6 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.btnRareSearch5 = new System.Windows.Forms.Button();
            this.tbRareOpt5 = new System.Windows.Forms.TextBox();
            this.tbRareChance5 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.btnRareSearch4 = new System.Windows.Forms.Button();
            this.tbRareOpt4 = new System.Windows.Forms.TextBox();
            this.tbRareChance4 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.btnRareSearch3 = new System.Windows.Forms.Button();
            this.tbRareOpt3 = new System.Windows.Forms.TextBox();
            this.tbRareChance3 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.btnRareSearch2 = new System.Windows.Forms.Button();
            this.tbRareOpt2 = new System.Windows.Forms.TextBox();
            this.tbRareChance2 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.btnRareSearch1 = new System.Windows.Forms.Button();
            this.tbRareOpt1 = new System.Windows.Forms.TextBox();
            this.tbRareChance1 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.btnRareSearch0 = new System.Windows.Forms.Button();
            this.tbRareOpt0 = new System.Windows.Forms.TextBox();
            this.tbRareChance0 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRareDbPut = new System.Windows.Forms.Button();
            this.btnRareDbGet = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnSearchSkill3 = new System.Windows.Forms.Button();
            this.btnSearchSkill2 = new System.Windows.Forms.Button();
            this.btnSearchSkill1 = new System.Windows.Forms.Button();
            this.tbCB1 = new System.Windows.Forms.TextBox();
            this.tbCB2 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.tbSkillLevel3 = new System.Windows.Forms.TextBox();
            this.tbSkillID3 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.tbSkillLevel2 = new System.Windows.Forms.TextBox();
            this.tbSkillID2 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.tbSkillLevel1 = new System.Windows.Forms.TextBox();
            this.tbSkillID1 = new System.Windows.Forms.TextBox();
            this.tbSealID6 = new System.Windows.Forms.TextBox();
            this.cbSealLevel6 = new System.Windows.Forms.ComboBox();
            this.tbSealLevel6 = new System.Windows.Forms.TextBox();
            this.cbSealID6 = new System.Windows.Forms.ComboBox();
            this.tbSealID5 = new System.Windows.Forms.TextBox();
            this.cbSealLevel5 = new System.Windows.Forms.ComboBox();
            this.tbSealLevel5 = new System.Windows.Forms.TextBox();
            this.cbSealID5 = new System.Windows.Forms.ComboBox();
            this.tbSealID4 = new System.Windows.Forms.TextBox();
            this.cbSealLevel4 = new System.Windows.Forms.ComboBox();
            this.tbSealLevel4 = new System.Windows.Forms.TextBox();
            this.cbSealID4 = new System.Windows.Forms.ComboBox();
            this.tbSealID3 = new System.Windows.Forms.TextBox();
            this.cbSealLevel3 = new System.Windows.Forms.ComboBox();
            this.tbSealLevel3 = new System.Windows.Forms.TextBox();
            this.cbSealID3 = new System.Windows.Forms.ComboBox();
            this.tbSealID2 = new System.Windows.Forms.TextBox();
            this.cbSealLevel2 = new System.Windows.Forms.ComboBox();
            this.tbSealLevel2 = new System.Windows.Forms.TextBox();
            this.cbSealID2 = new System.Windows.Forms.ComboBox();
            this.tbSealID1 = new System.Windows.Forms.TextBox();
            this.cbSealLevel1 = new System.Windows.Forms.ComboBox();
            this.tbSealLevel1 = new System.Windows.Forms.TextBox();
            this.cbSealID1 = new System.Windows.Forms.ComboBox();
            this.pbSkill3Icon = new System.Windows.Forms.PictureBox();
            this.pbSkill2Icon = new System.Windows.Forms.PictureBox();
            this.pbSkill1Icon = new System.Windows.Forms.PictureBox();
            this.lblCurDataPurple = new System.Windows.Forms.Label();
            this.btnPurplePut = new System.Windows.Forms.Button();
            this.btnPurpleGet = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chk3D = new System.Windows.Forms.CheckBox();
            this.slideLeftRight = new System.Windows.Forms.TrackBar();
            this.slideUpDown = new System.Windows.Forms.TrackBar();
            this.slideZoom = new System.Windows.Forms.TrackBar();
            this.panel3DView = new System.Windows.Forms.Panel();
            this.ModPanel = new System.Windows.Forms.Panel();
            this.chkDbUpdate = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label29 = new System.Windows.Forms.Label();
            this.t_DiscardChanges = new System.Windows.Forms.Button();
            this.t_SaveRecord = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SearchText = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.status = new System.Windows.Forms.ToolStripStatusLabel();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.ItemListBox = new System.Windows.Forms.ListBox();
            this.t_DeleteItem = new System.Windows.Forms.Button();
            this.t_CopyToNew = new System.Windows.Forms.Button();
            this.t_NewItem = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tb_castleWar = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t_Icon)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CraftGrid)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSkill3Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSkill2Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSkill1Icon)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slideLeftRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slideUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slideZoom)).BeginInit();
            this.ModPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.exportToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.mySQLConnectionToolStripMenuItem,
            this.extraToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1453, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripSeparator1,
            this.saveToolStripMenuItem,
            this.saveasToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // saveasToolStripMenuItem
            // 
            this.saveasToolStripMenuItem.Name = "saveasToolStripMenuItem";
            this.saveasToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveasToolStripMenuItem.Text = "Save As";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.thisToolStripMenuItem});
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.exportToolStripMenuItem.Text = "Export";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sQLToolStripMenuItem,
            this.xMLToolStripMenuItem,
            this.itemnameToolStripMenuItem,
            this.hTMLToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(133, 22);
            this.toolStripMenuItem1.Text = "File";
            // 
            // sQLToolStripMenuItem
            // 
            this.sQLToolStripMenuItem.Name = "sQLToolStripMenuItem";
            this.sQLToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.sQLToolStripMenuItem.Text = "SQL";
            // 
            // xMLToolStripMenuItem
            // 
            this.xMLToolStripMenuItem.Name = "xMLToolStripMenuItem";
            this.xMLToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.xMLToolStripMenuItem.Text = "XML";
            // 
            // itemnameToolStripMenuItem
            // 
            this.itemnameToolStripMenuItem.Name = "itemnameToolStripMenuItem";
            this.itemnameToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.itemnameToolStripMenuItem.Text = "Itemname.lod";
            // 
            // hTMLToolStripMenuItem
            // 
            this.hTMLToolStripMenuItem.Name = "hTMLToolStripMenuItem";
            this.hTMLToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.hTMLToolStripMenuItem.Text = "HTML";
            // 
            // thisToolStripMenuItem
            // 
            this.thisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertQueryToolStripMenuItem,
            this.updateQueryToolStripMenuItem});
            this.thisToolStripMenuItem.Name = "thisToolStripMenuItem";
            this.thisToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.thisToolStripMenuItem.Text = "This record";
            // 
            // insertQueryToolStripMenuItem
            // 
            this.insertQueryToolStripMenuItem.Name = "insertQueryToolStripMenuItem";
            this.insertQueryToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.insertQueryToolStripMenuItem.Text = "Insert Query";
            // 
            // updateQueryToolStripMenuItem
            // 
            this.updateQueryToolStripMenuItem.Name = "updateQueryToolStripMenuItem";
            this.updateQueryToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.updateQueryToolStripMenuItem.Text = "Update Query";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iconViewerToolStripMenuItem,
            this.itemFlagBuilderToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // iconViewerToolStripMenuItem
            // 
            this.iconViewerToolStripMenuItem.Name = "iconViewerToolStripMenuItem";
            this.iconViewerToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.iconViewerToolStripMenuItem.Text = "Icon Viewer";
            // 
            // itemFlagBuilderToolStripMenuItem
            // 
            this.itemFlagBuilderToolStripMenuItem.Name = "itemFlagBuilderToolStripMenuItem";
            this.itemFlagBuilderToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.itemFlagBuilderToolStripMenuItem.Text = "Item Flag Builder";
            // 
            // mySQLConnectionToolStripMenuItem
            // 
            this.mySQLConnectionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uPDATEThisRecordToolStripMenuItem,
            this.iNSERTThisRecordToolStripMenuItem,
            this.configConnectionToolStripMenuItem,
            this.massActionToolStripMenuItem,
            this.iNSERTALLNotExistingToolStripMenuItem,
            this.uPDATEINSERTThisRecordToolStripMenuItem,
            this.gETALLFromDatabaseToolStripMenuItem,
            this.updateAllNamesToDBToolStripMenuItem,
            this.updateAllFlagsToDBToolStripMenuItem,
            this.updateAllPicsToDBToolStripMenuItem});
            this.mySQLConnectionToolStripMenuItem.Name = "mySQLConnectionToolStripMenuItem";
            this.mySQLConnectionToolStripMenuItem.Size = new System.Drawing.Size(122, 20);
            this.mySQLConnectionToolStripMenuItem.Text = "mySQL Connection";
            // 
            // uPDATEThisRecordToolStripMenuItem
            // 
            this.uPDATEThisRecordToolStripMenuItem.Name = "uPDATEThisRecordToolStripMenuItem";
            this.uPDATEThisRecordToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.uPDATEThisRecordToolStripMenuItem.Text = "UPDATE this record";
            // 
            // iNSERTThisRecordToolStripMenuItem
            // 
            this.iNSERTThisRecordToolStripMenuItem.Name = "iNSERTThisRecordToolStripMenuItem";
            this.iNSERTThisRecordToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.iNSERTThisRecordToolStripMenuItem.Text = "INSERT this record";
            // 
            // configConnectionToolStripMenuItem
            // 
            this.configConnectionToolStripMenuItem.Name = "configConnectionToolStripMenuItem";
            this.configConnectionToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.configConnectionToolStripMenuItem.Text = "Config Connection";
            // 
            // massActionToolStripMenuItem
            // 
            this.massActionToolStripMenuItem.Name = "massActionToolStripMenuItem";
            this.massActionToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.massActionToolStripMenuItem.Text = "Mass Action";
            // 
            // iNSERTALLNotExistingToolStripMenuItem
            // 
            this.iNSERTALLNotExistingToolStripMenuItem.Name = "iNSERTALLNotExistingToolStripMenuItem";
            this.iNSERTALLNotExistingToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.iNSERTALLNotExistingToolStripMenuItem.Text = "INSERT ALL Not Existing";
            // 
            // uPDATEINSERTThisRecordToolStripMenuItem
            // 
            this.uPDATEINSERTThisRecordToolStripMenuItem.Name = "uPDATEINSERTThisRecordToolStripMenuItem";
            this.uPDATEINSERTThisRecordToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.uPDATEINSERTThisRecordToolStripMenuItem.Text = "UPDATE/INSERT This record";
            // 
            // gETALLFromDatabaseToolStripMenuItem
            // 
            this.gETALLFromDatabaseToolStripMenuItem.Name = "gETALLFromDatabaseToolStripMenuItem";
            this.gETALLFromDatabaseToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.gETALLFromDatabaseToolStripMenuItem.Text = "GET ALL From Database";
            // 
            // updateAllNamesToDBToolStripMenuItem
            // 
            this.updateAllNamesToDBToolStripMenuItem.Name = "updateAllNamesToDBToolStripMenuItem";
            this.updateAllNamesToDBToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.updateAllNamesToDBToolStripMenuItem.Text = "Update All Names To DB";
            // 
            // updateAllFlagsToDBToolStripMenuItem
            // 
            this.updateAllFlagsToDBToolStripMenuItem.Name = "updateAllFlagsToDBToolStripMenuItem";
            this.updateAllFlagsToDBToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.updateAllFlagsToDBToolStripMenuItem.Text = "Update All Flags To DB";
            // 
            // updateAllPicsToDBToolStripMenuItem
            // 
            this.updateAllPicsToDBToolStripMenuItem.Name = "updateAllPicsToDBToolStripMenuItem";
            this.updateAllPicsToDBToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.updateAllPicsToDBToolStripMenuItem.Text = "Update All Pics To DB";
            // 
            // extraToolStripMenuItem
            // 
            this.extraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateAllNamesInDatabaseToolStripMenuItem,
            this.toolStripMenuItem2,
            this.getRecordsFromOtherFileToolStripMenuItem,
            this.updateAllPricesInDatabaseToolStripMenuItem,
            this.getPhpItemlistToolStripMenuItem,
            this.removeAllIconsAbove9ToolStripMenuItem,
            this.removeAllIconsAbove14ToolStripMenuItem,
            this.getAllFlagsFromOtherFileToolStripMenuItem,
            this.getIconsFromOtherFileToolStripMenuItem});
            this.extraToolStripMenuItem.Name = "extraToolStripMenuItem";
            this.extraToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.extraToolStripMenuItem.Text = "Extra";
            // 
            // updateAllNamesInDatabaseToolStripMenuItem
            // 
            this.updateAllNamesInDatabaseToolStripMenuItem.Name = "updateAllNamesInDatabaseToolStripMenuItem";
            this.updateAllNamesInDatabaseToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.updateAllNamesInDatabaseToolStripMenuItem.Text = "Update all names in database";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(243, 22);
            this.toolStripMenuItem2.Text = "Update language from other file";
            // 
            // getRecordsFromOtherFileToolStripMenuItem
            // 
            this.getRecordsFromOtherFileToolStripMenuItem.Name = "getRecordsFromOtherFileToolStripMenuItem";
            this.getRecordsFromOtherFileToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.getRecordsFromOtherFileToolStripMenuItem.Text = "Get records from other file";
            // 
            // updateAllPricesInDatabaseToolStripMenuItem
            // 
            this.updateAllPricesInDatabaseToolStripMenuItem.Name = "updateAllPricesInDatabaseToolStripMenuItem";
            this.updateAllPricesInDatabaseToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.updateAllPricesInDatabaseToolStripMenuItem.Text = "Update all prices in database";
            // 
            // getPhpItemlistToolStripMenuItem
            // 
            this.getPhpItemlistToolStripMenuItem.Name = "getPhpItemlistToolStripMenuItem";
            this.getPhpItemlistToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.getPhpItemlistToolStripMenuItem.Text = "Get php itemlist";
            // 
            // removeAllIconsAbove9ToolStripMenuItem
            // 
            this.removeAllIconsAbove9ToolStripMenuItem.Name = "removeAllIconsAbove9ToolStripMenuItem";
            this.removeAllIconsAbove9ToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.removeAllIconsAbove9ToolStripMenuItem.Text = "Remove all icons above 9";
            // 
            // removeAllIconsAbove14ToolStripMenuItem
            // 
            this.removeAllIconsAbove14ToolStripMenuItem.Name = "removeAllIconsAbove14ToolStripMenuItem";
            this.removeAllIconsAbove14ToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.removeAllIconsAbove14ToolStripMenuItem.Text = "Remove all icons above 14";
            // 
            // getAllFlagsFromOtherFileToolStripMenuItem
            // 
            this.getAllFlagsFromOtherFileToolStripMenuItem.Enabled = false;
            this.getAllFlagsFromOtherFileToolStripMenuItem.Name = "getAllFlagsFromOtherFileToolStripMenuItem";
            this.getAllFlagsFromOtherFileToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.getAllFlagsFromOtherFileToolStripMenuItem.Text = "Get All Flags From Other File";
            // 
            // getIconsFromOtherFileToolStripMenuItem
            // 
            this.getIconsFromOtherFileToolStripMenuItem.Name = "getIconsFromOtherFileToolStripMenuItem";
            this.getIconsFromOtherFileToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.getIconsFromOtherFileToolStripMenuItem.Text = "Get Icons From Other File";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Enabled = false;
            this.tabControl2.Location = new System.Drawing.Point(287, 27);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(770, 518);
            this.tabControl2.TabIndex = 19;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.tb_castleWar);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.groupBox13);
            this.tabPage3.Controls.Add(this.groupBox23);
            this.tabPage3.Controls.Add(this.groupBox16);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(762, 492);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Basic Propperties";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.btnPercent2Add);
            this.groupBox13.Controls.Add(this.btnPercent1Add);
            this.groupBox13.Controls.Add(this.btnPercentAdd);
            this.groupBox13.Controls.Add(this.TbPercent2);
            this.groupBox13.Controls.Add(this.TbPercent1);
            this.groupBox13.Controls.Add(this.TbPercent);
            this.groupBox13.Controls.Add(this.label108);
            this.groupBox13.Controls.Add(this.label107);
            this.groupBox13.Controls.Add(this.label106);
            this.groupBox13.Controls.Add(this.t_Num4);
            this.groupBox13.Controls.Add(this.label90);
            this.groupBox13.Controls.Add(this.t_Num0);
            this.groupBox13.Controls.Add(this.label93);
            this.groupBox13.Controls.Add(this.label94);
            this.groupBox13.Controls.Add(this.t_Num1);
            this.groupBox13.Controls.Add(this.t_Num3);
            this.groupBox13.Controls.Add(this.label95);
            this.groupBox13.Controls.Add(this.label96);
            this.groupBox13.Controls.Add(this.t_Num2);
            this.groupBox13.Location = new System.Drawing.Point(201, 305);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(255, 146);
            this.groupBox13.TabIndex = 62;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Options";
            // 
            // btnPercent2Add
            // 
            this.btnPercent2Add.Location = new System.Drawing.Point(131, 73);
            this.btnPercent2Add.Name = "btnPercent2Add";
            this.btnPercent2Add.Size = new System.Drawing.Size(19, 20);
            this.btnPercent2Add.TabIndex = 32;
            this.btnPercent2Add.Text = "+";
            this.btnPercent2Add.UseVisualStyleBackColor = true;
            // 
            // btnPercent1Add
            // 
            this.btnPercent1Add.Location = new System.Drawing.Point(131, 47);
            this.btnPercent1Add.Name = "btnPercent1Add";
            this.btnPercent1Add.Size = new System.Drawing.Size(19, 20);
            this.btnPercent1Add.TabIndex = 31;
            this.btnPercent1Add.Text = "+";
            this.btnPercent1Add.UseVisualStyleBackColor = true;
            // 
            // btnPercentAdd
            // 
            this.btnPercentAdd.Location = new System.Drawing.Point(131, 19);
            this.btnPercentAdd.Name = "btnPercentAdd";
            this.btnPercentAdd.Size = new System.Drawing.Size(19, 20);
            this.btnPercentAdd.TabIndex = 30;
            this.btnPercentAdd.Text = "+";
            this.btnPercentAdd.UseVisualStyleBackColor = true;
            // 
            // TbPercent2
            // 
            this.TbPercent2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbPercent2.Location = new System.Drawing.Point(157, 72);
            this.TbPercent2.Name = "TbPercent2";
            this.TbPercent2.Size = new System.Drawing.Size(53, 20);
            this.TbPercent2.TabIndex = 29;
            this.TbPercent2.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // TbPercent1
            // 
            this.TbPercent1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbPercent1.Location = new System.Drawing.Point(157, 46);
            this.TbPercent1.Name = "TbPercent1";
            this.TbPercent1.Size = new System.Drawing.Size(53, 20);
            this.TbPercent1.TabIndex = 28;
            this.TbPercent1.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // TbPercent
            // 
            this.TbPercent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbPercent.Location = new System.Drawing.Point(157, 20);
            this.TbPercent.Name = "TbPercent";
            this.TbPercent.Size = new System.Drawing.Size(53, 20);
            this.TbPercent.TabIndex = 27;
            this.TbPercent.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(218, 75);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(14, 15);
            this.label108.TabIndex = 26;
            this.label108.Text = "%";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(217, 49);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(14, 15);
            this.label107.TabIndex = 25;
            this.label107.Text = "%";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(216, 22);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(14, 15);
            this.label106.TabIndex = 24;
            this.label106.Text = "%";
            // 
            // t_Num4
            // 
            this.t_Num4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Num4.Location = new System.Drawing.Point(65, 124);
            this.t_Num4.Name = "t_Num4";
            this.t_Num4.Size = new System.Drawing.Size(53, 20);
            this.t_Num4.TabIndex = 22;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(9, 126);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(38, 13);
            this.label90.TabIndex = 23;
            this.label90.Text = "Num4:";
            // 
            // t_Num0
            // 
            this.t_Num0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Num0.Location = new System.Drawing.Point(65, 20);
            this.t_Num0.Name = "t_Num0";
            this.t_Num0.Size = new System.Drawing.Size(53, 20);
            this.t_Num0.TabIndex = 14;
            this.t_Num0.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(9, 22);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(38, 13);
            this.label93.TabIndex = 15;
            this.label93.Text = "Num0:";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(9, 100);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(38, 13);
            this.label94.TabIndex = 21;
            this.label94.Text = "Num3:";
            // 
            // t_Num1
            // 
            this.t_Num1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Num1.Location = new System.Drawing.Point(65, 46);
            this.t_Num1.Name = "t_Num1";
            this.t_Num1.Size = new System.Drawing.Size(53, 20);
            this.t_Num1.TabIndex = 16;
            this.t_Num1.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // t_Num3
            // 
            this.t_Num3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Num3.Location = new System.Drawing.Point(65, 98);
            this.t_Num3.Name = "t_Num3";
            this.t_Num3.Size = new System.Drawing.Size(53, 20);
            this.t_Num3.TabIndex = 20;
            this.t_Num3.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(9, 48);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(38, 13);
            this.label95.TabIndex = 17;
            this.label95.Text = "Num1:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(9, 74);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(38, 13);
            this.label96.TabIndex = 19;
            this.label96.Text = "Num2:";
            // 
            // t_Num2
            // 
            this.t_Num2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Num2.Location = new System.Drawing.Point(65, 72);
            this.t_Num2.Name = "t_Num2";
            this.t_Num2.Size = new System.Drawing.Size(53, 20);
            this.t_Num2.TabIndex = 18;
            this.t_Num2.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label12);
            this.groupBox23.Controls.Add(this.t_quest_tigger);
            this.groupBox23.Controls.Add(this.label13);
            this.groupBox23.Controls.Add(this.t_quest_tigger_count);
            this.groupBox23.Location = new System.Drawing.Point(201, 258);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(289, 41);
            this.groupBox23.TabIndex = 61;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Quest Trigger Info";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(28, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 13);
            this.label12.TabIndex = 54;
            this.label12.Text = "IDs:";
            // 
            // t_quest_tigger
            // 
            this.t_quest_tigger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_quest_tigger.Location = new System.Drawing.Point(60, 17);
            this.t_quest_tigger.Name = "t_quest_tigger";
            this.t_quest_tigger.Size = new System.Drawing.Size(68, 20);
            this.t_quest_tigger.TabIndex = 53;
            this.t_quest_tigger.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(134, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 52;
            this.label13.Text = "Count:";
            // 
            // t_quest_tigger_count
            // 
            this.t_quest_tigger_count.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_quest_tigger_count.Location = new System.Drawing.Point(178, 16);
            this.t_quest_tigger_count.Name = "t_quest_tigger_count";
            this.t_quest_tigger_count.Size = new System.Drawing.Size(68, 20);
            this.t_quest_tigger_count.TabIndex = 51;
            this.t_quest_tigger_count.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.comboBox26);
            this.groupBox16.Controls.Add(this.comboBox25);
            this.groupBox16.Controls.Add(this.comboBox24);
            this.groupBox16.Controls.Add(this.label92);
            this.groupBox16.Controls.Add(this.t_rvr_Grade);
            this.groupBox16.Controls.Add(this.label91);
            this.groupBox16.Controls.Add(this.t_rvr_Value);
            this.groupBox16.Location = new System.Drawing.Point(473, 174);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(209, 74);
            this.groupBox16.TabIndex = 54;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "RvR";
            // 
            // comboBox26
            // 
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.Location = new System.Drawing.Point(55, 45);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(102, 21);
            this.comboBox26.TabIndex = 61;
            // 
            // comboBox25
            // 
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Location = new System.Drawing.Point(55, 45);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(102, 21);
            this.comboBox25.TabIndex = 60;
            // 
            // comboBox24
            // 
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Location = new System.Drawing.Point(55, 17);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(102, 21);
            this.comboBox24.TabIndex = 59;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(13, 48);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(39, 13);
            this.label92.TabIndex = 58;
            this.label92.Text = "Grade:";
            // 
            // t_rvr_Grade
            // 
            this.t_rvr_Grade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_rvr_Grade.Location = new System.Drawing.Point(172, 45);
            this.t_rvr_Grade.Name = "t_rvr_Grade";
            this.t_rvr_Grade.Size = new System.Drawing.Size(31, 20);
            this.t_rvr_Grade.TabIndex = 57;
            this.t_rvr_Grade.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(13, 19);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(37, 13);
            this.label91.TabIndex = 56;
            this.label91.Text = "Value:";
            // 
            // t_rvr_Value
            // 
            this.t_rvr_Value.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_rvr_Value.Location = new System.Drawing.Point(172, 17);
            this.t_rvr_Value.Name = "t_rvr_Value";
            this.t_rvr_Value.Size = new System.Drawing.Size(31, 20);
            this.t_rvr_Value.TabIndex = 55;
            this.t_rvr_Value.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.t_SMC);
            this.groupBox2.Controls.Add(this.label55);
            this.groupBox2.Controls.Add(this.t_Description);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.t_ItemName);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.t_ItemID);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(332, 166);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Basic";
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(298, 138);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(17, 17);
            this.button2.TabIndex = 17;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // t_SMC
            // 
            this.t_SMC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_SMC.Location = new System.Drawing.Point(72, 136);
            this.t_SMC.Name = "t_SMC";
            this.t_SMC.Size = new System.Drawing.Size(221, 20);
            this.t_SMC.TabIndex = 7;
            this.t_SMC.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(6, 138);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(30, 13);
            this.label55.TabIndex = 6;
            this.label55.Text = "SMC";
            // 
            // t_Description
            // 
            this.t_Description.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Description.Location = new System.Drawing.Point(72, 72);
            this.t_Description.Multiline = true;
            this.t_Description.Name = "t_Description";
            this.t_Description.Size = new System.Drawing.Size(244, 58);
            this.t_Description.TabIndex = 5;
            this.t_Description.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Description";
            // 
            // t_ItemName
            // 
            this.t_ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_ItemName.Location = new System.Drawing.Point(72, 46);
            this.t_ItemName.Name = "t_ItemName";
            this.t_ItemName.Size = new System.Drawing.Size(244, 20);
            this.t_ItemName.TabIndex = 3;
            this.t_ItemName.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name";
            // 
            // t_ItemID
            // 
            this.t_ItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_ItemID.Location = new System.Drawing.Point(72, 20);
            this.t_ItemID.Name = "t_ItemID";
            this.t_ItemID.Size = new System.Drawing.Size(69, 20);
            this.t_ItemID.TabIndex = 1;
            this.t_ItemID.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "ID";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.t_Icon);
            this.groupBox3.Controls.Add(this.t_iconpick);
            this.groupBox3.Controls.Add(this.t_IconColumn);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.t_IconRow);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.t_IconID);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(6, 170);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(189, 105);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Inventory Icon";
            // 
            // t_Icon
            // 
            this.t_Icon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Icon.Location = new System.Drawing.Point(136, 30);
            this.t_Icon.Name = "t_Icon";
            this.t_Icon.Size = new System.Drawing.Size(30, 30);
            this.t_Icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.t_Icon.TabIndex = 8;
            this.t_Icon.TabStop = false;
            // 
            // t_iconpick
            // 
            this.t_iconpick.AutoSize = true;
            this.t_iconpick.Location = new System.Drawing.Point(119, 72);
            this.t_iconpick.Name = "t_iconpick";
            this.t_iconpick.Size = new System.Drawing.Size(61, 13);
            this.t_iconpick.TabIndex = 9;
            this.t_iconpick.TabStop = true;
            this.t_iconpick.Text = "Icon Picker";
            // 
            // t_IconColumn
            // 
            this.t_IconColumn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_IconColumn.Location = new System.Drawing.Point(62, 71);
            this.t_IconColumn.Name = "t_IconColumn";
            this.t_IconColumn.Size = new System.Drawing.Size(50, 20);
            this.t_IconColumn.TabIndex = 7;
            this.t_IconColumn.TextChanged += new System.EventHandler(this.t_IconColumn_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Column";
            // 
            // t_IconRow
            // 
            this.t_IconRow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_IconRow.Location = new System.Drawing.Point(62, 45);
            this.t_IconRow.Name = "t_IconRow";
            this.t_IconRow.Size = new System.Drawing.Size(50, 20);
            this.t_IconRow.TabIndex = 5;
            this.t_IconRow.TextChanged += new System.EventHandler(this.t_IconRow_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Row";
            // 
            // t_IconID
            // 
            this.t_IconID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_IconID.Location = new System.Drawing.Point(62, 19);
            this.t_IconID.Name = "t_IconID";
            this.t_IconID.Size = new System.Drawing.Size(50, 20);
            this.t_IconID.TabIndex = 3;
            this.t_IconID.TextChanged += new System.EventHandler(this.t_IconID_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "File ID";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.t_EffectDamage);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.t_EffectAttack);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.t_EffectNormal);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(201, 171);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(265, 84);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Item Special Effects";
            // 
            // t_EffectDamage
            // 
            this.t_EffectDamage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_EffectDamage.Location = new System.Drawing.Point(67, 57);
            this.t_EffectDamage.Name = "t_EffectDamage";
            this.t_EffectDamage.Size = new System.Drawing.Size(192, 20);
            this.t_EffectDamage.TabIndex = 7;
            this.t_EffectDamage.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Damage";
            // 
            // t_EffectAttack
            // 
            this.t_EffectAttack.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_EffectAttack.Location = new System.Drawing.Point(67, 35);
            this.t_EffectAttack.Name = "t_EffectAttack";
            this.t_EffectAttack.Size = new System.Drawing.Size(192, 20);
            this.t_EffectAttack.TabIndex = 5;
            this.t_EffectAttack.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Attack";
            // 
            // t_EffectNormal
            // 
            this.t_EffectNormal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_EffectNormal.Location = new System.Drawing.Point(67, 14);
            this.t_EffectNormal.Name = "t_EffectNormal";
            this.t_EffectNormal.Size = new System.Drawing.Size(192, 20);
            this.t_EffectNormal.TabIndex = 3;
            this.t_EffectNormal.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Normal";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.t_Set5);
            this.groupBox10.Controls.Add(this.label34);
            this.groupBox10.Controls.Add(this.t_Set4);
            this.groupBox10.Controls.Add(this.label30);
            this.groupBox10.Controls.Add(this.t_Set3);
            this.groupBox10.Controls.Add(this.label31);
            this.groupBox10.Controls.Add(this.t_Set2);
            this.groupBox10.Controls.Add(this.label32);
            this.groupBox10.Controls.Add(this.t_Set1);
            this.groupBox10.Controls.Add(this.label33);
            this.groupBox10.Location = new System.Drawing.Point(124, 279);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(71, 135);
            this.groupBox10.TabIndex = 12;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Rand, S,";
            // 
            // t_Set5
            // 
            this.t_Set5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Set5.Location = new System.Drawing.Point(18, 107);
            this.t_Set5.Name = "t_Set5";
            this.t_Set5.Size = new System.Drawing.Size(44, 20);
            this.t_Set5.TabIndex = 13;
            this.t_Set5.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(2, 109);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(13, 13);
            this.label34.TabIndex = 12;
            this.label34.Text = "5";
            // 
            // t_Set4
            // 
            this.t_Set4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Set4.Location = new System.Drawing.Point(18, 84);
            this.t_Set4.Name = "t_Set4";
            this.t_Set4.Size = new System.Drawing.Size(44, 20);
            this.t_Set4.TabIndex = 11;
            this.t_Set4.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(2, 86);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(13, 13);
            this.label30.TabIndex = 10;
            this.label30.Text = "4";
            // 
            // t_Set3
            // 
            this.t_Set3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Set3.Location = new System.Drawing.Point(18, 61);
            this.t_Set3.Name = "t_Set3";
            this.t_Set3.Size = new System.Drawing.Size(44, 20);
            this.t_Set3.TabIndex = 9;
            this.t_Set3.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(2, 63);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(13, 13);
            this.label31.TabIndex = 8;
            this.label31.Text = "3";
            // 
            // t_Set2
            // 
            this.t_Set2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Set2.Location = new System.Drawing.Point(18, 38);
            this.t_Set2.Name = "t_Set2";
            this.t_Set2.Size = new System.Drawing.Size(44, 20);
            this.t_Set2.TabIndex = 7;
            this.t_Set2.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(2, 40);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(13, 13);
            this.label32.TabIndex = 6;
            this.label32.Text = "2";
            // 
            // t_Set1
            // 
            this.t_Set1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Set1.Location = new System.Drawing.Point(18, 15);
            this.t_Set1.Name = "t_Set1";
            this.t_Set1.Size = new System.Drawing.Size(44, 20);
            this.t_Set1.TabIndex = 5;
            this.t_Set1.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(2, 17);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(13, 13);
            this.label33.TabIndex = 4;
            this.label33.Text = "1";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.t_Level2);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Controls.Add(this.t_Price);
            this.groupBox5.Controls.Add(this.t_Weight);
            this.groupBox5.Controls.Add(this.t_Level);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(6, 273);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(112, 125);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Stats";
            // 
            // t_Level2
            // 
            this.t_Level2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Level2.Location = new System.Drawing.Point(47, 41);
            this.t_Level2.Name = "t_Level2";
            this.t_Level2.Size = new System.Drawing.Size(49, 20);
            this.t_Level2.TabIndex = 20;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Level 2";
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.gold1;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(23, 92);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(20, 20);
            this.button4.TabIndex = 18;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.depositphotos_17405057_stock_illustration_scales_of_justice;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(21, 65);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(20, 20);
            this.button3.TabIndex = 17;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // t_Price
            // 
            this.t_Price.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Price.Location = new System.Drawing.Point(47, 92);
            this.t_Price.Name = "t_Price";
            this.t_Price.Size = new System.Drawing.Size(49, 20);
            this.t_Price.TabIndex = 9;
            this.t_Price.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // t_Weight
            // 
            this.t_Weight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Weight.Location = new System.Drawing.Point(47, 67);
            this.t_Weight.Name = "t_Weight";
            this.t_Weight.Size = new System.Drawing.Size(49, 20);
            this.t_Weight.TabIndex = 7;
            this.t_Weight.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // t_Level
            // 
            this.t_Level.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Level.Location = new System.Drawing.Point(47, 14);
            this.t_Level.Name = "t_Level";
            this.t_Level.Size = new System.Drawing.Size(49, 20);
            this.t_Level.TabIndex = 5;
            this.t_Level.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Level";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.t_RareOptionRate);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.t_RareOptionID);
            this.groupBox8.Controls.Add(this.label25);
            this.groupBox8.Location = new System.Drawing.Point(6, 399);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(71, 71);
            this.groupBox8.TabIndex = 10;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "RareOpt";
            // 
            // t_RareOptionRate
            // 
            this.t_RareOptionRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_RareOptionRate.Location = new System.Drawing.Point(29, 45);
            this.t_RareOptionRate.Name = "t_RareOptionRate";
            this.t_RareOptionRate.Size = new System.Drawing.Size(33, 20);
            this.t_RareOptionRate.TabIndex = 7;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1, 47);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 13);
            this.label24.TabIndex = 6;
            this.label24.Text = "Rate";
            // 
            // t_RareOptionID
            // 
            this.t_RareOptionID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_RareOptionID.Location = new System.Drawing.Point(29, 19);
            this.t_RareOptionID.Name = "t_RareOptionID";
            this.t_RareOptionID.Size = new System.Drawing.Size(33, 20);
            this.t_RareOptionID.TabIndex = 5;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1, 21);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(18, 13);
            this.label25.TabIndex = 4;
            this.label25.Text = "ID";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.panel2);
            this.groupBox7.Controls.Add(this.t_maxuse);
            this.groupBox7.Controls.Add(this.label76);
            this.groupBox7.Controls.Add(this.button1);
            this.groupBox7.Controls.Add(this.t_Flag);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.t_WearingPosCombo);
            this.groupBox7.Controls.Add(this.t_WearingPos);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.t_Class);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.t_SubTypeCombo);
            this.groupBox7.Controls.Add(this.t_SubType);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.t_TypeCombo);
            this.groupBox7.Controls.Add(this.t_Type);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Location = new System.Drawing.Point(344, 8);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(406, 164);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Catagorize";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.checkBox_class8);
            this.panel2.Controls.Add(this.checkBox_class7);
            this.panel2.Controls.Add(this.checkBox_class6);
            this.panel2.Controls.Add(this.checkBox_class5);
            this.panel2.Controls.Add(this.checkBox_class4);
            this.panel2.Controls.Add(this.checkBox_class3);
            this.panel2.Controls.Add(this.checkBox_class2);
            this.panel2.Controls.Add(this.checkBox_class1);
            this.panel2.Controls.Add(this.checkBox_class0);
            this.panel2.Location = new System.Drawing.Point(68, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(290, 41);
            this.panel2.TabIndex = 46;
            // 
            // checkBox_class8
            // 
            this.checkBox_class8.AutoSize = true;
            this.checkBox_class8.Location = new System.Drawing.Point(176, 21);
            this.checkBox_class8.Name = "checkBox_class8";
            this.checkBox_class8.Size = new System.Drawing.Size(70, 17);
            this.checkBox_class8.TabIndex = 8;
            this.checkBox_class8.Text = "EX-Mage";
            this.checkBox_class8.UseVisualStyleBackColor = true;
            // 
            // checkBox_class7
            // 
            this.checkBox_class7.AutoSize = true;
            this.checkBox_class7.Location = new System.Drawing.Point(101, 21);
            this.checkBox_class7.Name = "checkBox_class7";
            this.checkBox_class7.Size = new System.Drawing.Size(75, 17);
            this.checkBox_class7.TabIndex = 7;
            this.checkBox_class7.Text = "EX-Rogue";
            this.checkBox_class7.UseVisualStyleBackColor = true;
            // 
            // checkBox_class6
            // 
            this.checkBox_class6.AutoSize = true;
            this.checkBox_class6.Location = new System.Drawing.Point(48, 21);
            this.checkBox_class6.Name = "checkBox_class6";
            this.checkBox_class6.Size = new System.Drawing.Size(41, 17);
            this.checkBox_class6.TabIndex = 6;
            this.checkBox_class6.Text = "NS";
            this.checkBox_class6.UseVisualStyleBackColor = true;
            // 
            // checkBox_class5
            // 
            this.checkBox_class5.AutoSize = true;
            this.checkBox_class5.Location = new System.Drawing.Point(1, 21);
            this.checkBox_class5.Name = "checkBox_class5";
            this.checkBox_class5.Size = new System.Drawing.Size(48, 17);
            this.checkBox_class5.TabIndex = 5;
            this.checkBox_class5.Text = "Sorc";
            this.checkBox_class5.UseVisualStyleBackColor = true;
            // 
            // checkBox_class4
            // 
            this.checkBox_class4.AutoSize = true;
            this.checkBox_class4.Location = new System.Drawing.Point(207, 3);
            this.checkBox_class4.Name = "checkBox_class4";
            this.checkBox_class4.Size = new System.Drawing.Size(58, 17);
            this.checkBox_class4.TabIndex = 4;
            this.checkBox_class4.Text = "Rogue";
            this.checkBox_class4.UseVisualStyleBackColor = true;
            // 
            // checkBox_class3
            // 
            this.checkBox_class3.AutoSize = true;
            this.checkBox_class3.Location = new System.Drawing.Point(155, 3);
            this.checkBox_class3.Name = "checkBox_class3";
            this.checkBox_class3.Size = new System.Drawing.Size(53, 17);
            this.checkBox_class3.TabIndex = 3;
            this.checkBox_class3.Text = "Mage";
            this.checkBox_class3.UseVisualStyleBackColor = true;
            // 
            // checkBox_class2
            // 
            this.checkBox_class2.AutoSize = true;
            this.checkBox_class2.Location = new System.Drawing.Point(101, 3);
            this.checkBox_class2.Name = "checkBox_class2";
            this.checkBox_class2.Size = new System.Drawing.Size(57, 17);
            this.checkBox_class2.TabIndex = 2;
            this.checkBox_class2.Text = "Healer";
            this.checkBox_class2.UseVisualStyleBackColor = true;
            // 
            // checkBox_class1
            // 
            this.checkBox_class1.AutoSize = true;
            this.checkBox_class1.Location = new System.Drawing.Point(48, 3);
            this.checkBox_class1.Name = "checkBox_class1";
            this.checkBox_class1.Size = new System.Drawing.Size(56, 17);
            this.checkBox_class1.TabIndex = 1;
            this.checkBox_class1.Text = "Knight";
            this.checkBox_class1.UseVisualStyleBackColor = true;
            // 
            // checkBox_class0
            // 
            this.checkBox_class0.AutoSize = true;
            this.checkBox_class0.Location = new System.Drawing.Point(1, 3);
            this.checkBox_class0.Name = "checkBox_class0";
            this.checkBox_class0.Size = new System.Drawing.Size(50, 17);
            this.checkBox_class0.TabIndex = 0;
            this.checkBox_class0.Text = "Titan";
            this.checkBox_class0.UseVisualStyleBackColor = true;
            // 
            // t_maxuse
            // 
            this.t_maxuse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_maxuse.Location = new System.Drawing.Point(275, 137);
            this.t_maxuse.Name = "t_maxuse";
            this.t_maxuse.Size = new System.Drawing.Size(60, 20);
            this.t_maxuse.TabIndex = 18;
            this.t_maxuse.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(220, 140);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(49, 13);
            this.label76.TabIndex = 17;
            this.label76.Text = "Max Use";
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.search;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(183, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(17, 17);
            this.button1.TabIndex = 16;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // t_Flag
            // 
            this.t_Flag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Flag.Location = new System.Drawing.Point(91, 137);
            this.t_Flag.Name = "t_Flag";
            this.t_Flag.Size = new System.Drawing.Size(89, 20);
            this.t_Flag.TabIndex = 15;
            this.t_Flag.TextChanged += new System.EventHandler(this.ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(7, 139);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 13);
            this.label22.TabIndex = 14;
            this.label22.Text = "Flag";
            // 
            // t_WearingPosCombo
            // 
            this.t_WearingPosCombo.FormattingEnabled = true;
            this.t_WearingPosCombo.Items.AddRange(new object[] {
            "None",
            "Hood Slot",
            "Shirt Slot",
            "Weapon Slot",
            "Pants Slot",
            "Shield Slot",
            "Gloves Slot",
            "Boots Slot",
            "Accesoire Slot",
            "Accesoire Slot",
            "Accesoire Slot",
            "Pet Slot",
            "Wing Slot"});
            this.t_WearingPosCombo.Location = new System.Drawing.Point(91, 112);
            this.t_WearingPosCombo.Name = "t_WearingPosCombo";
            this.t_WearingPosCombo.Size = new System.Drawing.Size(207, 21);
            this.t_WearingPosCombo.TabIndex = 13;
            // 
            // t_WearingPos
            // 
            this.t_WearingPos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_WearingPos.Location = new System.Drawing.Point(304, 113);
            this.t_WearingPos.Name = "t_WearingPos";
            this.t_WearingPos.Size = new System.Drawing.Size(31, 20);
            this.t_WearingPos.TabIndex = 12;
            this.t_WearingPos.TextChanged += new System.EventHandler(this.t_WearingPos_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(7, 115);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 13);
            this.label21.TabIndex = 11;
            this.label21.Text = "Wearing Pos";
            // 
            // t_Class
            // 
            this.t_Class.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Class.Location = new System.Drawing.Point(367, 67);
            this.t_Class.Name = "t_Class";
            this.t_Class.Size = new System.Drawing.Size(31, 20);
            this.t_Class.TabIndex = 9;
            this.t_Class.TextChanged += new System.EventHandler(this.t_Class_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(7, 69);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "Class";
            // 
            // t_SubTypeCombo
            // 
            this.t_SubTypeCombo.FormattingEnabled = true;
            this.t_SubTypeCombo.Items.AddRange(new object[] {
            "Item Name",
            "Item Description",
            "Flag"});
            this.t_SubTypeCombo.Location = new System.Drawing.Point(142, 38);
            this.t_SubTypeCombo.Name = "t_SubTypeCombo";
            this.t_SubTypeCombo.Size = new System.Drawing.Size(216, 21);
            this.t_SubTypeCombo.TabIndex = 7;
            this.t_SubTypeCombo.SelectedIndexChanged += new System.EventHandler(this.t_SubTypeCombo_SelectedIndexChanged);
            // 
            // t_SubType
            // 
            this.t_SubType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_SubType.Location = new System.Drawing.Point(367, 41);
            this.t_SubType.Name = "t_SubType";
            this.t_SubType.Size = new System.Drawing.Size(31, 20);
            this.t_SubType.TabIndex = 6;
            this.t_SubType.TextChanged += new System.EventHandler(this.t_SubType_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 44);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Sub Type";
            // 
            // t_TypeCombo
            // 
            this.t_TypeCombo.FormattingEnabled = true;
            this.t_TypeCombo.Items.AddRange(new object[] {
            "ITYPE_WEAPON",
            "ITYPE_WEAR",
            "ITYPE_ONCE",
            "ITYPE_SHOT",
            "ITYPE_ETC",
            "ITYPE_ACCESSORY",
            "ITYPE_POTION"});
            this.t_TypeCombo.Location = new System.Drawing.Point(142, 14);
            this.t_TypeCombo.Name = "t_TypeCombo";
            this.t_TypeCombo.Size = new System.Drawing.Size(216, 21);
            this.t_TypeCombo.TabIndex = 4;
            this.t_TypeCombo.SelectedIndexChanged += new System.EventHandler(this.t_TypeCombo_SelectedIndexChanged);
            // 
            // t_Type
            // 
            this.t_Type.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_Type.Location = new System.Drawing.Point(367, 14);
            this.t_Type.Name = "t_Type";
            this.t_Type.Size = new System.Drawing.Size(31, 20);
            this.t_Type.TabIndex = 3;
            this.t_Type.TextChanged += new System.EventHandler(this.t_Type_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Type";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox9);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(762, 492);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Crafting Data";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tabControl1);
            this.groupBox11.Location = new System.Drawing.Point(6, 92);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(477, 263);
            this.groupBox11.TabIndex = 13;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Item Crafting Data";
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 16);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(471, 244);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.CraftGrid);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(463, 215);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // CraftGrid
            // 
            this.CraftGrid.AllowUserToAddRows = false;
            this.CraftGrid.AllowUserToDeleteRows = false;
            this.CraftGrid.BackgroundColor = System.Drawing.SystemColors.Control;
            this.CraftGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CraftGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CraftGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemIcon,
            this.ItemID,
            this.ItemName,
            this.Amount});
            this.CraftGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CraftGrid.EnableHeadersVisualStyles = false;
            this.CraftGrid.Location = new System.Drawing.Point(3, 3);
            this.CraftGrid.MultiSelect = false;
            this.CraftGrid.Name = "CraftGrid";
            this.CraftGrid.ReadOnly = true;
            this.CraftGrid.RowHeadersVisible = false;
            this.CraftGrid.RowTemplate.Height = 34;
            this.CraftGrid.Size = new System.Drawing.Size(457, 209);
            this.CraftGrid.TabIndex = 0;
            // 
            // ItemIcon
            // 
            this.ItemIcon.HeaderText = "";
            this.ItemIcon.Name = "ItemIcon";
            this.ItemIcon.ReadOnly = true;
            this.ItemIcon.Width = 32;
            // 
            // ItemID
            // 
            this.ItemID.HeaderText = "ID";
            this.ItemID.Name = "ItemID";
            this.ItemID.ReadOnly = true;
            this.ItemID.Width = 65;
            // 
            // ItemName
            // 
            this.ItemName.HeaderText = "ItemName";
            this.ItemName.Name = "ItemName";
            this.ItemName.ReadOnly = true;
            this.ItemName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemName.Width = 250;
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.Width = 75;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.t_CraftItemSearch10);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount10);
            this.tabPage2.Controls.Add(this.t_CraftItemID10);
            this.tabPage2.Controls.Add(this.label45);
            this.tabPage2.Controls.Add(this.label46);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount9);
            this.tabPage2.Controls.Add(this.t_CraftItemID9);
            this.tabPage2.Controls.Add(this.label47);
            this.tabPage2.Controls.Add(this.label48);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount8);
            this.tabPage2.Controls.Add(this.t_CraftItemID8);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.label50);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount7);
            this.tabPage2.Controls.Add(this.t_CraftItemID7);
            this.tabPage2.Controls.Add(this.label51);
            this.tabPage2.Controls.Add(this.label52);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount6);
            this.tabPage2.Controls.Add(this.t_CraftItemID6);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Controls.Add(this.label54);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount5);
            this.tabPage2.Controls.Add(this.t_CraftItemID5);
            this.tabPage2.Controls.Add(this.label43);
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount4);
            this.tabPage2.Controls.Add(this.t_CraftItemID4);
            this.tabPage2.Controls.Add(this.label41);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount3);
            this.tabPage2.Controls.Add(this.t_CraftItemID3);
            this.tabPage2.Controls.Add(this.label39);
            this.tabPage2.Controls.Add(this.label40);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount2);
            this.tabPage2.Controls.Add(this.t_CraftItemID2);
            this.tabPage2.Controls.Add(this.label37);
            this.tabPage2.Controls.Add(this.label38);
            this.tabPage2.Controls.Add(this.t_CraftItemAmount1);
            this.tabPage2.Controls.Add(this.t_CraftItemID1);
            this.tabPage2.Controls.Add(this.label35);
            this.tabPage2.Controls.Add(this.label36);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch9);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch8);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch7);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch6);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch5);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch4);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch3);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch2);
            this.tabPage2.Controls.Add(this.t_CraftItemSearch1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(463, 215);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Edit";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch10
            // 
            this.t_CraftItemSearch10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch10.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch10.Location = new System.Drawing.Point(341, 125);
            this.t_CraftItemSearch10.Name = "t_CraftItemSearch10";
            this.t_CraftItemSearch10.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch10.TabIndex = 61;
            this.t_CraftItemSearch10.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemAmount10
            // 
            this.t_CraftItemAmount10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount10.Location = new System.Drawing.Point(412, 124);
            this.t_CraftItemAmount10.Name = "t_CraftItemAmount10";
            this.t_CraftItemAmount10.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount10.TabIndex = 60;
            // 
            // t_CraftItemID10
            // 
            this.t_CraftItemID10.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID10.Location = new System.Drawing.Point(290, 124);
            this.t_CraftItemID10.Name = "t_CraftItemID10";
            this.t_CraftItemID10.ReadOnly = true;
            this.t_CraftItemID10.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID10.TabIndex = 58;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(366, 126);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 13);
            this.label45.TabIndex = 59;
            this.label45.Text = "Amount";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(244, 126);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(41, 13);
            this.label46.TabIndex = 57;
            this.label46.Text = "Item ID";
            // 
            // t_CraftItemAmount9
            // 
            this.t_CraftItemAmount9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount9.Location = new System.Drawing.Point(412, 98);
            this.t_CraftItemAmount9.Name = "t_CraftItemAmount9";
            this.t_CraftItemAmount9.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount9.TabIndex = 55;
            // 
            // t_CraftItemID9
            // 
            this.t_CraftItemID9.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID9.Location = new System.Drawing.Point(290, 98);
            this.t_CraftItemID9.Name = "t_CraftItemID9";
            this.t_CraftItemID9.ReadOnly = true;
            this.t_CraftItemID9.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID9.TabIndex = 53;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(366, 100);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(43, 13);
            this.label47.TabIndex = 54;
            this.label47.Text = "Amount";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(244, 100);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(41, 13);
            this.label48.TabIndex = 52;
            this.label48.Text = "Item ID";
            // 
            // t_CraftItemAmount8
            // 
            this.t_CraftItemAmount8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount8.Location = new System.Drawing.Point(412, 72);
            this.t_CraftItemAmount8.Name = "t_CraftItemAmount8";
            this.t_CraftItemAmount8.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount8.TabIndex = 50;
            // 
            // t_CraftItemID8
            // 
            this.t_CraftItemID8.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID8.Location = new System.Drawing.Point(290, 72);
            this.t_CraftItemID8.Name = "t_CraftItemID8";
            this.t_CraftItemID8.ReadOnly = true;
            this.t_CraftItemID8.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID8.TabIndex = 48;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(366, 74);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(43, 13);
            this.label49.TabIndex = 49;
            this.label49.Text = "Amount";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(244, 74);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(41, 13);
            this.label50.TabIndex = 47;
            this.label50.Text = "Item ID";
            // 
            // t_CraftItemAmount7
            // 
            this.t_CraftItemAmount7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount7.Location = new System.Drawing.Point(412, 46);
            this.t_CraftItemAmount7.Name = "t_CraftItemAmount7";
            this.t_CraftItemAmount7.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount7.TabIndex = 45;
            // 
            // t_CraftItemID7
            // 
            this.t_CraftItemID7.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID7.Location = new System.Drawing.Point(290, 46);
            this.t_CraftItemID7.Name = "t_CraftItemID7";
            this.t_CraftItemID7.ReadOnly = true;
            this.t_CraftItemID7.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID7.TabIndex = 43;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(366, 48);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(43, 13);
            this.label51.TabIndex = 44;
            this.label51.Text = "Amount";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(244, 48);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 13);
            this.label52.TabIndex = 42;
            this.label52.Text = "Item ID";
            // 
            // t_CraftItemAmount6
            // 
            this.t_CraftItemAmount6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount6.Location = new System.Drawing.Point(412, 20);
            this.t_CraftItemAmount6.Name = "t_CraftItemAmount6";
            this.t_CraftItemAmount6.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount6.TabIndex = 40;
            // 
            // t_CraftItemID6
            // 
            this.t_CraftItemID6.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID6.Location = new System.Drawing.Point(290, 20);
            this.t_CraftItemID6.Name = "t_CraftItemID6";
            this.t_CraftItemID6.ReadOnly = true;
            this.t_CraftItemID6.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID6.TabIndex = 38;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(366, 22);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(43, 13);
            this.label53.TabIndex = 39;
            this.label53.Text = "Amount";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(244, 22);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(41, 13);
            this.label54.TabIndex = 37;
            this.label54.Text = "Item ID";
            // 
            // t_CraftItemAmount5
            // 
            this.t_CraftItemAmount5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount5.Location = new System.Drawing.Point(174, 121);
            this.t_CraftItemAmount5.Name = "t_CraftItemAmount5";
            this.t_CraftItemAmount5.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount5.TabIndex = 35;
            // 
            // t_CraftItemID5
            // 
            this.t_CraftItemID5.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID5.Location = new System.Drawing.Point(52, 121);
            this.t_CraftItemID5.Name = "t_CraftItemID5";
            this.t_CraftItemID5.ReadOnly = true;
            this.t_CraftItemID5.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID5.TabIndex = 33;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(128, 123);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(43, 13);
            this.label43.TabIndex = 34;
            this.label43.Text = "Amount";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 123);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(41, 13);
            this.label44.TabIndex = 32;
            this.label44.Text = "Item ID";
            // 
            // t_CraftItemAmount4
            // 
            this.t_CraftItemAmount4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount4.Location = new System.Drawing.Point(174, 95);
            this.t_CraftItemAmount4.Name = "t_CraftItemAmount4";
            this.t_CraftItemAmount4.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount4.TabIndex = 30;
            // 
            // t_CraftItemID4
            // 
            this.t_CraftItemID4.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID4.Location = new System.Drawing.Point(52, 95);
            this.t_CraftItemID4.Name = "t_CraftItemID4";
            this.t_CraftItemID4.ReadOnly = true;
            this.t_CraftItemID4.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID4.TabIndex = 28;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(128, 97);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(43, 13);
            this.label41.TabIndex = 29;
            this.label41.Text = "Amount";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 97);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 13);
            this.label42.TabIndex = 27;
            this.label42.Text = "Item ID";
            // 
            // t_CraftItemAmount3
            // 
            this.t_CraftItemAmount3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount3.Location = new System.Drawing.Point(174, 69);
            this.t_CraftItemAmount3.Name = "t_CraftItemAmount3";
            this.t_CraftItemAmount3.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount3.TabIndex = 25;
            // 
            // t_CraftItemID3
            // 
            this.t_CraftItemID3.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID3.Location = new System.Drawing.Point(52, 69);
            this.t_CraftItemID3.Name = "t_CraftItemID3";
            this.t_CraftItemID3.ReadOnly = true;
            this.t_CraftItemID3.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID3.TabIndex = 23;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(128, 71);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(43, 13);
            this.label39.TabIndex = 24;
            this.label39.Text = "Amount";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 71);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 13);
            this.label40.TabIndex = 22;
            this.label40.Text = "Item ID";
            // 
            // t_CraftItemAmount2
            // 
            this.t_CraftItemAmount2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount2.Location = new System.Drawing.Point(174, 43);
            this.t_CraftItemAmount2.Name = "t_CraftItemAmount2";
            this.t_CraftItemAmount2.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount2.TabIndex = 20;
            // 
            // t_CraftItemID2
            // 
            this.t_CraftItemID2.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID2.Location = new System.Drawing.Point(52, 43);
            this.t_CraftItemID2.Name = "t_CraftItemID2";
            this.t_CraftItemID2.ReadOnly = true;
            this.t_CraftItemID2.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID2.TabIndex = 18;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(128, 45);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(43, 13);
            this.label37.TabIndex = 19;
            this.label37.Text = "Amount";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 45);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(41, 13);
            this.label38.TabIndex = 17;
            this.label38.Text = "Item ID";
            // 
            // t_CraftItemAmount1
            // 
            this.t_CraftItemAmount1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemAmount1.Location = new System.Drawing.Point(174, 17);
            this.t_CraftItemAmount1.Name = "t_CraftItemAmount1";
            this.t_CraftItemAmount1.Size = new System.Drawing.Size(36, 20);
            this.t_CraftItemAmount1.TabIndex = 15;
            // 
            // t_CraftItemID1
            // 
            this.t_CraftItemID1.BackColor = System.Drawing.SystemColors.Window;
            this.t_CraftItemID1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftItemID1.Location = new System.Drawing.Point(52, 17);
            this.t_CraftItemID1.Name = "t_CraftItemID1";
            this.t_CraftItemID1.ReadOnly = true;
            this.t_CraftItemID1.Size = new System.Drawing.Size(42, 20);
            this.t_CraftItemID1.TabIndex = 13;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(128, 19);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(43, 13);
            this.label35.TabIndex = 14;
            this.label35.Text = "Amount";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 19);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(41, 13);
            this.label36.TabIndex = 12;
            this.label36.Text = "Item ID";
            // 
            // t_CraftItemSearch9
            // 
            this.t_CraftItemSearch9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch9.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch9.Location = new System.Drawing.Point(341, 99);
            this.t_CraftItemSearch9.Name = "t_CraftItemSearch9";
            this.t_CraftItemSearch9.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch9.TabIndex = 56;
            this.t_CraftItemSearch9.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch8
            // 
            this.t_CraftItemSearch8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch8.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch8.Location = new System.Drawing.Point(341, 73);
            this.t_CraftItemSearch8.Name = "t_CraftItemSearch8";
            this.t_CraftItemSearch8.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch8.TabIndex = 51;
            this.t_CraftItemSearch8.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch7
            // 
            this.t_CraftItemSearch7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch7.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch7.Location = new System.Drawing.Point(341, 47);
            this.t_CraftItemSearch7.Name = "t_CraftItemSearch7";
            this.t_CraftItemSearch7.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch7.TabIndex = 46;
            this.t_CraftItemSearch7.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch6
            // 
            this.t_CraftItemSearch6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch6.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch6.Location = new System.Drawing.Point(341, 21);
            this.t_CraftItemSearch6.Name = "t_CraftItemSearch6";
            this.t_CraftItemSearch6.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch6.TabIndex = 41;
            this.t_CraftItemSearch6.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch5
            // 
            this.t_CraftItemSearch5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch5.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch5.Location = new System.Drawing.Point(103, 122);
            this.t_CraftItemSearch5.Name = "t_CraftItemSearch5";
            this.t_CraftItemSearch5.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch5.TabIndex = 36;
            this.t_CraftItemSearch5.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch4
            // 
            this.t_CraftItemSearch4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch4.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch4.Location = new System.Drawing.Point(103, 96);
            this.t_CraftItemSearch4.Name = "t_CraftItemSearch4";
            this.t_CraftItemSearch4.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch4.TabIndex = 31;
            this.t_CraftItemSearch4.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch3
            // 
            this.t_CraftItemSearch3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch3.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch3.Location = new System.Drawing.Point(103, 70);
            this.t_CraftItemSearch3.Name = "t_CraftItemSearch3";
            this.t_CraftItemSearch3.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch3.TabIndex = 26;
            this.t_CraftItemSearch3.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch2
            // 
            this.t_CraftItemSearch2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch2.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch2.Location = new System.Drawing.Point(103, 44);
            this.t_CraftItemSearch2.Name = "t_CraftItemSearch2";
            this.t_CraftItemSearch2.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch2.TabIndex = 21;
            this.t_CraftItemSearch2.UseVisualStyleBackColor = true;
            // 
            // t_CraftItemSearch1
            // 
            this.t_CraftItemSearch1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.t_CraftItemSearch1.FlatAppearance.BorderSize = 0;
            this.t_CraftItemSearch1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_CraftItemSearch1.Location = new System.Drawing.Point(103, 18);
            this.t_CraftItemSearch1.Name = "t_CraftItemSearch1";
            this.t_CraftItemSearch1.Size = new System.Drawing.Size(19, 20);
            this.t_CraftItemSearch1.TabIndex = 16;
            this.t_CraftItemSearch1.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.t_CraftSkill2Level);
            this.groupBox9.Controls.Add(this.label27);
            this.groupBox9.Controls.Add(this.t_CraftSkill1Level);
            this.groupBox9.Controls.Add(this.label28);
            this.groupBox9.Controls.Add(this.t_CraftSkill2ID);
            this.groupBox9.Controls.Add(this.label23);
            this.groupBox9.Controls.Add(this.t_CraftSkill1ID);
            this.groupBox9.Controls.Add(this.label26);
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(260, 80);
            this.groupBox9.TabIndex = 11;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Craft Skill Requirements";
            // 
            // t_CraftSkill2Level
            // 
            this.t_CraftSkill2Level.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftSkill2Level.Location = new System.Drawing.Point(173, 45);
            this.t_CraftSkill2Level.Name = "t_CraftSkill2Level";
            this.t_CraftSkill2Level.Size = new System.Drawing.Size(60, 20);
            this.t_CraftSkill2Level.TabIndex = 11;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(127, 47);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 13);
            this.label27.TabIndex = 10;
            this.label27.Text = "Level";
            // 
            // t_CraftSkill1Level
            // 
            this.t_CraftSkill1Level.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftSkill1Level.Location = new System.Drawing.Point(173, 19);
            this.t_CraftSkill1Level.Name = "t_CraftSkill1Level";
            this.t_CraftSkill1Level.Size = new System.Drawing.Size(60, 20);
            this.t_CraftSkill1Level.TabIndex = 9;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(127, 21);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(33, 13);
            this.label28.TabIndex = 8;
            this.label28.Text = "Level";
            // 
            // t_CraftSkill2ID
            // 
            this.t_CraftSkill2ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftSkill2ID.Location = new System.Drawing.Point(59, 45);
            this.t_CraftSkill2ID.Name = "t_CraftSkill2ID";
            this.t_CraftSkill2ID.Size = new System.Drawing.Size(60, 20);
            this.t_CraftSkill2ID.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 47);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 13);
            this.label23.TabIndex = 6;
            this.label23.Text = "Skill ID";
            // 
            // t_CraftSkill1ID
            // 
            this.t_CraftSkill1ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t_CraftSkill1ID.Location = new System.Drawing.Point(59, 19);
            this.t_CraftSkill1ID.Name = "t_CraftSkill1ID";
            this.t_CraftSkill1ID.Size = new System.Drawing.Size(60, 20);
            this.t_CraftSkill1ID.TabIndex = 5;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(13, 21);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 13);
            this.label26.TabIndex = 4;
            this.label26.Text = "Skill ID";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage5.Controls.Add(this.groupBox12);
            this.tabPage5.Controls.Add(this.panel3);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(762, 492);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Rare Option";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btnRareSearch9);
            this.groupBox12.Controls.Add(this.tbRareOpt9);
            this.groupBox12.Controls.Add(this.tbRareChance9);
            this.groupBox12.Controls.Add(this.label66);
            this.groupBox12.Controls.Add(this.label67);
            this.groupBox12.Controls.Add(this.btnRareSearch8);
            this.groupBox12.Controls.Add(this.tbRareOpt8);
            this.groupBox12.Controls.Add(this.tbRareChance8);
            this.groupBox12.Controls.Add(this.label68);
            this.groupBox12.Controls.Add(this.label69);
            this.groupBox12.Controls.Add(this.btnRareSearch7);
            this.groupBox12.Controls.Add(this.tbRareOpt7);
            this.groupBox12.Controls.Add(this.tbRareChance7);
            this.groupBox12.Controls.Add(this.label70);
            this.groupBox12.Controls.Add(this.label71);
            this.groupBox12.Controls.Add(this.btnRareSearch6);
            this.groupBox12.Controls.Add(this.tbRareOpt6);
            this.groupBox12.Controls.Add(this.tbRareChance6);
            this.groupBox12.Controls.Add(this.label72);
            this.groupBox12.Controls.Add(this.label73);
            this.groupBox12.Controls.Add(this.btnRareSearch5);
            this.groupBox12.Controls.Add(this.tbRareOpt5);
            this.groupBox12.Controls.Add(this.tbRareChance5);
            this.groupBox12.Controls.Add(this.label74);
            this.groupBox12.Controls.Add(this.label75);
            this.groupBox12.Controls.Add(this.btnRareSearch4);
            this.groupBox12.Controls.Add(this.tbRareOpt4);
            this.groupBox12.Controls.Add(this.tbRareChance4);
            this.groupBox12.Controls.Add(this.label64);
            this.groupBox12.Controls.Add(this.label65);
            this.groupBox12.Controls.Add(this.btnRareSearch3);
            this.groupBox12.Controls.Add(this.tbRareOpt3);
            this.groupBox12.Controls.Add(this.tbRareChance3);
            this.groupBox12.Controls.Add(this.label62);
            this.groupBox12.Controls.Add(this.label63);
            this.groupBox12.Controls.Add(this.btnRareSearch2);
            this.groupBox12.Controls.Add(this.tbRareOpt2);
            this.groupBox12.Controls.Add(this.tbRareChance2);
            this.groupBox12.Controls.Add(this.label60);
            this.groupBox12.Controls.Add(this.label61);
            this.groupBox12.Controls.Add(this.btnRareSearch1);
            this.groupBox12.Controls.Add(this.tbRareOpt1);
            this.groupBox12.Controls.Add(this.tbRareChance1);
            this.groupBox12.Controls.Add(this.label58);
            this.groupBox12.Controls.Add(this.label59);
            this.groupBox12.Controls.Add(this.btnRareSearch0);
            this.groupBox12.Controls.Add(this.tbRareOpt0);
            this.groupBox12.Controls.Add(this.tbRareChance0);
            this.groupBox12.Controls.Add(this.label57);
            this.groupBox12.Controls.Add(this.label56);
            this.groupBox12.Location = new System.Drawing.Point(6, 38);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(317, 328);
            this.groupBox12.TabIndex = 12;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Rare Options";
            // 
            // btnRareSearch9
            // 
            this.btnRareSearch9.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch9.FlatAppearance.BorderSize = 0;
            this.btnRareSearch9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch9.Location = new System.Drawing.Point(134, 273);
            this.btnRareSearch9.Name = "btnRareSearch9";
            this.btnRareSearch9.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch9.TabIndex = 62;
            this.btnRareSearch9.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt9
            // 
            this.tbRareOpt9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt9.Location = new System.Drawing.Point(73, 273);
            this.tbRareOpt9.Name = "tbRareOpt9";
            this.tbRareOpt9.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt9.TabIndex = 61;
            // 
            // tbRareChance9
            // 
            this.tbRareChance9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance9.Location = new System.Drawing.Point(220, 273);
            this.tbRareChance9.Name = "tbRareChance9";
            this.tbRareChance9.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance9.TabIndex = 60;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(170, 275);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(44, 13);
            this.label66.TabIndex = 59;
            this.label66.Text = "Chance";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(18, 275);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(47, 13);
            this.label67.TabIndex = 58;
            this.label67.Text = "Option 9";
            // 
            // btnRareSearch8
            // 
            this.btnRareSearch8.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch8.FlatAppearance.BorderSize = 0;
            this.btnRareSearch8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch8.Location = new System.Drawing.Point(134, 247);
            this.btnRareSearch8.Name = "btnRareSearch8";
            this.btnRareSearch8.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch8.TabIndex = 57;
            this.btnRareSearch8.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt8
            // 
            this.tbRareOpt8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt8.Location = new System.Drawing.Point(73, 247);
            this.tbRareOpt8.Name = "tbRareOpt8";
            this.tbRareOpt8.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt8.TabIndex = 56;
            // 
            // tbRareChance8
            // 
            this.tbRareChance8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance8.Location = new System.Drawing.Point(220, 247);
            this.tbRareChance8.Name = "tbRareChance8";
            this.tbRareChance8.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance8.TabIndex = 55;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(170, 249);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(44, 13);
            this.label68.TabIndex = 54;
            this.label68.Text = "Chance";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(18, 249);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(47, 13);
            this.label69.TabIndex = 53;
            this.label69.Text = "Option 8";
            // 
            // btnRareSearch7
            // 
            this.btnRareSearch7.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch7.FlatAppearance.BorderSize = 0;
            this.btnRareSearch7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch7.Location = new System.Drawing.Point(134, 221);
            this.btnRareSearch7.Name = "btnRareSearch7";
            this.btnRareSearch7.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch7.TabIndex = 52;
            this.btnRareSearch7.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt7
            // 
            this.tbRareOpt7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt7.Location = new System.Drawing.Point(73, 221);
            this.tbRareOpt7.Name = "tbRareOpt7";
            this.tbRareOpt7.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt7.TabIndex = 51;
            // 
            // tbRareChance7
            // 
            this.tbRareChance7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance7.Location = new System.Drawing.Point(220, 221);
            this.tbRareChance7.Name = "tbRareChance7";
            this.tbRareChance7.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance7.TabIndex = 50;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(170, 223);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(44, 13);
            this.label70.TabIndex = 49;
            this.label70.Text = "Chance";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(18, 223);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(47, 13);
            this.label71.TabIndex = 48;
            this.label71.Text = "Option 7";
            // 
            // btnRareSearch6
            // 
            this.btnRareSearch6.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch6.FlatAppearance.BorderSize = 0;
            this.btnRareSearch6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch6.Location = new System.Drawing.Point(134, 195);
            this.btnRareSearch6.Name = "btnRareSearch6";
            this.btnRareSearch6.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch6.TabIndex = 47;
            this.btnRareSearch6.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt6
            // 
            this.tbRareOpt6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt6.Location = new System.Drawing.Point(73, 195);
            this.tbRareOpt6.Name = "tbRareOpt6";
            this.tbRareOpt6.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt6.TabIndex = 46;
            // 
            // tbRareChance6
            // 
            this.tbRareChance6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance6.Location = new System.Drawing.Point(220, 195);
            this.tbRareChance6.Name = "tbRareChance6";
            this.tbRareChance6.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance6.TabIndex = 45;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(170, 197);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(44, 13);
            this.label72.TabIndex = 44;
            this.label72.Text = "Chance";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(18, 197);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(47, 13);
            this.label73.TabIndex = 43;
            this.label73.Text = "Option 6";
            // 
            // btnRareSearch5
            // 
            this.btnRareSearch5.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch5.FlatAppearance.BorderSize = 0;
            this.btnRareSearch5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch5.Location = new System.Drawing.Point(134, 169);
            this.btnRareSearch5.Name = "btnRareSearch5";
            this.btnRareSearch5.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch5.TabIndex = 42;
            this.btnRareSearch5.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt5
            // 
            this.tbRareOpt5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt5.Location = new System.Drawing.Point(73, 169);
            this.tbRareOpt5.Name = "tbRareOpt5";
            this.tbRareOpt5.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt5.TabIndex = 41;
            // 
            // tbRareChance5
            // 
            this.tbRareChance5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance5.Location = new System.Drawing.Point(220, 169);
            this.tbRareChance5.Name = "tbRareChance5";
            this.tbRareChance5.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance5.TabIndex = 40;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(170, 171);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(44, 13);
            this.label74.TabIndex = 39;
            this.label74.Text = "Chance";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(18, 171);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(47, 13);
            this.label75.TabIndex = 38;
            this.label75.Text = "Option 5";
            // 
            // btnRareSearch4
            // 
            this.btnRareSearch4.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch4.FlatAppearance.BorderSize = 0;
            this.btnRareSearch4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch4.Location = new System.Drawing.Point(134, 143);
            this.btnRareSearch4.Name = "btnRareSearch4";
            this.btnRareSearch4.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch4.TabIndex = 37;
            this.btnRareSearch4.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt4
            // 
            this.tbRareOpt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt4.Location = new System.Drawing.Point(73, 143);
            this.tbRareOpt4.Name = "tbRareOpt4";
            this.tbRareOpt4.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt4.TabIndex = 36;
            // 
            // tbRareChance4
            // 
            this.tbRareChance4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance4.Location = new System.Drawing.Point(220, 143);
            this.tbRareChance4.Name = "tbRareChance4";
            this.tbRareChance4.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance4.TabIndex = 35;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(170, 145);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(44, 13);
            this.label64.TabIndex = 34;
            this.label64.Text = "Chance";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(18, 145);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(47, 13);
            this.label65.TabIndex = 33;
            this.label65.Text = "Option 4";
            // 
            // btnRareSearch3
            // 
            this.btnRareSearch3.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch3.FlatAppearance.BorderSize = 0;
            this.btnRareSearch3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch3.Location = new System.Drawing.Point(134, 117);
            this.btnRareSearch3.Name = "btnRareSearch3";
            this.btnRareSearch3.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch3.TabIndex = 32;
            this.btnRareSearch3.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt3
            // 
            this.tbRareOpt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt3.Location = new System.Drawing.Point(73, 117);
            this.tbRareOpt3.Name = "tbRareOpt3";
            this.tbRareOpt3.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt3.TabIndex = 31;
            // 
            // tbRareChance3
            // 
            this.tbRareChance3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance3.Location = new System.Drawing.Point(220, 117);
            this.tbRareChance3.Name = "tbRareChance3";
            this.tbRareChance3.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance3.TabIndex = 30;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(170, 119);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(44, 13);
            this.label62.TabIndex = 29;
            this.label62.Text = "Chance";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(18, 119);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(47, 13);
            this.label63.TabIndex = 28;
            this.label63.Text = "Option 3";
            // 
            // btnRareSearch2
            // 
            this.btnRareSearch2.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch2.FlatAppearance.BorderSize = 0;
            this.btnRareSearch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch2.Location = new System.Drawing.Point(134, 91);
            this.btnRareSearch2.Name = "btnRareSearch2";
            this.btnRareSearch2.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch2.TabIndex = 27;
            this.btnRareSearch2.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt2
            // 
            this.tbRareOpt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt2.Location = new System.Drawing.Point(73, 91);
            this.tbRareOpt2.Name = "tbRareOpt2";
            this.tbRareOpt2.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt2.TabIndex = 26;
            // 
            // tbRareChance2
            // 
            this.tbRareChance2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance2.Location = new System.Drawing.Point(220, 91);
            this.tbRareChance2.Name = "tbRareChance2";
            this.tbRareChance2.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance2.TabIndex = 25;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(170, 93);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(44, 13);
            this.label60.TabIndex = 24;
            this.label60.Text = "Chance";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(18, 93);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(47, 13);
            this.label61.TabIndex = 23;
            this.label61.Text = "Option 2";
            // 
            // btnRareSearch1
            // 
            this.btnRareSearch1.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch1.FlatAppearance.BorderSize = 0;
            this.btnRareSearch1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch1.Location = new System.Drawing.Point(134, 65);
            this.btnRareSearch1.Name = "btnRareSearch1";
            this.btnRareSearch1.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch1.TabIndex = 22;
            this.btnRareSearch1.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt1
            // 
            this.tbRareOpt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt1.Location = new System.Drawing.Point(73, 65);
            this.tbRareOpt1.Name = "tbRareOpt1";
            this.tbRareOpt1.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt1.TabIndex = 21;
            // 
            // tbRareChance1
            // 
            this.tbRareChance1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance1.Location = new System.Drawing.Point(220, 65);
            this.tbRareChance1.Name = "tbRareChance1";
            this.tbRareChance1.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance1.TabIndex = 20;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(170, 67);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(44, 13);
            this.label58.TabIndex = 19;
            this.label58.Text = "Chance";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(18, 67);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(47, 13);
            this.label59.TabIndex = 18;
            this.label59.Text = "Option 1";
            // 
            // btnRareSearch0
            // 
            this.btnRareSearch0.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.btnRareSearch0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRareSearch0.FlatAppearance.BorderSize = 0;
            this.btnRareSearch0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRareSearch0.Location = new System.Drawing.Point(134, 39);
            this.btnRareSearch0.Name = "btnRareSearch0";
            this.btnRareSearch0.Size = new System.Drawing.Size(19, 20);
            this.btnRareSearch0.TabIndex = 17;
            this.btnRareSearch0.UseVisualStyleBackColor = true;
            // 
            // tbRareOpt0
            // 
            this.tbRareOpt0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareOpt0.Location = new System.Drawing.Point(73, 39);
            this.tbRareOpt0.Name = "tbRareOpt0";
            this.tbRareOpt0.Size = new System.Drawing.Size(55, 20);
            this.tbRareOpt0.TabIndex = 4;
            // 
            // tbRareChance0
            // 
            this.tbRareChance0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRareChance0.Location = new System.Drawing.Point(220, 39);
            this.tbRareChance0.Name = "tbRareChance0";
            this.tbRareChance0.Size = new System.Drawing.Size(74, 20);
            this.tbRareChance0.TabIndex = 3;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(170, 41);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(44, 13);
            this.label57.TabIndex = 2;
            this.label57.Text = "Chance";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(18, 41);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(47, 13);
            this.label56.TabIndex = 1;
            this.label56.Text = "Option 0";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnRareDbPut);
            this.panel3.Controls.Add(this.btnRareDbGet);
            this.panel3.Location = new System.Drawing.Point(6, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(687, 29);
            this.panel3.TabIndex = 11;
            // 
            // btnRareDbPut
            // 
            this.btnRareDbPut.Location = new System.Drawing.Point(152, 2);
            this.btnRareDbPut.Name = "btnRareDbPut";
            this.btnRareDbPut.Size = new System.Drawing.Size(152, 23);
            this.btnRareDbPut.TabIndex = 1;
            this.btnRareDbPut.Text = "Update to database";
            this.btnRareDbPut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRareDbPut.UseVisualStyleBackColor = true;
            // 
            // btnRareDbGet
            // 
            this.btnRareDbGet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRareDbGet.Location = new System.Drawing.Point(5, 2);
            this.btnRareDbGet.Name = "btnRareDbGet";
            this.btnRareDbGet.Size = new System.Drawing.Size(141, 23);
            this.btnRareDbGet.TabIndex = 0;
            this.btnRareDbGet.Text = "Get from database";
            this.btnRareDbGet.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRareDbGet.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage6.Controls.Add(this.textBox6);
            this.tabPage6.Controls.Add(this.textBox5);
            this.tabPage6.Controls.Add(this.textBox4);
            this.tabPage6.Controls.Add(this.textBox3);
            this.tabPage6.Controls.Add(this.textBox2);
            this.tabPage6.Controls.Add(this.textBox1);
            this.tabPage6.Controls.Add(this.btnSearchSkill3);
            this.tabPage6.Controls.Add(this.btnSearchSkill2);
            this.tabPage6.Controls.Add(this.btnSearchSkill1);
            this.tabPage6.Controls.Add(this.tbCB1);
            this.tabPage6.Controls.Add(this.tbCB2);
            this.tabPage6.Controls.Add(this.label89);
            this.tabPage6.Controls.Add(this.label86);
            this.tabPage6.Controls.Add(this.label87);
            this.tabPage6.Controls.Add(this.label88);
            this.tabPage6.Controls.Add(this.label85);
            this.tabPage6.Controls.Add(this.label84);
            this.tabPage6.Controls.Add(this.label83);
            this.tabPage6.Controls.Add(this.label81);
            this.tabPage6.Controls.Add(this.label82);
            this.tabPage6.Controls.Add(this.tbSkillLevel3);
            this.tabPage6.Controls.Add(this.tbSkillID3);
            this.tabPage6.Controls.Add(this.label79);
            this.tabPage6.Controls.Add(this.label80);
            this.tabPage6.Controls.Add(this.tbSkillLevel2);
            this.tabPage6.Controls.Add(this.tbSkillID2);
            this.tabPage6.Controls.Add(this.label78);
            this.tabPage6.Controls.Add(this.label77);
            this.tabPage6.Controls.Add(this.tbSkillLevel1);
            this.tabPage6.Controls.Add(this.tbSkillID1);
            this.tabPage6.Controls.Add(this.tbSealID6);
            this.tabPage6.Controls.Add(this.cbSealLevel6);
            this.tabPage6.Controls.Add(this.tbSealLevel6);
            this.tabPage6.Controls.Add(this.cbSealID6);
            this.tabPage6.Controls.Add(this.tbSealID5);
            this.tabPage6.Controls.Add(this.cbSealLevel5);
            this.tabPage6.Controls.Add(this.tbSealLevel5);
            this.tabPage6.Controls.Add(this.cbSealID5);
            this.tabPage6.Controls.Add(this.tbSealID4);
            this.tabPage6.Controls.Add(this.cbSealLevel4);
            this.tabPage6.Controls.Add(this.tbSealLevel4);
            this.tabPage6.Controls.Add(this.cbSealID4);
            this.tabPage6.Controls.Add(this.tbSealID3);
            this.tabPage6.Controls.Add(this.cbSealLevel3);
            this.tabPage6.Controls.Add(this.tbSealLevel3);
            this.tabPage6.Controls.Add(this.cbSealID3);
            this.tabPage6.Controls.Add(this.tbSealID2);
            this.tabPage6.Controls.Add(this.cbSealLevel2);
            this.tabPage6.Controls.Add(this.tbSealLevel2);
            this.tabPage6.Controls.Add(this.cbSealID2);
            this.tabPage6.Controls.Add(this.tbSealID1);
            this.tabPage6.Controls.Add(this.cbSealLevel1);
            this.tabPage6.Controls.Add(this.tbSealLevel1);
            this.tabPage6.Controls.Add(this.cbSealID1);
            this.tabPage6.Controls.Add(this.pbSkill3Icon);
            this.tabPage6.Controls.Add(this.pbSkill2Icon);
            this.tabPage6.Controls.Add(this.pbSkill1Icon);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(762, 492);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "Purple Items";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(485, 99);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(38, 20);
            this.textBox6.TabIndex = 61;
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Location = new System.Drawing.Point(485, 236);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(38, 20);
            this.textBox5.TabIndex = 60;
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(485, 210);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(38, 20);
            this.textBox4.TabIndex = 59;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(485, 182);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(38, 20);
            this.textBox3.TabIndex = 58;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(485, 155);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(38, 20);
            this.textBox2.TabIndex = 57;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(485, 126);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(38, 20);
            this.textBox1.TabIndex = 56;
            // 
            // btnSearchSkill3
            // 
            this.btnSearchSkill3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchSkill3.FlatAppearance.BorderSize = 0;
            this.btnSearchSkill3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchSkill3.Location = new System.Drawing.Point(171, 372);
            this.btnSearchSkill3.Name = "btnSearchSkill3";
            this.btnSearchSkill3.Size = new System.Drawing.Size(19, 20);
            this.btnSearchSkill3.TabIndex = 55;
            this.btnSearchSkill3.UseVisualStyleBackColor = true;
            // 
            // btnSearchSkill2
            // 
            this.btnSearchSkill2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchSkill2.FlatAppearance.BorderSize = 0;
            this.btnSearchSkill2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchSkill2.Location = new System.Drawing.Point(171, 332);
            this.btnSearchSkill2.Name = "btnSearchSkill2";
            this.btnSearchSkill2.Size = new System.Drawing.Size(19, 20);
            this.btnSearchSkill2.TabIndex = 54;
            this.btnSearchSkill2.UseVisualStyleBackColor = true;
            // 
            // btnSearchSkill1
            // 
            this.btnSearchSkill1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchSkill1.FlatAppearance.BorderSize = 0;
            this.btnSearchSkill1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchSkill1.Location = new System.Drawing.Point(171, 293);
            this.btnSearchSkill1.Name = "btnSearchSkill1";
            this.btnSearchSkill1.Size = new System.Drawing.Size(19, 20);
            this.btnSearchSkill1.TabIndex = 53;
            this.btnSearchSkill1.UseVisualStyleBackColor = true;
            // 
            // tbCB1
            // 
            this.tbCB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbCB1.Location = new System.Drawing.Point(162, 52);
            this.tbCB1.Name = "tbCB1";
            this.tbCB1.Size = new System.Drawing.Size(38, 20);
            this.tbCB1.TabIndex = 46;
            // 
            // tbCB2
            // 
            this.tbCB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbCB2.Location = new System.Drawing.Point(206, 52);
            this.tbCB2.Name = "tbCB2";
            this.tbCB2.Size = new System.Drawing.Size(38, 20);
            this.tbCB2.TabIndex = 45;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(70, 54);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(86, 13);
            this.label89.TabIndex = 44;
            this.label89.Text = "Character bound";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(27, 237);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(37, 13);
            this.label86.TabIndex = 43;
            this.label86.Text = "Seal 6";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(27, 210);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(37, 13);
            this.label87.TabIndex = 42;
            this.label87.Text = "Seal 5";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(27, 182);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(37, 13);
            this.label88.TabIndex = 41;
            this.label88.Text = "Seal 4";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(27, 157);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(37, 13);
            this.label85.TabIndex = 40;
            this.label85.Text = "Seal 3";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(27, 130);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(37, 13);
            this.label84.TabIndex = 39;
            this.label84.Text = "Seal 2";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(27, 102);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(37, 13);
            this.label83.TabIndex = 38;
            this.label83.Text = "Seal 1";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(196, 374);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(33, 13);
            this.label81.TabIndex = 36;
            this.label81.Text = "Level";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(67, 374);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(40, 13);
            this.label82.TabIndex = 35;
            this.label82.Text = "Skill ID";
            // 
            // tbSkillLevel3
            // 
            this.tbSkillLevel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSkillLevel3.Location = new System.Drawing.Point(235, 372);
            this.tbSkillLevel3.Name = "tbSkillLevel3";
            this.tbSkillLevel3.Size = new System.Drawing.Size(38, 20);
            this.tbSkillLevel3.TabIndex = 34;
            // 
            // tbSkillID3
            // 
            this.tbSkillID3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSkillID3.Location = new System.Drawing.Point(113, 372);
            this.tbSkillID3.Name = "tbSkillID3";
            this.tbSkillID3.Size = new System.Drawing.Size(52, 20);
            this.tbSkillID3.TabIndex = 33;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(196, 334);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(33, 13);
            this.label79.TabIndex = 32;
            this.label79.Text = "Level";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(67, 334);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(40, 13);
            this.label80.TabIndex = 31;
            this.label80.Text = "Skill ID";
            // 
            // tbSkillLevel2
            // 
            this.tbSkillLevel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSkillLevel2.Location = new System.Drawing.Point(235, 332);
            this.tbSkillLevel2.Name = "tbSkillLevel2";
            this.tbSkillLevel2.Size = new System.Drawing.Size(38, 20);
            this.tbSkillLevel2.TabIndex = 30;
            // 
            // tbSkillID2
            // 
            this.tbSkillID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSkillID2.Location = new System.Drawing.Point(113, 332);
            this.tbSkillID2.Name = "tbSkillID2";
            this.tbSkillID2.Size = new System.Drawing.Size(52, 20);
            this.tbSkillID2.TabIndex = 29;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(196, 295);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(33, 13);
            this.label78.TabIndex = 28;
            this.label78.Text = "Level";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(67, 295);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(40, 13);
            this.label77.TabIndex = 27;
            this.label77.Text = "Skill ID";
            // 
            // tbSkillLevel1
            // 
            this.tbSkillLevel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSkillLevel1.Location = new System.Drawing.Point(235, 293);
            this.tbSkillLevel1.Name = "tbSkillLevel1";
            this.tbSkillLevel1.Size = new System.Drawing.Size(38, 20);
            this.tbSkillLevel1.TabIndex = 26;
            // 
            // tbSkillID1
            // 
            this.tbSkillID1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSkillID1.Location = new System.Drawing.Point(113, 293);
            this.tbSkillID1.Name = "tbSkillID1";
            this.tbSkillID1.Size = new System.Drawing.Size(52, 20);
            this.tbSkillID1.TabIndex = 25;
            // 
            // tbSealID6
            // 
            this.tbSealID6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealID6.Location = new System.Drawing.Point(397, 234);
            this.tbSealID6.Name = "tbSealID6";
            this.tbSealID6.ReadOnly = true;
            this.tbSealID6.Size = new System.Drawing.Size(38, 20);
            this.tbSealID6.TabIndex = 24;
            // 
            // cbSealLevel6
            // 
            this.cbSealLevel6.FormattingEnabled = true;
            this.cbSealLevel6.Location = new System.Drawing.Point(288, 234);
            this.cbSealLevel6.MaxDropDownItems = 100;
            this.cbSealLevel6.Name = "cbSealLevel6";
            this.cbSealLevel6.Size = new System.Drawing.Size(99, 21);
            this.cbSealLevel6.TabIndex = 23;
            // 
            // tbSealLevel6
            // 
            this.tbSealLevel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealLevel6.Location = new System.Drawing.Point(441, 234);
            this.tbSealLevel6.Name = "tbSealLevel6";
            this.tbSealLevel6.ReadOnly = true;
            this.tbSealLevel6.Size = new System.Drawing.Size(38, 20);
            this.tbSealLevel6.TabIndex = 22;
            // 
            // cbSealID6
            // 
            this.cbSealID6.FormattingEnabled = true;
            this.cbSealID6.Location = new System.Drawing.Point(70, 235);
            this.cbSealID6.MaxDropDownItems = 100;
            this.cbSealID6.Name = "cbSealID6";
            this.cbSealID6.Size = new System.Drawing.Size(212, 21);
            this.cbSealID6.TabIndex = 21;
            // 
            // tbSealID5
            // 
            this.tbSealID5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealID5.Location = new System.Drawing.Point(397, 207);
            this.tbSealID5.Name = "tbSealID5";
            this.tbSealID5.ReadOnly = true;
            this.tbSealID5.Size = new System.Drawing.Size(38, 20);
            this.tbSealID5.TabIndex = 20;
            // 
            // cbSealLevel5
            // 
            this.cbSealLevel5.FormattingEnabled = true;
            this.cbSealLevel5.Location = new System.Drawing.Point(288, 207);
            this.cbSealLevel5.MaxDropDownItems = 100;
            this.cbSealLevel5.Name = "cbSealLevel5";
            this.cbSealLevel5.Size = new System.Drawing.Size(99, 21);
            this.cbSealLevel5.TabIndex = 19;
            // 
            // tbSealLevel5
            // 
            this.tbSealLevel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealLevel5.Location = new System.Drawing.Point(441, 207);
            this.tbSealLevel5.Name = "tbSealLevel5";
            this.tbSealLevel5.ReadOnly = true;
            this.tbSealLevel5.Size = new System.Drawing.Size(38, 20);
            this.tbSealLevel5.TabIndex = 18;
            // 
            // cbSealID5
            // 
            this.cbSealID5.FormattingEnabled = true;
            this.cbSealID5.Location = new System.Drawing.Point(70, 208);
            this.cbSealID5.MaxDropDownItems = 100;
            this.cbSealID5.Name = "cbSealID5";
            this.cbSealID5.Size = new System.Drawing.Size(212, 21);
            this.cbSealID5.TabIndex = 17;
            // 
            // tbSealID4
            // 
            this.tbSealID4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealID4.Location = new System.Drawing.Point(397, 180);
            this.tbSealID4.Name = "tbSealID4";
            this.tbSealID4.ReadOnly = true;
            this.tbSealID4.Size = new System.Drawing.Size(38, 20);
            this.tbSealID4.TabIndex = 16;
            // 
            // cbSealLevel4
            // 
            this.cbSealLevel4.FormattingEnabled = true;
            this.cbSealLevel4.Location = new System.Drawing.Point(288, 180);
            this.cbSealLevel4.MaxDropDownItems = 100;
            this.cbSealLevel4.Name = "cbSealLevel4";
            this.cbSealLevel4.Size = new System.Drawing.Size(99, 21);
            this.cbSealLevel4.TabIndex = 15;
            // 
            // tbSealLevel4
            // 
            this.tbSealLevel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealLevel4.Location = new System.Drawing.Point(441, 180);
            this.tbSealLevel4.Name = "tbSealLevel4";
            this.tbSealLevel4.ReadOnly = true;
            this.tbSealLevel4.Size = new System.Drawing.Size(38, 20);
            this.tbSealLevel4.TabIndex = 14;
            // 
            // cbSealID4
            // 
            this.cbSealID4.FormattingEnabled = true;
            this.cbSealID4.Location = new System.Drawing.Point(70, 181);
            this.cbSealID4.MaxDropDownItems = 100;
            this.cbSealID4.Name = "cbSealID4";
            this.cbSealID4.Size = new System.Drawing.Size(212, 21);
            this.cbSealID4.TabIndex = 13;
            // 
            // tbSealID3
            // 
            this.tbSealID3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealID3.Location = new System.Drawing.Point(397, 153);
            this.tbSealID3.Name = "tbSealID3";
            this.tbSealID3.ReadOnly = true;
            this.tbSealID3.Size = new System.Drawing.Size(38, 20);
            this.tbSealID3.TabIndex = 12;
            // 
            // cbSealLevel3
            // 
            this.cbSealLevel3.FormattingEnabled = true;
            this.cbSealLevel3.Location = new System.Drawing.Point(288, 153);
            this.cbSealLevel3.MaxDropDownItems = 100;
            this.cbSealLevel3.Name = "cbSealLevel3";
            this.cbSealLevel3.Size = new System.Drawing.Size(99, 21);
            this.cbSealLevel3.TabIndex = 11;
            // 
            // tbSealLevel3
            // 
            this.tbSealLevel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealLevel3.Location = new System.Drawing.Point(441, 153);
            this.tbSealLevel3.Name = "tbSealLevel3";
            this.tbSealLevel3.ReadOnly = true;
            this.tbSealLevel3.Size = new System.Drawing.Size(38, 20);
            this.tbSealLevel3.TabIndex = 10;
            // 
            // cbSealID3
            // 
            this.cbSealID3.FormattingEnabled = true;
            this.cbSealID3.Location = new System.Drawing.Point(70, 154);
            this.cbSealID3.MaxDropDownItems = 100;
            this.cbSealID3.Name = "cbSealID3";
            this.cbSealID3.Size = new System.Drawing.Size(212, 21);
            this.cbSealID3.TabIndex = 9;
            // 
            // tbSealID2
            // 
            this.tbSealID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealID2.Location = new System.Drawing.Point(397, 126);
            this.tbSealID2.Name = "tbSealID2";
            this.tbSealID2.ReadOnly = true;
            this.tbSealID2.Size = new System.Drawing.Size(38, 20);
            this.tbSealID2.TabIndex = 8;
            // 
            // cbSealLevel2
            // 
            this.cbSealLevel2.FormattingEnabled = true;
            this.cbSealLevel2.Location = new System.Drawing.Point(288, 126);
            this.cbSealLevel2.MaxDropDownItems = 100;
            this.cbSealLevel2.Name = "cbSealLevel2";
            this.cbSealLevel2.Size = new System.Drawing.Size(99, 21);
            this.cbSealLevel2.TabIndex = 7;
            // 
            // tbSealLevel2
            // 
            this.tbSealLevel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealLevel2.Location = new System.Drawing.Point(441, 126);
            this.tbSealLevel2.Name = "tbSealLevel2";
            this.tbSealLevel2.ReadOnly = true;
            this.tbSealLevel2.Size = new System.Drawing.Size(38, 20);
            this.tbSealLevel2.TabIndex = 6;
            // 
            // cbSealID2
            // 
            this.cbSealID2.FormattingEnabled = true;
            this.cbSealID2.Location = new System.Drawing.Point(70, 127);
            this.cbSealID2.MaxDropDownItems = 100;
            this.cbSealID2.Name = "cbSealID2";
            this.cbSealID2.Size = new System.Drawing.Size(212, 21);
            this.cbSealID2.TabIndex = 5;
            // 
            // tbSealID1
            // 
            this.tbSealID1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealID1.Location = new System.Drawing.Point(397, 99);
            this.tbSealID1.Name = "tbSealID1";
            this.tbSealID1.ReadOnly = true;
            this.tbSealID1.Size = new System.Drawing.Size(38, 20);
            this.tbSealID1.TabIndex = 3;
            // 
            // cbSealLevel1
            // 
            this.cbSealLevel1.FormattingEnabled = true;
            this.cbSealLevel1.Location = new System.Drawing.Point(288, 99);
            this.cbSealLevel1.MaxDropDownItems = 100;
            this.cbSealLevel1.Name = "cbSealLevel1";
            this.cbSealLevel1.Size = new System.Drawing.Size(99, 21);
            this.cbSealLevel1.TabIndex = 2;
            // 
            // tbSealLevel1
            // 
            this.tbSealLevel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSealLevel1.Location = new System.Drawing.Point(441, 99);
            this.tbSealLevel1.Name = "tbSealLevel1";
            this.tbSealLevel1.ReadOnly = true;
            this.tbSealLevel1.Size = new System.Drawing.Size(38, 20);
            this.tbSealLevel1.TabIndex = 1;
            // 
            // cbSealID1
            // 
            this.cbSealID1.FormattingEnabled = true;
            this.cbSealID1.Location = new System.Drawing.Point(70, 100);
            this.cbSealID1.MaxDropDownItems = 100;
            this.cbSealID1.Name = "cbSealID1";
            this.cbSealID1.Size = new System.Drawing.Size(212, 21);
            this.cbSealID1.TabIndex = 0;
            // 
            // pbSkill3Icon
            // 
            this.pbSkill3Icon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSkill3Icon.Location = new System.Drawing.Point(297, 365);
            this.pbSkill3Icon.Name = "pbSkill3Icon";
            this.pbSkill3Icon.Size = new System.Drawing.Size(32, 32);
            this.pbSkill3Icon.TabIndex = 51;
            this.pbSkill3Icon.TabStop = false;
            // 
            // pbSkill2Icon
            // 
            this.pbSkill2Icon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSkill2Icon.Location = new System.Drawing.Point(297, 327);
            this.pbSkill2Icon.Name = "pbSkill2Icon";
            this.pbSkill2Icon.Size = new System.Drawing.Size(32, 32);
            this.pbSkill2Icon.TabIndex = 49;
            this.pbSkill2Icon.TabStop = false;
            // 
            // pbSkill1Icon
            // 
            this.pbSkill1Icon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSkill1Icon.Location = new System.Drawing.Point(297, 289);
            this.pbSkill1Icon.Name = "pbSkill1Icon";
            this.pbSkill1Icon.Size = new System.Drawing.Size(32, 32);
            this.pbSkill1Icon.TabIndex = 47;
            this.pbSkill1Icon.TabStop = false;
            // 
            // lblCurDataPurple
            // 
            this.lblCurDataPurple.AutoSize = true;
            this.lblCurDataPurple.Location = new System.Drawing.Point(310, 7);
            this.lblCurDataPurple.Name = "lblCurDataPurple";
            this.lblCurDataPurple.Size = new System.Drawing.Size(0, 13);
            this.lblCurDataPurple.TabIndex = 2;
            // 
            // btnPurplePut
            // 
            this.btnPurplePut.Location = new System.Drawing.Point(152, 2);
            this.btnPurplePut.Name = "btnPurplePut";
            this.btnPurplePut.Size = new System.Drawing.Size(152, 23);
            this.btnPurplePut.TabIndex = 1;
            this.btnPurplePut.Text = "Update to database";
            this.btnPurplePut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPurplePut.UseVisualStyleBackColor = true;
            // 
            // btnPurpleGet
            // 
            this.btnPurpleGet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPurpleGet.Location = new System.Drawing.Point(5, 2);
            this.btnPurpleGet.Name = "btnPurpleGet";
            this.btnPurpleGet.Size = new System.Drawing.Size(141, 23);
            this.btnPurpleGet.TabIndex = 0;
            this.btnPurpleGet.Text = "Get from database";
            this.btnPurpleGet.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPurpleGet.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chk3D);
            this.groupBox1.Controls.Add(this.slideLeftRight);
            this.groupBox1.Controls.Add(this.slideUpDown);
            this.groupBox1.Controls.Add(this.slideZoom);
            this.groupBox1.Controls.Add(this.panel3DView);
            this.groupBox1.Location = new System.Drawing.Point(1063, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(378, 430);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "3D View";
            // 
            // chk3D
            // 
            this.chk3D.AutoSize = true;
            this.chk3D.Checked = true;
            this.chk3D.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk3D.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chk3D.Location = new System.Drawing.Point(273, -3);
            this.chk3D.Name = "chk3D";
            this.chk3D.Size = new System.Drawing.Size(99, 17);
            this.chk3D.TabIndex = 39;
            this.chk3D.Text = "Enable 3D View";
            this.chk3D.UseVisualStyleBackColor = true;
            this.chk3D.CheckedChanged += new System.EventHandler(this.chk3D_CheckedChanged);
            // 
            // slideLeftRight
            // 
            this.slideLeftRight.AutoSize = false;
            this.slideLeftRight.Location = new System.Drawing.Point(234, 400);
            this.slideLeftRight.Maximum = 10000;
            this.slideLeftRight.Minimum = -10000;
            this.slideLeftRight.Name = "slideLeftRight";
            this.slideLeftRight.Size = new System.Drawing.Size(85, 25);
            this.slideLeftRight.TabIndex = 3;
            this.slideLeftRight.TickStyle = System.Windows.Forms.TickStyle.None;
            this.slideLeftRight.Scroll += new System.EventHandler(this.slideLeftRight_Scroll);
            // 
            // slideUpDown
            // 
            this.slideUpDown.AutoSize = false;
            this.slideUpDown.Location = new System.Drawing.Point(143, 400);
            this.slideUpDown.Maximum = 10000;
            this.slideUpDown.Minimum = -10000;
            this.slideUpDown.Name = "slideUpDown";
            this.slideUpDown.Size = new System.Drawing.Size(85, 25);
            this.slideUpDown.TabIndex = 2;
            this.slideUpDown.TickStyle = System.Windows.Forms.TickStyle.None;
            this.slideUpDown.Scroll += new System.EventHandler(this.slideUpDown_Scroll);
            // 
            // slideZoom
            // 
            this.slideZoom.AutoSize = false;
            this.slideZoom.Location = new System.Drawing.Point(57, 400);
            this.slideZoom.Maximum = 100000;
            this.slideZoom.Minimum = -10000;
            this.slideZoom.Name = "slideZoom";
            this.slideZoom.Size = new System.Drawing.Size(85, 25);
            this.slideZoom.TabIndex = 1;
            this.slideZoom.TickStyle = System.Windows.Forms.TickStyle.None;
            this.slideZoom.Scroll += new System.EventHandler(this.slideZoom_Scroll);
            // 
            // panel3DView
            // 
            this.panel3DView.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel3DView.Location = new System.Drawing.Point(7, 20);
            this.panel3DView.Name = "panel3DView";
            this.panel3DView.Size = new System.Drawing.Size(371, 371);
            this.panel3DView.TabIndex = 0;
            // 
            // ModPanel
            // 
            this.ModPanel.BackColor = System.Drawing.Color.White;
            this.ModPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ModPanel.Controls.Add(this.chkDbUpdate);
            this.ModPanel.Controls.Add(this.pictureBox1);
            this.ModPanel.Controls.Add(this.label29);
            this.ModPanel.Controls.Add(this.t_DiscardChanges);
            this.ModPanel.Controls.Add(this.t_SaveRecord);
            this.ModPanel.Location = new System.Drawing.Point(287, 557);
            this.ModPanel.Name = "ModPanel";
            this.ModPanel.Size = new System.Drawing.Size(687, 30);
            this.ModPanel.TabIndex = 20;
            this.ModPanel.Visible = false;
            // 
            // chkDbUpdate
            // 
            this.chkDbUpdate.AutoSize = true;
            this.chkDbUpdate.Location = new System.Drawing.Point(290, 7);
            this.chkDbUpdate.Name = "chkDbUpdate";
            this.chkDbUpdate.Size = new System.Drawing.Size(131, 17);
            this.chkDbUpdate.TabIndex = 18;
            this.chkDbUpdate.Text = "Auto update database";
            this.chkDbUpdate.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.Wykrzyknik;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(7, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(17, 17);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DarkRed;
            this.label29.Location = new System.Drawing.Point(30, 8);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(233, 13);
            this.label29.TabIndex = 16;
            this.label29.Text = "Changes have been made to this record";
            // 
            // t_DiscardChanges
            // 
            this.t_DiscardChanges.Location = new System.Drawing.Point(434, 3);
            this.t_DiscardChanges.Name = "t_DiscardChanges";
            this.t_DiscardChanges.Size = new System.Drawing.Size(126, 23);
            this.t_DiscardChanges.TabIndex = 15;
            this.t_DiscardChanges.Text = "&Discard Changes";
            this.t_DiscardChanges.UseVisualStyleBackColor = true;
            // 
            // t_SaveRecord
            // 
            this.t_SaveRecord.Location = new System.Drawing.Point(566, 3);
            this.t_SaveRecord.Name = "t_SaveRecord";
            this.t_SaveRecord.Size = new System.Drawing.Size(112, 23);
            this.t_SaveRecord.TabIndex = 14;
            this.t_SaveRecord.Text = "&Save all Changes";
            this.t_SaveRecord.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search";
            // 
            // SearchText
            // 
            this.SearchText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchText.Location = new System.Drawing.Point(55, 9);
            this.SearchText.Name = "SearchText";
            this.SearchText.Size = new System.Drawing.Size(207, 20);
            this.SearchText.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.status});
            this.statusStrip1.Location = new System.Drawing.Point(0, 591);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1453, 22);
            this.statusStrip1.TabIndex = 22;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // status
            // 
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(0, 17);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 40;
            this.label15.Text = "Search";
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Location = new System.Drawing.Point(56, 19);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(207, 20);
            this.textBox7.TabIndex = 39;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox7);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Location = new System.Drawing.Point(12, 27);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(269, 47);
            this.groupBox6.TabIndex = 41;
            this.groupBox6.TabStop = false;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.ItemListBox);
            this.groupBox14.Location = new System.Drawing.Point(12, 80);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(269, 465);
            this.groupBox14.TabIndex = 42;
            this.groupBox14.TabStop = false;
            // 
            // ItemListBox
            // 
            this.ItemListBox.Location = new System.Drawing.Point(4, 16);
            this.ItemListBox.Name = "ItemListBox";
            this.ItemListBox.Size = new System.Drawing.Size(259, 433);
            this.ItemListBox.TabIndex = 1;
            this.ItemListBox.SelectedIndexChanged += new System.EventHandler(this.ItemListBox_SelectedIndexChanged);
            // 
            // t_DeleteItem
            // 
            this.t_DeleteItem.Location = new System.Drawing.Point(196, 561);
            this.t_DeleteItem.Name = "t_DeleteItem";
            this.t_DeleteItem.Size = new System.Drawing.Size(87, 23);
            this.t_DeleteItem.TabIndex = 45;
            this.t_DeleteItem.Text = "Delete Item";
            this.t_DeleteItem.UseVisualStyleBackColor = true;
            // 
            // t_CopyToNew
            // 
            this.t_CopyToNew.Location = new System.Drawing.Point(105, 561);
            this.t_CopyToNew.Name = "t_CopyToNew";
            this.t_CopyToNew.Size = new System.Drawing.Size(85, 23);
            this.t_CopyToNew.TabIndex = 44;
            this.t_CopyToNew.Text = "Copy to New";
            this.t_CopyToNew.UseVisualStyleBackColor = true;
            // 
            // t_NewItem
            // 
            this.t_NewItem.Location = new System.Drawing.Point(24, 561);
            this.t_NewItem.Name = "t_NewItem";
            this.t_NewItem.Size = new System.Drawing.Size(75, 23);
            this.t_NewItem.TabIndex = 43;
            this.t_NewItem.Text = "New Item";
            this.t_NewItem.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tb_castleWar
            // 
            this.tb_castleWar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_castleWar.Location = new System.Drawing.Point(537, 273);
            this.tb_castleWar.Name = "tb_castleWar";
            this.tb_castleWar.Size = new System.Drawing.Size(51, 20);
            this.tb_castleWar.TabIndex = 63;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(497, 275);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 13);
            this.label16.TabIndex = 64;
            this.label16.Text = "Castle:";
            // 
            // ItemAll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1453, 613);
            this.Controls.Add(this.t_DeleteItem);
            this.Controls.Add(this.t_CopyToNew);
            this.Controls.Add(this.t_NewItem);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.ModPanel);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.menuStrip1);
            this.Name = "ItemAll";
            this.Text = "ItemAll";
            this.Load += new System.EventHandler(this.ItemAll_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t_Icon)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CraftGrid)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSkill3Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSkill2Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSkill1Icon)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slideLeftRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slideUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slideZoom)).EndInit();
            this.ModPanel.ResumeLayout(false);
            this.ModPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemnameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hTMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertQueryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateQueryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iconViewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemFlagBuilderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mySQLConnectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPDATEThisRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNSERTThisRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configConnectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem massActionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNSERTALLNotExistingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPDATEINSERTThisRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gETALLFromDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateAllNamesToDBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateAllFlagsToDBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateAllPicsToDBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateAllNamesInDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem getRecordsFromOtherFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateAllPricesInDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getPhpItemlistToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeAllIconsAbove9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeAllIconsAbove14ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getAllFlagsFromOtherFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getIconsFromOtherFileToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chk3D;
        private System.Windows.Forms.TrackBar slideLeftRight;
        private System.Windows.Forms.TrackBar slideUpDown;
        private System.Windows.Forms.TrackBar slideZoom;
        private System.Windows.Forms.Panel panel3DView;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox t_SMC;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox t_Description;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox t_ItemName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox t_ItemID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox t_Icon;
        private System.Windows.Forms.LinkLabel t_iconpick;
        private System.Windows.Forms.TextBox t_IconColumn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox t_IconRow;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox t_IconID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox t_EffectDamage;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox t_EffectAttack;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox t_EffectNormal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox t_Set5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox t_Set4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox t_Set3;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox t_Set2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox t_Set1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox t_Price;
        private System.Windows.Forms.TextBox t_Weight;
        private System.Windows.Forms.TextBox t_Level;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox t_RareOptionRate;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox t_RareOptionID;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox t_maxuse;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox t_Flag;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox t_WearingPosCombo;
        private System.Windows.Forms.TextBox t_WearingPos;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox t_Class;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox t_SubTypeCombo;
        private System.Windows.Forms.TextBox t_SubType;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox t_TypeCombo;
        private System.Windows.Forms.TextBox t_Type;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView CraftGrid;
        private System.Windows.Forms.DataGridViewImageColumn ItemIcon;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button t_CraftItemSearch10;
        private System.Windows.Forms.TextBox t_CraftItemAmount10;
        private System.Windows.Forms.TextBox t_CraftItemID10;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox t_CraftItemAmount9;
        private System.Windows.Forms.TextBox t_CraftItemID9;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox t_CraftItemAmount8;
        private System.Windows.Forms.TextBox t_CraftItemID8;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox t_CraftItemAmount7;
        private System.Windows.Forms.TextBox t_CraftItemID7;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox t_CraftItemAmount6;
        private System.Windows.Forms.TextBox t_CraftItemID6;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox t_CraftItemAmount5;
        private System.Windows.Forms.TextBox t_CraftItemID5;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox t_CraftItemAmount4;
        private System.Windows.Forms.TextBox t_CraftItemID4;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox t_CraftItemAmount3;
        private System.Windows.Forms.TextBox t_CraftItemID3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox t_CraftItemAmount2;
        private System.Windows.Forms.TextBox t_CraftItemID2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox t_CraftItemAmount1;
        private System.Windows.Forms.TextBox t_CraftItemID1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button t_CraftItemSearch9;
        private System.Windows.Forms.Button t_CraftItemSearch8;
        private System.Windows.Forms.Button t_CraftItemSearch7;
        private System.Windows.Forms.Button t_CraftItemSearch6;
        private System.Windows.Forms.Button t_CraftItemSearch5;
        private System.Windows.Forms.Button t_CraftItemSearch4;
        private System.Windows.Forms.Button t_CraftItemSearch3;
        private System.Windows.Forms.Button t_CraftItemSearch2;
        private System.Windows.Forms.Button t_CraftItemSearch1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox t_CraftSkill2Level;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox t_CraftSkill1Level;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox t_CraftSkill2ID;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox t_CraftSkill1ID;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnRareSearch9;
        private System.Windows.Forms.TextBox tbRareOpt9;
        private System.Windows.Forms.TextBox tbRareChance9;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button btnRareSearch8;
        private System.Windows.Forms.TextBox tbRareOpt8;
        private System.Windows.Forms.TextBox tbRareChance8;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Button btnRareSearch7;
        private System.Windows.Forms.TextBox tbRareOpt7;
        private System.Windows.Forms.TextBox tbRareChance7;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Button btnRareSearch6;
        private System.Windows.Forms.TextBox tbRareOpt6;
        private System.Windows.Forms.TextBox tbRareChance6;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button btnRareSearch5;
        private System.Windows.Forms.TextBox tbRareOpt5;
        private System.Windows.Forms.TextBox tbRareChance5;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Button btnRareSearch4;
        private System.Windows.Forms.TextBox tbRareOpt4;
        private System.Windows.Forms.TextBox tbRareChance4;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button btnRareSearch3;
        private System.Windows.Forms.TextBox tbRareOpt3;
        private System.Windows.Forms.TextBox tbRareChance3;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button btnRareSearch2;
        private System.Windows.Forms.TextBox tbRareOpt2;
        private System.Windows.Forms.TextBox tbRareChance2;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Button btnRareSearch1;
        private System.Windows.Forms.TextBox tbRareOpt1;
        private System.Windows.Forms.TextBox tbRareChance1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button btnRareSearch0;
        private System.Windows.Forms.TextBox tbRareOpt0;
        private System.Windows.Forms.TextBox tbRareChance0;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnRareDbPut;
        private System.Windows.Forms.Button btnRareDbGet;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnSearchSkill3;
        private System.Windows.Forms.Button btnSearchSkill2;
        private System.Windows.Forms.Button btnSearchSkill1;
        private System.Windows.Forms.TextBox tbCB1;
        private System.Windows.Forms.TextBox tbCB2;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label lblCurDataPurple;
        private System.Windows.Forms.Button btnPurplePut;
        private System.Windows.Forms.Button btnPurpleGet;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox tbSkillLevel3;
        private System.Windows.Forms.TextBox tbSkillID3;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox tbSkillLevel2;
        private System.Windows.Forms.TextBox tbSkillID2;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox tbSkillLevel1;
        private System.Windows.Forms.TextBox tbSkillID1;
        private System.Windows.Forms.TextBox tbSealID6;
        private System.Windows.Forms.ComboBox cbSealLevel6;
        private System.Windows.Forms.TextBox tbSealLevel6;
        private System.Windows.Forms.ComboBox cbSealID6;
        private System.Windows.Forms.TextBox tbSealID5;
        private System.Windows.Forms.ComboBox cbSealLevel5;
        private System.Windows.Forms.TextBox tbSealLevel5;
        private System.Windows.Forms.ComboBox cbSealID5;
        private System.Windows.Forms.TextBox tbSealID4;
        private System.Windows.Forms.ComboBox cbSealLevel4;
        private System.Windows.Forms.TextBox tbSealLevel4;
        private System.Windows.Forms.ComboBox cbSealID4;
        private System.Windows.Forms.TextBox tbSealID3;
        private System.Windows.Forms.ComboBox cbSealLevel3;
        private System.Windows.Forms.TextBox tbSealLevel3;
        private System.Windows.Forms.ComboBox cbSealID3;
        private System.Windows.Forms.TextBox tbSealID2;
        private System.Windows.Forms.ComboBox cbSealLevel2;
        private System.Windows.Forms.TextBox tbSealLevel2;
        private System.Windows.Forms.ComboBox cbSealID2;
        private System.Windows.Forms.TextBox tbSealID1;
        private System.Windows.Forms.ComboBox cbSealLevel1;
        private System.Windows.Forms.TextBox tbSealLevel1;
        private System.Windows.Forms.ComboBox cbSealID1;
        private System.Windows.Forms.PictureBox pbSkill3Icon;
        private System.Windows.Forms.PictureBox pbSkill2Icon;
        private System.Windows.Forms.PictureBox pbSkill1Icon;
        private System.Windows.Forms.Panel ModPanel;
        private System.Windows.Forms.CheckBox chkDbUpdate;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button t_DiscardChanges;
        private System.Windows.Forms.Button t_SaveRecord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SearchText;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel status;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox t_rvr_Grade;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox t_rvr_Value;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox t_quest_tigger;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox t_quest_tigger_count;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button btnPercent2Add;
        private System.Windows.Forms.Button btnPercent1Add;
        private System.Windows.Forms.Button btnPercentAdd;
        private System.Windows.Forms.TextBox TbPercent2;
        private System.Windows.Forms.TextBox TbPercent1;
        private System.Windows.Forms.TextBox TbPercent;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox t_Num4;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox t_Num0;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox t_Num1;
        private System.Windows.Forms.TextBox t_Num3;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox t_Num2;
        private System.Windows.Forms.TextBox t_Level2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ListBox ItemListBox;
        private System.Windows.Forms.Button t_DeleteItem;
        private System.Windows.Forms.Button t_CopyToNew;
        private System.Windows.Forms.Button t_NewItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox checkBox_class8;
        private System.Windows.Forms.CheckBox checkBox_class7;
        private System.Windows.Forms.CheckBox checkBox_class6;
        private System.Windows.Forms.CheckBox checkBox_class5;
        private System.Windows.Forms.CheckBox checkBox_class4;
        private System.Windows.Forms.CheckBox checkBox_class3;
        private System.Windows.Forms.CheckBox checkBox_class2;
        private System.Windows.Forms.CheckBox checkBox_class1;
        private System.Windows.Forms.CheckBox checkBox_class0;
        private System.Windows.Forms.TextBox tb_castleWar;
        private System.Windows.Forms.Label label16;
    }
}