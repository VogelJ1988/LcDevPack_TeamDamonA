﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.ExChange
{
    public class tbl_exchange
    {
        //structure for exchange table
        public int index;
        public int npcidx;
        public int result_itemIndex;
        public int result_itemCount;
        public int source_itemIndex0;
        public int source_itemIndex1;
        public int source_itemIndex2;
        public int source_itemIndex3;
        public int source_item_Index4;
        public int source_itemCount0;
        public int source_itemCount1;
        public int source_itemCount2;
        public int source_itemCount3;
        public int source_itemCount4;
    }
}
