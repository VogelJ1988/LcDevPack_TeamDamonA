﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.ExChange
{
    partial class ExChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToLodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbFileCol4 = new System.Windows.Forms.TextBox();
            this.tbFileRow4 = new System.Windows.Forms.TextBox();
            this.tbFileID4 = new System.Windows.Forms.TextBox();
            this.tbFileCol3 = new System.Windows.Forms.TextBox();
            this.tbFileRow3 = new System.Windows.Forms.TextBox();
            this.tbFileID3 = new System.Windows.Forms.TextBox();
            this.tbFileCol2 = new System.Windows.Forms.TextBox();
            this.tbFileRow2 = new System.Windows.Forms.TextBox();
            this.tbFileID2 = new System.Windows.Forms.TextBox();
            this.tbFileCol1 = new System.Windows.Forms.TextBox();
            this.tbFileRow1 = new System.Windows.Forms.TextBox();
            this.tbFileID1 = new System.Windows.Forms.TextBox();
            this.tbFileCol0 = new System.Windows.Forms.TextBox();
            this.tbFileRow0 = new System.Windows.Forms.TextBox();
            this.tbFileID0 = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_source_itemIndex4 = new System.Windows.Forms.TextBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_source_itemIndex3 = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_source_itemIndex2 = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_source_itemIndex1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_source_itemIndex0 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PbSelectID1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tbFileID = new System.Windows.Forms.TextBox();
            this.tbFileRow = new System.Windows.Forms.TextBox();
            this.tbFileCol = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tb_count_itemIndex4 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tb_count_itemIndex3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tb_count_itemIndex2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tb_count_itemIndex1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tb_count_itemIndex0 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbSelectID1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.listBox1);
            this.groupBox3.Location = new System.Drawing.Point(12, 27);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(237, 475);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ExChange NPC";
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(131, 446);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(6, 446);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 14);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(225, 420);
            this.listBox1.TabIndex = 1;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.AllowMerge = false;
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(811, 24);
            this.menuStrip1.TabIndex = 32;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToLodToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToLodToolStripMenuItem
            // 
            this.saveToLodToolStripMenuItem.Name = "saveToLodToolStripMenuItem";
            this.saveToLodToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveToLodToolStripMenuItem.Text = "Save to lod";
            this.saveToLodToolStripMenuItem.Click += new System.EventHandler(this.saveToLodToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 503);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(811, 22);
            this.statusStrip1.TabIndex = 50;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Ready";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox4.Controls.Add(this.tbFileCol4);
            this.groupBox4.Controls.Add(this.tbFileRow4);
            this.groupBox4.Controls.Add(this.tbFileID4);
            this.groupBox4.Controls.Add(this.tbFileCol3);
            this.groupBox4.Controls.Add(this.tbFileRow3);
            this.groupBox4.Controls.Add(this.tbFileID3);
            this.groupBox4.Controls.Add(this.tbFileCol2);
            this.groupBox4.Controls.Add(this.tbFileRow2);
            this.groupBox4.Controls.Add(this.tbFileID2);
            this.groupBox4.Controls.Add(this.tbFileCol1);
            this.groupBox4.Controls.Add(this.tbFileRow1);
            this.groupBox4.Controls.Add(this.tbFileID1);
            this.groupBox4.Controls.Add(this.tbFileCol0);
            this.groupBox4.Controls.Add(this.tbFileRow0);
            this.groupBox4.Controls.Add(this.tbFileID0);
            this.groupBox4.Controls.Add(this.pictureBox10);
            this.groupBox4.Controls.Add(this.pictureBox11);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.tb_source_itemIndex4);
            this.groupBox4.Controls.Add(this.pictureBox8);
            this.groupBox4.Controls.Add(this.pictureBox9);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.tb_source_itemIndex3);
            this.groupBox4.Controls.Add(this.pictureBox6);
            this.groupBox4.Controls.Add(this.pictureBox7);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.tb_source_itemIndex2);
            this.groupBox4.Controls.Add(this.pictureBox4);
            this.groupBox4.Controls.Add(this.pictureBox5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.tb_source_itemIndex1);
            this.groupBox4.Controls.Add(this.pictureBox2);
            this.groupBox4.Controls.Add(this.pictureBox3);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.tb_source_itemIndex0);
            this.groupBox4.Location = new System.Drawing.Point(258, 184);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(187, 220);
            this.groupBox4.TabIndex = 51;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Items Need";
            // 
            // tbFileCol4
            // 
            this.tbFileCol4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileCol4.Location = new System.Drawing.Point(241, 182);
            this.tbFileCol4.Name = "tbFileCol4";
            this.tbFileCol4.Size = new System.Drawing.Size(13, 20);
            this.tbFileCol4.TabIndex = 148;
            this.tbFileCol4.Visible = false;
            // 
            // tbFileRow4
            // 
            this.tbFileRow4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileRow4.Location = new System.Drawing.Point(216, 182);
            this.tbFileRow4.Name = "tbFileRow4";
            this.tbFileRow4.Size = new System.Drawing.Size(19, 20);
            this.tbFileRow4.TabIndex = 147;
            this.tbFileRow4.Visible = false;
            // 
            // tbFileID4
            // 
            this.tbFileID4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileID4.Location = new System.Drawing.Point(189, 182);
            this.tbFileID4.Name = "tbFileID4";
            this.tbFileID4.Size = new System.Drawing.Size(21, 20);
            this.tbFileID4.TabIndex = 146;
            this.tbFileID4.Visible = false;
            // 
            // tbFileCol3
            // 
            this.tbFileCol3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileCol3.Location = new System.Drawing.Point(241, 144);
            this.tbFileCol3.Name = "tbFileCol3";
            this.tbFileCol3.Size = new System.Drawing.Size(13, 20);
            this.tbFileCol3.TabIndex = 145;
            this.tbFileCol3.Visible = false;
            // 
            // tbFileRow3
            // 
            this.tbFileRow3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileRow3.Location = new System.Drawing.Point(216, 144);
            this.tbFileRow3.Name = "tbFileRow3";
            this.tbFileRow3.Size = new System.Drawing.Size(19, 20);
            this.tbFileRow3.TabIndex = 144;
            this.tbFileRow3.Visible = false;
            // 
            // tbFileID3
            // 
            this.tbFileID3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileID3.Location = new System.Drawing.Point(189, 144);
            this.tbFileID3.Name = "tbFileID3";
            this.tbFileID3.Size = new System.Drawing.Size(21, 20);
            this.tbFileID3.TabIndex = 143;
            this.tbFileID3.Visible = false;
            // 
            // tbFileCol2
            // 
            this.tbFileCol2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileCol2.Location = new System.Drawing.Point(241, 106);
            this.tbFileCol2.Name = "tbFileCol2";
            this.tbFileCol2.Size = new System.Drawing.Size(13, 20);
            this.tbFileCol2.TabIndex = 142;
            this.tbFileCol2.Visible = false;
            // 
            // tbFileRow2
            // 
            this.tbFileRow2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileRow2.Location = new System.Drawing.Point(216, 106);
            this.tbFileRow2.Name = "tbFileRow2";
            this.tbFileRow2.Size = new System.Drawing.Size(19, 20);
            this.tbFileRow2.TabIndex = 141;
            this.tbFileRow2.Visible = false;
            // 
            // tbFileID2
            // 
            this.tbFileID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileID2.Location = new System.Drawing.Point(189, 106);
            this.tbFileID2.Name = "tbFileID2";
            this.tbFileID2.Size = new System.Drawing.Size(21, 20);
            this.tbFileID2.TabIndex = 140;
            this.tbFileID2.Visible = false;
            // 
            // tbFileCol1
            // 
            this.tbFileCol1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileCol1.Location = new System.Drawing.Point(241, 68);
            this.tbFileCol1.Name = "tbFileCol1";
            this.tbFileCol1.Size = new System.Drawing.Size(13, 20);
            this.tbFileCol1.TabIndex = 139;
            this.tbFileCol1.Visible = false;
            // 
            // tbFileRow1
            // 
            this.tbFileRow1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileRow1.Location = new System.Drawing.Point(216, 68);
            this.tbFileRow1.Name = "tbFileRow1";
            this.tbFileRow1.Size = new System.Drawing.Size(19, 20);
            this.tbFileRow1.TabIndex = 138;
            this.tbFileRow1.Visible = false;
            // 
            // tbFileID1
            // 
            this.tbFileID1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileID1.Location = new System.Drawing.Point(189, 68);
            this.tbFileID1.Name = "tbFileID1";
            this.tbFileID1.Size = new System.Drawing.Size(21, 20);
            this.tbFileID1.TabIndex = 137;
            this.tbFileID1.Visible = false;
            // 
            // tbFileCol0
            // 
            this.tbFileCol0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileCol0.Location = new System.Drawing.Point(241, 30);
            this.tbFileCol0.Name = "tbFileCol0";
            this.tbFileCol0.Size = new System.Drawing.Size(13, 20);
            this.tbFileCol0.TabIndex = 136;
            this.tbFileCol0.Visible = false;
            // 
            // tbFileRow0
            // 
            this.tbFileRow0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileRow0.Location = new System.Drawing.Point(216, 30);
            this.tbFileRow0.Name = "tbFileRow0";
            this.tbFileRow0.Size = new System.Drawing.Size(19, 20);
            this.tbFileRow0.TabIndex = 135;
            this.tbFileRow0.Visible = false;
            // 
            // tbFileID0
            // 
            this.tbFileID0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileID0.Location = new System.Drawing.Point(189, 30);
            this.tbFileID0.Name = "tbFileID0";
            this.tbFileID0.Size = new System.Drawing.Size(21, 20);
            this.tbFileID0.TabIndex = 134;
            this.tbFileID0.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox10.Location = new System.Drawing.Point(123, 180);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(22, 22);
            this.pictureBox10.TabIndex = 133;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.White;
            this.pictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox11.Location = new System.Drawing.Point(151, 176);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(32, 32);
            this.pictureBox11.TabIndex = 132;
            this.pictureBox11.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 13);
            this.label11.TabIndex = 131;
            this.label11.Text = "Item";
            // 
            // tb_source_itemIndex4
            // 
            this.tb_source_itemIndex4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_source_itemIndex4.Location = new System.Drawing.Point(67, 180);
            this.tb_source_itemIndex4.Name = "tb_source_itemIndex4";
            this.tb_source_itemIndex4.Size = new System.Drawing.Size(50, 20);
            this.tb_source_itemIndex4.TabIndex = 130;
            this.tb_source_itemIndex4.TextChanged += new System.EventHandler(this.tb_source_itemIndex4_TextChanged);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(123, 142);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(22, 22);
            this.pictureBox8.TabIndex = 129;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.White;
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox9.Location = new System.Drawing.Point(151, 138);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(32, 32);
            this.pictureBox9.TabIndex = 128;
            this.pictureBox9.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 13);
            this.label9.TabIndex = 127;
            this.label9.Text = "Item";
            // 
            // tb_source_itemIndex3
            // 
            this.tb_source_itemIndex3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_source_itemIndex3.Location = new System.Drawing.Point(67, 142);
            this.tb_source_itemIndex3.Name = "tb_source_itemIndex3";
            this.tb_source_itemIndex3.Size = new System.Drawing.Size(50, 20);
            this.tb_source_itemIndex3.TabIndex = 126;
            this.tb_source_itemIndex3.TextChanged += new System.EventHandler(this.tb_source_itemIndex3_TextChanged);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(123, 104);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(22, 22);
            this.pictureBox6.TabIndex = 125;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.White;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(151, 100);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(32, 32);
            this.pictureBox7.TabIndex = 124;
            this.pictureBox7.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 123;
            this.label7.Text = "Item";
            // 
            // tb_source_itemIndex2
            // 
            this.tb_source_itemIndex2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_source_itemIndex2.Location = new System.Drawing.Point(67, 104);
            this.tb_source_itemIndex2.Name = "tb_source_itemIndex2";
            this.tb_source_itemIndex2.Size = new System.Drawing.Size(50, 20);
            this.tb_source_itemIndex2.TabIndex = 122;
            this.tb_source_itemIndex2.TextChanged += new System.EventHandler(this.tb_source_itemIndex2_TextChanged);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(123, 66);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(22, 22);
            this.pictureBox4.TabIndex = 121;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(151, 62);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 32);
            this.pictureBox5.TabIndex = 120;
            this.pictureBox5.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 119;
            this.label6.Text = "Item";
            // 
            // tb_source_itemIndex1
            // 
            this.tb_source_itemIndex1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_source_itemIndex1.Location = new System.Drawing.Point(67, 66);
            this.tb_source_itemIndex1.Name = "tb_source_itemIndex1";
            this.tb_source_itemIndex1.Size = new System.Drawing.Size(50, 20);
            this.tb_source_itemIndex1.TabIndex = 118;
            this.tb_source_itemIndex1.TextChanged += new System.EventHandler(this.tb_source_itemIndex1_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(123, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 22);
            this.pictureBox2.TabIndex = 117;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(151, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 32);
            this.pictureBox3.TabIndex = 116;
            this.pictureBox3.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 115;
            this.label5.Text = "Item";
            // 
            // tb_source_itemIndex0
            // 
            this.tb_source_itemIndex0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_source_itemIndex0.Location = new System.Drawing.Point(67, 28);
            this.tb_source_itemIndex0.Name = "tb_source_itemIndex0";
            this.tb_source_itemIndex0.Size = new System.Drawing.Size(50, 20);
            this.tb_source_itemIndex0.TabIndex = 114;
            this.tb_source_itemIndex0.TextChanged += new System.EventHandler(this.tb_source_itemIndex0_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.PbSelectID1);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox9);
            this.groupBox2.Location = new System.Drawing.Point(530, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(183, 137);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Result Gift";
            // 
            // PbSelectID1
            // 
            this.PbSelectID1.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.PbSelectID1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbSelectID1.Location = new System.Drawing.Point(115, 23);
            this.PbSelectID1.Name = "PbSelectID1";
            this.PbSelectID1.Size = new System.Drawing.Size(22, 22);
            this.PbSelectID1.TabIndex = 113;
            this.PbSelectID1.TabStop = false;
            this.PbSelectID1.Click += new System.EventHandler(this.PbSelectID1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(143, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.TabIndex = 112;
            this.pictureBox1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 13);
            this.label10.TabIndex = 44;
            this.label10.Text = "Item";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Count";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(59, 23);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(50, 20);
            this.textBox6.TabIndex = 40;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Location = new System.Drawing.Point(59, 78);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(82, 20);
            this.textBox9.TabIndex = 37;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Location = new System.Drawing.Point(258, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 137);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Main";
            // 
            // textBox11
            // 
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Location = new System.Drawing.Point(79, 0);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(50, 20);
            this.textBox11.TabIndex = 39;
            this.textBox11.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 37;
            this.label4.Text = "Npc Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "Npc ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(144, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enable:";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(204, 23);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(50, 20);
            this.textBox2.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Index:";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(79, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(50, 20);
            this.textBox1.TabIndex = 31;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(79, 52);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(50, 20);
            this.textBox3.TabIndex = 33;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(79, 78);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(175, 20);
            this.textBox4.TabIndex = 34;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(705, 479);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 23);
            this.button2.TabIndex = 54;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tbFileID
            // 
            this.tbFileID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileID.Location = new System.Drawing.Point(719, 93);
            this.tbFileID.Name = "tbFileID";
            this.tbFileID.Size = new System.Drawing.Size(50, 20);
            this.tbFileID.TabIndex = 55;
            this.tbFileID.Visible = false;
            // 
            // tbFileRow
            // 
            this.tbFileRow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileRow.Location = new System.Drawing.Point(719, 119);
            this.tbFileRow.Name = "tbFileRow";
            this.tbFileRow.Size = new System.Drawing.Size(50, 20);
            this.tbFileRow.TabIndex = 56;
            this.tbFileRow.Visible = false;
            // 
            // tbFileCol
            // 
            this.tbFileCol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFileCol.Location = new System.Drawing.Point(719, 145);
            this.tbFileCol.Name = "tbFileCol";
            this.tbFileCol.Size = new System.Drawing.Size(50, 20);
            this.tbFileCol.TabIndex = 57;
            this.tbFileCol.Visible = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.tb_count_itemIndex4);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.tb_count_itemIndex3);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.tb_count_itemIndex2);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.tb_count_itemIndex1);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.tb_count_itemIndex0);
            this.groupBox5.Location = new System.Drawing.Point(451, 184);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(139, 220);
            this.groupBox5.TabIndex = 58;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Items Count Need";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 182);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 131;
            this.label12.Text = "Count";
            // 
            // tb_count_itemIndex4
            // 
            this.tb_count_itemIndex4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_count_itemIndex4.Location = new System.Drawing.Point(67, 180);
            this.tb_count_itemIndex4.Name = "tb_count_itemIndex4";
            this.tb_count_itemIndex4.Size = new System.Drawing.Size(50, 20);
            this.tb_count_itemIndex4.TabIndex = 130;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 144);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 127;
            this.label13.Text = "Count";
            // 
            // tb_count_itemIndex3
            // 
            this.tb_count_itemIndex3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_count_itemIndex3.Location = new System.Drawing.Point(67, 142);
            this.tb_count_itemIndex3.Name = "tb_count_itemIndex3";
            this.tb_count_itemIndex3.Size = new System.Drawing.Size(50, 20);
            this.tb_count_itemIndex3.TabIndex = 126;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 106);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 13);
            this.label14.TabIndex = 123;
            this.label14.Text = "Count";
            // 
            // tb_count_itemIndex2
            // 
            this.tb_count_itemIndex2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_count_itemIndex2.Location = new System.Drawing.Point(67, 104);
            this.tb_count_itemIndex2.Name = "tb_count_itemIndex2";
            this.tb_count_itemIndex2.Size = new System.Drawing.Size(50, 20);
            this.tb_count_itemIndex2.TabIndex = 122;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 68);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 119;
            this.label15.Text = "Count";
            // 
            // tb_count_itemIndex1
            // 
            this.tb_count_itemIndex1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_count_itemIndex1.Location = new System.Drawing.Point(67, 66);
            this.tb_count_itemIndex1.Name = "tb_count_itemIndex1";
            this.tb_count_itemIndex1.Size = new System.Drawing.Size(50, 20);
            this.tb_count_itemIndex1.TabIndex = 118;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 115;
            this.label16.Text = "Count";
            // 
            // tb_count_itemIndex0
            // 
            this.tb_count_itemIndex0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_count_itemIndex0.Location = new System.Drawing.Point(67, 28);
            this.tb_count_itemIndex0.Name = "tb_count_itemIndex0";
            this.tb_count_itemIndex0.Size = new System.Drawing.Size(50, 20);
            this.tb_count_itemIndex0.TabIndex = 114;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Red;
            this.checkBox1.Location = new System.Drawing.Point(657, 483);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(42, 17);
            this.checkBox1.TabIndex = 59;
            this.checkBox1.Text = "NO";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(549, 484);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 13);
            this.label17.TabIndex = 60;
            this.label17.Text = "Auto In Database ->";
            // 
            // ExChange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 525);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.tbFileCol);
            this.Controls.Add(this.tbFileRow);
            this.Controls.Add(this.tbFileID);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox3);
            this.Name = "ExChange";
            this.Text = "ExChange";
            this.Load += new System.EventHandler(this.ExChange_Load);
            this.groupBox3.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbSelectID1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox PbSelectID1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox tbFileID;
        private System.Windows.Forms.TextBox tbFileRow;
        private System.Windows.Forms.TextBox tbFileCol;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_source_itemIndex0;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_source_itemIndex4;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_source_itemIndex3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_source_itemIndex2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_source_itemIndex1;
        private System.Windows.Forms.TextBox tbFileCol0;
        private System.Windows.Forms.TextBox tbFileRow0;
        private System.Windows.Forms.TextBox tbFileID0;
        private System.Windows.Forms.TextBox tbFileCol4;
        private System.Windows.Forms.TextBox tbFileRow4;
        private System.Windows.Forms.TextBox tbFileID4;
        private System.Windows.Forms.TextBox tbFileCol3;
        private System.Windows.Forms.TextBox tbFileRow3;
        private System.Windows.Forms.TextBox tbFileID3;
        private System.Windows.Forms.TextBox tbFileCol2;
        private System.Windows.Forms.TextBox tbFileRow2;
        private System.Windows.Forms.TextBox tbFileID2;
        private System.Windows.Forms.TextBox tbFileCol1;
        private System.Windows.Forms.TextBox tbFileRow1;
        private System.Windows.Forms.TextBox tbFileID1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tb_count_itemIndex4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tb_count_itemIndex3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb_count_itemIndex2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tb_count_itemIndex1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tb_count_itemIndex0;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToLodToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label17;
    }
}