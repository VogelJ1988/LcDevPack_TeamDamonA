﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.ExChange
{

    internal class LoadLod
    {

    }
}
