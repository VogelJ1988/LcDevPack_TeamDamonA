﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.ExChange
{
    public class t_EXChange
    {
        public int IndexID { get; set; }
        public int Enable;
        public int NpcIndex;
        public int ResultItemIdx;
        public int ResultItemCount;
        public int SourceItemIndex0;
        public int SourceItemIndex1;
        public int SourceItemIndex2;
        public int SourceItemIndex3;
        public int SourceItemIndex4;
        public int SourceItemCount0;
        public int SourceItemCount1;
        public int SourceItemCount2;
        public int SourceItemCount3;
        public int SourceItemCount4;
    }
}
