﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.t_attkpet
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public class t_attkpet
    {
        public int index;
        public int enable;
        public string name; //dethunter12 6/27/2018 non localhost connect test
        public int type;
        public int str;
        public int con;
        public int dex;
        public int intel;
        public int itemidx;
        public int maxFaith;
        public int maxStm;
        public int maxHP;
        public int maxMP;
        public int recoverHP;
        public int recoverMP;
        public int delay;
        public int AISlot;
        public int afterDead;
        public int attack;
        public int defense;
        public int mAttack;
        public int mDefense;
        public int hitPoint;
        public int avoidPoint;
        public int mavoidPoint;
        public int attackSpeed;
        public int Deadly;
        public int Critical;
        public int awful;
        public int strong;
        public int normal;
        public int weak;
        public int bagicSkill1;
        public int bagicSkill2;
        public int flag;
        public int transType;
        public int transStart;
        public int transEnd;
        public string smcFileName1;
        public string aniIdle1;
        public string aniIdle2;
        public string aniAttack1;
        public string aniAttack2;
        public string aniDamage1;
        public string aniDie1;
        public string aniWalk1;
        public string aniRun1;
        public string aniLevelup1;
        public int mount1;
        public int summonSkill1;
        public int speed1;
        public string smcFileName2;
        public string aniIdle1_2;
        public string aniIdle2_2;
        public string aniAttack1_2;
        public string aniAttack2_2;
        public string aniDamage1_2;
        public string aniDie1_2;
        public string aniWalk1_2;
        public string aniRun1_2;
        public string aniLevelup1_2;
        public int mount1_2;
        public int summonSkill1_2;
        public int speed1_2;
        public string Menu;
        public t_attkpet Clone()
        {
            return (t_attkpet)MemberwiseClone();
        }
    }
}

