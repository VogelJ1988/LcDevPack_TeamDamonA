﻿using System;
using System.Windows.Forms;

namespace LcDevPack_TeamDamonA.Tools.MemoryWorker
{
    public partial class DailyLogin : Form
    {
        public string _ClientPath = LcDevPack_TeamDamonA.Tools.MobEditor.connection.ReadSettings("ClientPath"); //dethunter12 8/7/2018
        public DailyLogin()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sQLCurrentMonthToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sQLYearToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
