﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.Tools.MemoryWorker.AllLists
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

using System.Collections.Generic;

namespace LcDevPack_TeamDamonA.Tools.MemoryWorker
{
    public class AllLists
    {
        public static List<tnpc> tnpc_MenuData = new List<tnpc>();
        public static List<string> tnpc_Menu = new List<string>();
        public static List<treward_head> treward_head_MenuData = new List<treward_head>();
        public static List<string> treward_head_Menu = new List<string>();
        public static List<treward_data> treward_data_MenuData = new List<treward_data>();
        public static List<t_attkpet> tpet_MenuData = new List<t_attkpet>();
        public static List<tItemCollection> tItemCollect_MenuData = new List<tItemCollection>(); //dethunter12 add 7/26/2020
        public static List<string> tItemCollect_Menu = new List<string>();
        public static List<string> tpet_Menu = new List<string>();
        //Pet Ev
        public static List<BigpetEv> tpet_ev_MenuData = new List<BigpetEv>();
        public static List<string> tpet_ev_Menu = new List<string>();
        //Pet EXP
        public static List<BigpetExp> tpet_exp_MenuData = new List<BigpetExp>();
        public static List<string> tpet_exp_Menu = new List<string>();
        // public static List<t_lcball> lcball_MenuData 
    }
}
