﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.Jawel
{
    public class JawelStruct
    {
        public int a_index;
        public long a_normal_compose_neednas;
        public long a_chaos_compose_neednas;
        public int a_normal_compose_prob;
        public int a_chaos_compose_prob;
        public int a_compose_normalToChaos_prob;
        public int a_normal_plus2_prob;
        public int a_normal_plus3_prob;
        public int a_chaos_plus2_prob;
        public int a_chaos_plus3_prob;
        public int a_normal_minus1_prob;
        public int a_normal_minus2_prob;
        public int a_normal_minus3_prob;
        public int a_chaos_minus1_prob;
        public int a_chaos_minus2_prob;
        public int a_chaos_minus3_prob;
    }
}
