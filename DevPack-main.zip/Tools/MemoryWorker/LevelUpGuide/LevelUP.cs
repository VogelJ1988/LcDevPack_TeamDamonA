﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.LevelUpGuide
{
    public class LevelUP
    {
        public int Level;
        public int StringIndex;
        public string Name;
    }
}
