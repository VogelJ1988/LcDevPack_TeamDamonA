﻿namespace LcDevPack_TeamDamonA
{
    public class t_lcball

    {
        public int a_item_order, a_tocken_index, a_course_code, a_order, a_item_index, a_item_count, a_item_max, a_item_remain;


    }
}
