﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.rareoption
{
    class t_rareoption
    {
        public int IndexID { get; set; }
#pragma warning disable CS0649 // Field 't_rareoption.name' is never assigned to, and will always have its default value 0
        public int name;
#pragma warning restore CS0649 // Field 't_rareoption.name' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.grade' is never assigned to, and will always have its default value 0
        public int grade;
#pragma warning restore CS0649 // Field 't_rareoption.grade' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.type' is never assigned to, and will always have its default value 0
        public int type;
#pragma warning restore CS0649 // Field 't_rareoption.type' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.attack' is never assigned to, and will always have its default value 0
        public int attack;
#pragma warning restore CS0649 // Field 't_rareoption.attack' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.defense' is never assigned to, and will always have its default value 0
        public int defense;
#pragma warning restore CS0649 // Field 't_rareoption.defense' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.magic' is never assigned to, and will always have its default value 0
        public int magic;
#pragma warning restore CS0649 // Field 't_rareoption.magic' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.resist' is never assigned to, and will always have its default value 0
        public int resist;
#pragma warning restore CS0649 // Field 't_rareoption.resist' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex0' is never assigned to, and will always have its default value 0
        public int optionindex0;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex0' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex1' is never assigned to, and will always have its default value 0
        public int optionindex1;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex1' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex2' is never assigned to, and will always have its default value 0
        public int optionindex2;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex2' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex3' is never assigned to, and will always have its default value 0
        public int optionindex3;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex3' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex4' is never assigned to, and will always have its default value 0
        public int optionindex4;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex4' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex5' is never assigned to, and will always have its default value 0
        public int optionindex5;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex5' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex6' is never assigned to, and will always have its default value 0
        public int optionindex6;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex6' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex7' is never assigned to, and will always have its default value 0
        public int optionindex7;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex7' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex8' is never assigned to, and will always have its default value 0
        public int optionindex8;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex8' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionindex9' is never assigned to, and will always have its default value 0
        public int optionindex9;
#pragma warning restore CS0649 // Field 't_rareoption.optionindex9' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel0' is never assigned to, and will always have its default value 0
        public int optionlevel0;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel0' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel1' is never assigned to, and will always have its default value 0
        public int optionlevel1;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel1' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel2' is never assigned to, and will always have its default value 0
        public int optionlevel2;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel2' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel3' is never assigned to, and will always have its default value 0
        public int optionlevel3;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel3' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel4' is never assigned to, and will always have its default value 0
        public int optionlevel4;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel4' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel5' is never assigned to, and will always have its default value 0
        public int optionlevel5;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel5' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel6' is never assigned to, and will always have its default value 0
        public int optionlevel6;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel6' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel7' is never assigned to, and will always have its default value 0
        public int optionlevel7;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel7' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel8' is never assigned to, and will always have its default value 0
        public int optionlevel8;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel8' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionlevel9' is never assigned to, and will always have its default value 0
        public int optionlevel9;
#pragma warning restore CS0649 // Field 't_rareoption.optionlevel9' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob0' is never assigned to, and will always have its default value 0
        public int optionprob0;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob0' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob1' is never assigned to, and will always have its default value 0
        public int optionprob1;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob1' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob2' is never assigned to, and will always have its default value 0
        public int optionprob2;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob2' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob3' is never assigned to, and will always have its default value 0
        public int optionprob3;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob3' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob4' is never assigned to, and will always have its default value 0
        public int optionprob4;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob4' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob5' is never assigned to, and will always have its default value 0
        public int optionprob5;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob5' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob6' is never assigned to, and will always have its default value 0
        public int optionprob6;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob6' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob7' is never assigned to, and will always have its default value 0
        public int optionprob7;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob7' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob8' is never assigned to, and will always have its default value 0
        public int optionprob8;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob8' is never assigned to, and will always have its default value 0
#pragma warning disable CS0649 // Field 't_rareoption.optionprob9' is never assigned to, and will always have its default value 0
        public int optionprob9;
#pragma warning restore CS0649 // Field 't_rareoption.optionprob9' is never assigned to, and will always have its default value 0
    }
}
