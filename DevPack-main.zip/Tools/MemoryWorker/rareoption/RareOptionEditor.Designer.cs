﻿namespace LcDevPack_TeamDamonA.Tools.MemoryWorker.rareoption
{
    partial class RareOptionEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RareOptionEditor));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rareOptionlodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.strRareOptionusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportStringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LblPercent3 = new System.Windows.Forms.Label();
            this.LblNote = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblProb10 = new System.Windows.Forms.Label();
            this.lblProb9 = new System.Windows.Forms.Label();
            this.lblProb8 = new System.Windows.Forms.Label();
            this.lblProb7 = new System.Windows.Forms.Label();
            this.lblProb6 = new System.Windows.Forms.Label();
            this.lblProb5 = new System.Windows.Forms.Label();
            this.lblProb4 = new System.Windows.Forms.Label();
            this.lblProb3 = new System.Windows.Forms.Label();
            this.lblProb2 = new System.Windows.Forms.Label();
            this.lblProb1 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.od9 = new System.Windows.Forms.TextBox();
            this.lvl9 = new System.Windows.Forms.ComboBox();
            this.s9d = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.od8 = new System.Windows.Forms.TextBox();
            this.lvl8 = new System.Windows.Forms.ComboBox();
            this.s8d = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.od7 = new System.Windows.Forms.TextBox();
            this.lvl7 = new System.Windows.Forms.ComboBox();
            this.s7d = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.od6 = new System.Windows.Forms.TextBox();
            this.lvl6 = new System.Windows.Forms.ComboBox();
            this.s6d = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.od5 = new System.Windows.Forms.TextBox();
            this.lvl5 = new System.Windows.Forms.ComboBox();
            this.s5d = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.od4 = new System.Windows.Forms.TextBox();
            this.lvl4 = new System.Windows.Forms.ComboBox();
            this.s4d = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.od3 = new System.Windows.Forms.TextBox();
            this.lvl3 = new System.Windows.Forms.ComboBox();
            this.s3d = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.od2 = new System.Windows.Forms.TextBox();
            this.lvl2 = new System.Windows.Forms.ComboBox();
            this.s2d = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.od1 = new System.Windows.Forms.TextBox();
            this.lvl1 = new System.Windows.Forms.ComboBox();
            this.s1d = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.od0 = new System.Windows.Forms.TextBox();
            this.lvl0 = new System.Windows.Forms.ComboBox();
            this.s0d = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TbSeal7 = new System.Windows.Forms.TextBox();
            this.TbSeal6 = new System.Windows.Forms.TextBox();
            this.TbSeal9 = new System.Windows.Forms.TextBox();
            this.TbSeal8 = new System.Windows.Forms.TextBox();
            this.TbSeal5 = new System.Windows.Forms.TextBox();
            this.TbSeal4 = new System.Windows.Forms.TextBox();
            this.TbSeal3 = new System.Windows.Forms.TextBox();
            this.TbSeal2 = new System.Windows.Forms.TextBox();
            this.TbSeal1 = new System.Windows.Forms.TextBox();
            this.TbSeal0 = new System.Windows.Forms.TextBox();
            this.LblPercent4 = new System.Windows.Forms.Label();
            this.LblPercent2 = new System.Windows.Forms.Label();
            this.LblPercent1 = new System.Windows.Forms.Label();
            this.TbPercent4 = new System.Windows.Forms.TextBox();
            this.TbPercent3 = new System.Windows.Forms.TextBox();
            this.TbPercent2 = new System.Windows.Forms.TextBox();
            this.TbPercent1 = new System.Windows.Forms.TextBox();
            this.btnPercentAddResist = new System.Windows.Forms.Button();
            this.btnPercentAddMattk = new System.Windows.Forms.Button();
            this.btnPercentAddDef = new System.Windows.Forms.Button();
            this.btnPercentAddAttk = new System.Windows.Forms.Button();
            this.TbType = new System.Windows.Forms.TextBox();
            this.TbGrade = new System.Windows.Forms.TextBox();
            this.PbAcc = new System.Windows.Forms.PictureBox();
            this.PbArmor = new System.Windows.Forms.PictureBox();
            this.PbWeapon = new System.Windows.Forms.PictureBox();
            this.rstxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tdrop = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.gdrop = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.mtktxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.deftxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.atktxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.idtxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.remove = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbArmor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbWeapon)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(999, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToolStripMenuItem,
            this.exportStringToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rareOptionlodToolStripMenuItem,
            this.strRareOptionusToolStripMenuItem});
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.exportToolStripMenuItem.Text = "Export";
            // 
            // rareOptionlodToolStripMenuItem
            // 
            this.rareOptionlodToolStripMenuItem.Name = "rareOptionlodToolStripMenuItem";
            this.rareOptionlodToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.rareOptionlodToolStripMenuItem.Text = "RareOption.lod";
            this.rareOptionlodToolStripMenuItem.Click += new System.EventHandler(this.rareOptionlodToolStripMenuItem_Click);
            // 
            // strRareOptionusToolStripMenuItem
            // 
            this.strRareOptionusToolStripMenuItem.Name = "strRareOptionusToolStripMenuItem";
            this.strRareOptionusToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.strRareOptionusToolStripMenuItem.Text = "strRareOption_us";
            // 
            // exportStringToolStripMenuItem
            // 
            this.exportStringToolStripMenuItem.Name = "exportStringToolStripMenuItem";
            this.exportStringToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.exportStringToolStripMenuItem.Text = "Export String";
            this.exportStringToolStripMenuItem.Click += new System.EventHandler(this.exportStringToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LblPercent3);
            this.groupBox1.Controls.Add(this.LblNote);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(975, 414);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // LblPercent3
            // 
            this.LblPercent3.AutoSize = true;
            this.LblPercent3.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPercent3.Location = new System.Drawing.Point(409, 144);
            this.LblPercent3.Name = "LblPercent3";
            this.LblPercent3.Size = new System.Drawing.Size(14, 15);
            this.LblPercent3.TabIndex = 41;
            this.LblPercent3.Text = "%";
            // 
            // LblNote
            // 
            this.LblNote.AutoSize = true;
            this.LblNote.ForeColor = System.Drawing.Color.Red;
            this.LblNote.Location = new System.Drawing.Point(560, 383);
            this.LblNote.Name = "LblNote";
            this.LblNote.Size = new System.Drawing.Size(275, 13);
            this.LblNote.TabIndex = 7;
            this.LblNote.Text = "Note: Probability 10,000 = 100% chance to achieve seal ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(560, 366);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(225, 13);
            this.label20.TabIndex = 6;
            this.label20.Text = "Type Info - 0 = Weapon , 1 = Armor , 2 = Accs";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(560, 345);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(343, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Grade Info - 0 = Blue ,1= Green , 2= Yellow,3 = White bonus, 4 = White";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblProb10);
            this.groupBox4.Controls.Add(this.lblProb9);
            this.groupBox4.Controls.Add(this.lblProb8);
            this.groupBox4.Controls.Add(this.lblProb7);
            this.groupBox4.Controls.Add(this.lblProb6);
            this.groupBox4.Controls.Add(this.lblProb5);
            this.groupBox4.Controls.Add(this.lblProb4);
            this.groupBox4.Controls.Add(this.lblProb3);
            this.groupBox4.Controls.Add(this.lblProb2);
            this.groupBox4.Controls.Add(this.lblProb1);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.od9);
            this.groupBox4.Controls.Add(this.lvl9);
            this.groupBox4.Controls.Add(this.s9d);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.od8);
            this.groupBox4.Controls.Add(this.lvl8);
            this.groupBox4.Controls.Add(this.s8d);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.od7);
            this.groupBox4.Controls.Add(this.lvl7);
            this.groupBox4.Controls.Add(this.s7d);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.od6);
            this.groupBox4.Controls.Add(this.lvl6);
            this.groupBox4.Controls.Add(this.s6d);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.od5);
            this.groupBox4.Controls.Add(this.lvl5);
            this.groupBox4.Controls.Add(this.s5d);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.od4);
            this.groupBox4.Controls.Add(this.lvl4);
            this.groupBox4.Controls.Add(this.s4d);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.od3);
            this.groupBox4.Controls.Add(this.lvl3);
            this.groupBox4.Controls.Add(this.s3d);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.od2);
            this.groupBox4.Controls.Add(this.lvl2);
            this.groupBox4.Controls.Add(this.s2d);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.od1);
            this.groupBox4.Controls.Add(this.lvl1);
            this.groupBox4.Controls.Add(this.s1d);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.od0);
            this.groupBox4.Controls.Add(this.lvl0);
            this.groupBox4.Controls.Add(this.s0d);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(432, 15);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(522, 314);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Seals";
            // 
            // lblProb10
            // 
            this.lblProb10.AutoSize = true;
            this.lblProb10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb10.Location = new System.Drawing.Point(458, 289);
            this.lblProb10.Name = "lblProb10";
            this.lblProb10.Size = new System.Drawing.Size(0, 15);
            this.lblProb10.TabIndex = 56;
            // 
            // lblProb9
            // 
            this.lblProb9.AutoSize = true;
            this.lblProb9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb9.Location = new System.Drawing.Point(458, 261);
            this.lblProb9.Name = "lblProb9";
            this.lblProb9.Size = new System.Drawing.Size(0, 15);
            this.lblProb9.TabIndex = 55;
            // 
            // lblProb8
            // 
            this.lblProb8.AutoSize = true;
            this.lblProb8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb8.Location = new System.Drawing.Point(458, 234);
            this.lblProb8.Name = "lblProb8";
            this.lblProb8.Size = new System.Drawing.Size(0, 15);
            this.lblProb8.TabIndex = 54;
            // 
            // lblProb7
            // 
            this.lblProb7.AutoSize = true;
            this.lblProb7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb7.Location = new System.Drawing.Point(458, 207);
            this.lblProb7.Name = "lblProb7";
            this.lblProb7.Size = new System.Drawing.Size(0, 15);
            this.lblProb7.TabIndex = 53;
            // 
            // lblProb6
            // 
            this.lblProb6.AutoSize = true;
            this.lblProb6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb6.Location = new System.Drawing.Point(458, 181);
            this.lblProb6.Name = "lblProb6";
            this.lblProb6.Size = new System.Drawing.Size(0, 15);
            this.lblProb6.TabIndex = 52;
            // 
            // lblProb5
            // 
            this.lblProb5.AutoSize = true;
            this.lblProb5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb5.Location = new System.Drawing.Point(458, 154);
            this.lblProb5.Name = "lblProb5";
            this.lblProb5.Size = new System.Drawing.Size(0, 15);
            this.lblProb5.TabIndex = 51;
            // 
            // lblProb4
            // 
            this.lblProb4.AutoSize = true;
            this.lblProb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb4.Location = new System.Drawing.Point(458, 127);
            this.lblProb4.Name = "lblProb4";
            this.lblProb4.Size = new System.Drawing.Size(0, 15);
            this.lblProb4.TabIndex = 50;
            // 
            // lblProb3
            // 
            this.lblProb3.AutoSize = true;
            this.lblProb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb3.Location = new System.Drawing.Point(458, 99);
            this.lblProb3.Name = "lblProb3";
            this.lblProb3.Size = new System.Drawing.Size(0, 15);
            this.lblProb3.TabIndex = 49;
            // 
            // lblProb2
            // 
            this.lblProb2.AutoSize = true;
            this.lblProb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb2.Location = new System.Drawing.Point(458, 73);
            this.lblProb2.Name = "lblProb2";
            this.lblProb2.Size = new System.Drawing.Size(0, 15);
            this.lblProb2.TabIndex = 48;
            // 
            // lblProb1
            // 
            this.lblProb1.AutoSize = true;
            this.lblProb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProb1.Location = new System.Drawing.Point(458, 46);
            this.lblProb1.Name = "lblProb1";
            this.lblProb1.Size = new System.Drawing.Size(0, 15);
            this.lblProb1.TabIndex = 47;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(399, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 13);
            this.label23.TabIndex = 46;
            this.label23.Text = "Probability";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(336, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 13);
            this.label22.TabIndex = 45;
            this.label22.Text = "Level";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(166, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(28, 13);
            this.label21.TabIndex = 44;
            this.label21.Text = "Seal";
            // 
            // od9
            // 
            this.od9.Location = new System.Drawing.Point(402, 286);
            this.od9.Name = "od9";
            this.od9.Size = new System.Drawing.Size(50, 20);
            this.od9.TabIndex = 39;
            this.od9.TextChanged += new System.EventHandler(this.od9_TextChanged);
            this.od9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od9_KeyPress);
            // 
            // lvl9
            // 
            this.lvl9.FormattingEnabled = true;
            this.lvl9.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl9.Location = new System.Drawing.Point(322, 286);
            this.lvl9.Name = "lvl9";
            this.lvl9.Size = new System.Drawing.Size(73, 21);
            this.lvl9.TabIndex = 38;
            this.lvl9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl9_KeyPress);
            // 
            // s9d
            // 
            this.s9d.FormattingEnabled = true;
            this.s9d.Location = new System.Drawing.Point(61, 286);
            this.s9d.Name = "s9d";
            this.s9d.Size = new System.Drawing.Size(255, 21);
            this.s9d.TabIndex = 37;
            this.s9d.SelectedIndexChanged += new System.EventHandler(this.S9d_SelectedIndexChanged);
            this.s9d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S9d_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 288);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 13);
            this.label19.TabIndex = 36;
            this.label19.Text = "10";
            // 
            // od8
            // 
            this.od8.Location = new System.Drawing.Point(402, 259);
            this.od8.Name = "od8";
            this.od8.Size = new System.Drawing.Size(50, 20);
            this.od8.TabIndex = 35;
            this.od8.TextChanged += new System.EventHandler(this.od8_TextChanged);
            this.od8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od8_KeyPress);
            // 
            // lvl8
            // 
            this.lvl8.FormattingEnabled = true;
            this.lvl8.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl8.Location = new System.Drawing.Point(322, 259);
            this.lvl8.Name = "lvl8";
            this.lvl8.Size = new System.Drawing.Size(73, 21);
            this.lvl8.TabIndex = 34;
            this.lvl8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl8_KeyPress);
            // 
            // s8d
            // 
            this.s8d.FormattingEnabled = true;
            this.s8d.Location = new System.Drawing.Point(61, 259);
            this.s8d.Name = "s8d";
            this.s8d.Size = new System.Drawing.Size(255, 21);
            this.s8d.TabIndex = 33;
            this.s8d.SelectedIndexChanged += new System.EventHandler(this.S8d_SelectedIndexChanged);
            this.s8d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S8d_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 261);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 32;
            this.label18.Text = "9";
            // 
            // od7
            // 
            this.od7.Location = new System.Drawing.Point(402, 232);
            this.od7.Name = "od7";
            this.od7.Size = new System.Drawing.Size(50, 20);
            this.od7.TabIndex = 31;
            this.od7.TextChanged += new System.EventHandler(this.od7_TextChanged);
            this.od7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od7_KeyPress);
            // 
            // lvl7
            // 
            this.lvl7.FormattingEnabled = true;
            this.lvl7.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl7.Location = new System.Drawing.Point(322, 232);
            this.lvl7.Name = "lvl7";
            this.lvl7.Size = new System.Drawing.Size(73, 21);
            this.lvl7.TabIndex = 30;
            this.lvl7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl7_KeyPress);
            // 
            // s7d
            // 
            this.s7d.FormattingEnabled = true;
            this.s7d.Location = new System.Drawing.Point(61, 232);
            this.s7d.Name = "s7d";
            this.s7d.Size = new System.Drawing.Size(255, 21);
            this.s7d.TabIndex = 29;
            this.s7d.SelectedIndexChanged += new System.EventHandler(this.S7d_SelectedIndexChanged);
            this.s7d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S7d_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 234);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "8";
            // 
            // od6
            // 
            this.od6.Location = new System.Drawing.Point(402, 205);
            this.od6.Name = "od6";
            this.od6.Size = new System.Drawing.Size(50, 20);
            this.od6.TabIndex = 27;
            this.od6.TextChanged += new System.EventHandler(this.od6_TextChanged);
            this.od6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od6_KeyPress);
            // 
            // lvl6
            // 
            this.lvl6.FormattingEnabled = true;
            this.lvl6.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl6.Location = new System.Drawing.Point(322, 205);
            this.lvl6.Name = "lvl6";
            this.lvl6.Size = new System.Drawing.Size(73, 21);
            this.lvl6.TabIndex = 26;
            this.lvl6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl6_KeyPress);
            // 
            // s6d
            // 
            this.s6d.FormattingEnabled = true;
            this.s6d.Location = new System.Drawing.Point(61, 205);
            this.s6d.Name = "s6d";
            this.s6d.Size = new System.Drawing.Size(255, 21);
            this.s6d.TabIndex = 25;
            this.s6d.SelectedIndexChanged += new System.EventHandler(this.S6d_SelectedIndexChanged);
            this.s6d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S6d_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 207);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 24;
            this.label16.Text = "7";
            // 
            // od5
            // 
            this.od5.Location = new System.Drawing.Point(402, 178);
            this.od5.Name = "od5";
            this.od5.Size = new System.Drawing.Size(50, 20);
            this.od5.TabIndex = 23;
            this.od5.TextChanged += new System.EventHandler(this.od5_TextChanged);
            this.od5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od5_KeyPress);
            // 
            // lvl5
            // 
            this.lvl5.FormattingEnabled = true;
            this.lvl5.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl5.Location = new System.Drawing.Point(322, 178);
            this.lvl5.Name = "lvl5";
            this.lvl5.Size = new System.Drawing.Size(73, 21);
            this.lvl5.TabIndex = 22;
            this.lvl5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl5_KeyPress);
            // 
            // s5d
            // 
            this.s5d.FormattingEnabled = true;
            this.s5d.Location = new System.Drawing.Point(61, 178);
            this.s5d.Name = "s5d";
            this.s5d.Size = new System.Drawing.Size(255, 21);
            this.s5d.TabIndex = 21;
            this.s5d.SelectedIndexChanged += new System.EventHandler(this.S5d_SelectedIndexChanged);
            this.s5d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S5d_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 180);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 20;
            this.label15.Text = "6";
            // 
            // od4
            // 
            this.od4.Location = new System.Drawing.Point(402, 151);
            this.od4.Name = "od4";
            this.od4.Size = new System.Drawing.Size(50, 20);
            this.od4.TabIndex = 19;
            this.od4.TextChanged += new System.EventHandler(this.od4_TextChanged);
            this.od4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od4_KeyPress);
            // 
            // lvl4
            // 
            this.lvl4.FormattingEnabled = true;
            this.lvl4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl4.Location = new System.Drawing.Point(322, 151);
            this.lvl4.Name = "lvl4";
            this.lvl4.Size = new System.Drawing.Size(73, 21);
            this.lvl4.TabIndex = 18;
            this.lvl4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl4_KeyPress);
            // 
            // s4d
            // 
            this.s4d.FormattingEnabled = true;
            this.s4d.Location = new System.Drawing.Point(61, 151);
            this.s4d.Name = "s4d";
            this.s4d.Size = new System.Drawing.Size(255, 21);
            this.s4d.TabIndex = 17;
            this.s4d.SelectedIndexChanged += new System.EventHandler(this.S4d_SelectedIndexChanged);
            this.s4d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S4d_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 153);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "5";
            // 
            // od3
            // 
            this.od3.Location = new System.Drawing.Point(402, 124);
            this.od3.Name = "od3";
            this.od3.Size = new System.Drawing.Size(50, 20);
            this.od3.TabIndex = 15;
            this.od3.TextChanged += new System.EventHandler(this.od3_TextChanged);
            this.od3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od3_KeyPress);
            // 
            // lvl3
            // 
            this.lvl3.FormattingEnabled = true;
            this.lvl3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl3.Location = new System.Drawing.Point(322, 124);
            this.lvl3.Name = "lvl3";
            this.lvl3.Size = new System.Drawing.Size(73, 21);
            this.lvl3.TabIndex = 14;
            this.lvl3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl3_KeyPress);
            // 
            // s3d
            // 
            this.s3d.FormattingEnabled = true;
            this.s3d.Location = new System.Drawing.Point(61, 124);
            this.s3d.Name = "s3d";
            this.s3d.Size = new System.Drawing.Size(255, 21);
            this.s3d.TabIndex = 13;
            this.s3d.SelectedIndexChanged += new System.EventHandler(this.S3d_SelectedIndexChanged);
            this.s3d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S3d_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 126);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "4";
            // 
            // od2
            // 
            this.od2.Location = new System.Drawing.Point(402, 97);
            this.od2.Name = "od2";
            this.od2.Size = new System.Drawing.Size(50, 20);
            this.od2.TabIndex = 11;
            this.od2.TextChanged += new System.EventHandler(this.od2_TextChanged);
            this.od2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od2_KeyPress);
            // 
            // lvl2
            // 
            this.lvl2.FormattingEnabled = true;
            this.lvl2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl2.Location = new System.Drawing.Point(322, 97);
            this.lvl2.Name = "lvl2";
            this.lvl2.Size = new System.Drawing.Size(73, 21);
            this.lvl2.TabIndex = 10;
            this.lvl2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl2_KeyPress);
            // 
            // s2d
            // 
            this.s2d.FormattingEnabled = true;
            this.s2d.Location = new System.Drawing.Point(61, 97);
            this.s2d.Name = "s2d";
            this.s2d.Size = new System.Drawing.Size(255, 21);
            this.s2d.TabIndex = 9;
            this.s2d.SelectedIndexChanged += new System.EventHandler(this.S2d_SelectedIndexChanged);
            this.s2d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S2d_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "3";
            // 
            // od1
            // 
            this.od1.Location = new System.Drawing.Point(402, 70);
            this.od1.Name = "od1";
            this.od1.Size = new System.Drawing.Size(50, 20);
            this.od1.TabIndex = 7;
            this.od1.TextChanged += new System.EventHandler(this.od1_TextChanged);
            this.od1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od1_KeyPress);
            // 
            // lvl1
            // 
            this.lvl1.FormattingEnabled = true;
            this.lvl1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl1.Location = new System.Drawing.Point(322, 70);
            this.lvl1.Name = "lvl1";
            this.lvl1.Size = new System.Drawing.Size(73, 21);
            this.lvl1.TabIndex = 6;
            this.lvl1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl1_KeyPress);
            // 
            // s1d
            // 
            this.s1d.FormattingEnabled = true;
            this.s1d.Location = new System.Drawing.Point(61, 70);
            this.s1d.Name = "s1d";
            this.s1d.Size = new System.Drawing.Size(255, 21);
            this.s1d.TabIndex = 5;
            this.s1d.SelectedIndexChanged += new System.EventHandler(this.S1d_SelectedIndexChanged);
            this.s1d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S1d_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 72);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "2";
            // 
            // od0
            // 
            this.od0.Location = new System.Drawing.Point(402, 43);
            this.od0.Name = "od0";
            this.od0.Size = new System.Drawing.Size(50, 20);
            this.od0.TabIndex = 3;
            this.od0.TextChanged += new System.EventHandler(this.od0_TextChanged);
            this.od0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Od0_KeyPress);
            // 
            // lvl0
            // 
            this.lvl0.FormattingEnabled = true;
            this.lvl0.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.lvl0.Location = new System.Drawing.Point(322, 43);
            this.lvl0.Name = "lvl0";
            this.lvl0.Size = new System.Drawing.Size(73, 21);
            this.lvl0.TabIndex = 2;
            this.lvl0.SelectedIndexChanged += new System.EventHandler(this.lvl0_SelectedIndexChanged);
            this.lvl0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lvl0_KeyPress);
            // 
            // s0d
            // 
            this.s0d.FormattingEnabled = true;
            this.s0d.Location = new System.Drawing.Point(61, 43);
            this.s0d.Name = "s0d";
            this.s0d.Size = new System.Drawing.Size(255, 21);
            this.s0d.TabIndex = 1;
            this.s0d.SelectedIndexChanged += new System.EventHandler(this.S0d_SelectedIndexChanged);
            this.s0d.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S0d_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TbSeal7);
            this.groupBox3.Controls.Add(this.TbSeal6);
            this.groupBox3.Controls.Add(this.TbSeal9);
            this.groupBox3.Controls.Add(this.TbSeal8);
            this.groupBox3.Controls.Add(this.TbSeal5);
            this.groupBox3.Controls.Add(this.TbSeal4);
            this.groupBox3.Controls.Add(this.TbSeal3);
            this.groupBox3.Controls.Add(this.TbSeal2);
            this.groupBox3.Controls.Add(this.TbSeal1);
            this.groupBox3.Controls.Add(this.TbSeal0);
            this.groupBox3.Controls.Add(this.LblPercent4);
            this.groupBox3.Controls.Add(this.LblPercent2);
            this.groupBox3.Controls.Add(this.LblPercent1);
            this.groupBox3.Controls.Add(this.TbPercent4);
            this.groupBox3.Controls.Add(this.TbPercent3);
            this.groupBox3.Controls.Add(this.TbPercent2);
            this.groupBox3.Controls.Add(this.TbPercent1);
            this.groupBox3.Controls.Add(this.btnPercentAddResist);
            this.groupBox3.Controls.Add(this.btnPercentAddMattk);
            this.groupBox3.Controls.Add(this.btnPercentAddDef);
            this.groupBox3.Controls.Add(this.btnPercentAddAttk);
            this.groupBox3.Controls.Add(this.TbType);
            this.groupBox3.Controls.Add(this.TbGrade);
            this.groupBox3.Controls.Add(this.PbAcc);
            this.groupBox3.Controls.Add(this.PbArmor);
            this.groupBox3.Controls.Add(this.PbWeapon);
            this.groupBox3.Controls.Add(this.rstxt);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.tdrop);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.gdrop);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.mtktxt);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.deftxt);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.atktxt);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.nametxt);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.idtxt);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(192, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(234, 314);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Info";
            // 
            // TbSeal7
            // 
            this.TbSeal7.Location = new System.Drawing.Point(209, 258);
            this.TbSeal7.Name = "TbSeal7";
            this.TbSeal7.Size = new System.Drawing.Size(23, 20);
            this.TbSeal7.TabIndex = 52;
            this.TbSeal7.Visible = false;
            // 
            // TbSeal6
            // 
            this.TbSeal6.Location = new System.Drawing.Point(180, 258);
            this.TbSeal6.Name = "TbSeal6";
            this.TbSeal6.Size = new System.Drawing.Size(23, 20);
            this.TbSeal6.TabIndex = 51;
            this.TbSeal6.Visible = false;
            // 
            // TbSeal9
            // 
            this.TbSeal9.Location = new System.Drawing.Point(209, 287);
            this.TbSeal9.Name = "TbSeal9";
            this.TbSeal9.Size = new System.Drawing.Size(23, 20);
            this.TbSeal9.TabIndex = 50;
            this.TbSeal9.Visible = false;
            // 
            // TbSeal8
            // 
            this.TbSeal8.Location = new System.Drawing.Point(180, 287);
            this.TbSeal8.Name = "TbSeal8";
            this.TbSeal8.Size = new System.Drawing.Size(23, 20);
            this.TbSeal8.TabIndex = 49;
            this.TbSeal8.Visible = false;
            // 
            // TbSeal5
            // 
            this.TbSeal5.Location = new System.Drawing.Point(152, 286);
            this.TbSeal5.Name = "TbSeal5";
            this.TbSeal5.Size = new System.Drawing.Size(23, 20);
            this.TbSeal5.TabIndex = 48;
            this.TbSeal5.Visible = false;
            // 
            // TbSeal4
            // 
            this.TbSeal4.Location = new System.Drawing.Point(123, 286);
            this.TbSeal4.Name = "TbSeal4";
            this.TbSeal4.Size = new System.Drawing.Size(23, 20);
            this.TbSeal4.TabIndex = 47;
            this.TbSeal4.Visible = false;
            // 
            // TbSeal3
            // 
            this.TbSeal3.Location = new System.Drawing.Point(94, 286);
            this.TbSeal3.Name = "TbSeal3";
            this.TbSeal3.Size = new System.Drawing.Size(23, 20);
            this.TbSeal3.TabIndex = 46;
            this.TbSeal3.Visible = false;
            // 
            // TbSeal2
            // 
            this.TbSeal2.Location = new System.Drawing.Point(65, 286);
            this.TbSeal2.Name = "TbSeal2";
            this.TbSeal2.Size = new System.Drawing.Size(23, 20);
            this.TbSeal2.TabIndex = 45;
            this.TbSeal2.Visible = false;
            // 
            // TbSeal1
            // 
            this.TbSeal1.Location = new System.Drawing.Point(36, 286);
            this.TbSeal1.Name = "TbSeal1";
            this.TbSeal1.Size = new System.Drawing.Size(23, 20);
            this.TbSeal1.TabIndex = 44;
            this.TbSeal1.Visible = false;
            // 
            // TbSeal0
            // 
            this.TbSeal0.Location = new System.Drawing.Point(7, 286);
            this.TbSeal0.Name = "TbSeal0";
            this.TbSeal0.Size = new System.Drawing.Size(23, 20);
            this.TbSeal0.TabIndex = 43;
            this.TbSeal0.Visible = false;
            // 
            // LblPercent4
            // 
            this.LblPercent4.AutoSize = true;
            this.LblPercent4.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPercent4.Location = new System.Drawing.Point(217, 155);
            this.LblPercent4.Name = "LblPercent4";
            this.LblPercent4.Size = new System.Drawing.Size(14, 15);
            this.LblPercent4.TabIndex = 42;
            this.LblPercent4.Text = "%";
            // 
            // LblPercent2
            // 
            this.LblPercent2.AutoSize = true;
            this.LblPercent2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPercent2.Location = new System.Drawing.Point(217, 104);
            this.LblPercent2.Name = "LblPercent2";
            this.LblPercent2.Size = new System.Drawing.Size(14, 15);
            this.LblPercent2.TabIndex = 40;
            this.LblPercent2.Text = "%";
            // 
            // LblPercent1
            // 
            this.LblPercent1.AutoSize = true;
            this.LblPercent1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPercent1.Location = new System.Drawing.Point(217, 76);
            this.LblPercent1.Name = "LblPercent1";
            this.LblPercent1.Size = new System.Drawing.Size(14, 15);
            this.LblPercent1.TabIndex = 39;
            this.LblPercent1.Text = "%";
            // 
            // TbPercent4
            // 
            this.TbPercent4.Location = new System.Drawing.Point(180, 152);
            this.TbPercent4.Name = "TbPercent4";
            this.TbPercent4.Size = new System.Drawing.Size(33, 20);
            this.TbPercent4.TabIndex = 38;
            this.TbPercent4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbPercent4_KeyPress);
            // 
            // TbPercent3
            // 
            this.TbPercent3.Location = new System.Drawing.Point(180, 125);
            this.TbPercent3.Name = "TbPercent3";
            this.TbPercent3.Size = new System.Drawing.Size(33, 20);
            this.TbPercent3.TabIndex = 37;
            this.TbPercent3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbPercent3_KeyPress);
            // 
            // TbPercent2
            // 
            this.TbPercent2.Location = new System.Drawing.Point(180, 100);
            this.TbPercent2.Name = "TbPercent2";
            this.TbPercent2.Size = new System.Drawing.Size(33, 20);
            this.TbPercent2.TabIndex = 36;
            this.TbPercent2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbPercent2_KeyPress);
            // 
            // TbPercent1
            // 
            this.TbPercent1.Location = new System.Drawing.Point(180, 72);
            this.TbPercent1.Name = "TbPercent1";
            this.TbPercent1.Size = new System.Drawing.Size(33, 20);
            this.TbPercent1.TabIndex = 35;
            this.TbPercent1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbPercent1_KeyPress);
            // 
            // btnPercentAddResist
            // 
            this.btnPercentAddResist.Location = new System.Drawing.Point(154, 152);
            this.btnPercentAddResist.Name = "btnPercentAddResist";
            this.btnPercentAddResist.Size = new System.Drawing.Size(19, 20);
            this.btnPercentAddResist.TabIndex = 34;
            this.btnPercentAddResist.Text = "+";
            this.btnPercentAddResist.UseVisualStyleBackColor = true;
            this.btnPercentAddResist.Click += new System.EventHandler(this.BtnPercentAddResist_Click);
            // 
            // btnPercentAddMattk
            // 
            this.btnPercentAddMattk.Location = new System.Drawing.Point(154, 126);
            this.btnPercentAddMattk.Name = "btnPercentAddMattk";
            this.btnPercentAddMattk.Size = new System.Drawing.Size(19, 20);
            this.btnPercentAddMattk.TabIndex = 33;
            this.btnPercentAddMattk.Text = "+";
            this.btnPercentAddMattk.UseVisualStyleBackColor = true;
            this.btnPercentAddMattk.Click += new System.EventHandler(this.BtnPercentAddMattk_Click);
            // 
            // btnPercentAddDef
            // 
            this.btnPercentAddDef.Location = new System.Drawing.Point(154, 99);
            this.btnPercentAddDef.Name = "btnPercentAddDef";
            this.btnPercentAddDef.Size = new System.Drawing.Size(19, 20);
            this.btnPercentAddDef.TabIndex = 32;
            this.btnPercentAddDef.Text = "+";
            this.btnPercentAddDef.UseVisualStyleBackColor = true;
            this.btnPercentAddDef.Click += new System.EventHandler(this.BtnPercentAddDef_Click);
            // 
            // btnPercentAddAttk
            // 
            this.btnPercentAddAttk.Location = new System.Drawing.Point(154, 73);
            this.btnPercentAddAttk.Name = "btnPercentAddAttk";
            this.btnPercentAddAttk.Size = new System.Drawing.Size(19, 20);
            this.btnPercentAddAttk.TabIndex = 31;
            this.btnPercentAddAttk.Text = "+";
            this.btnPercentAddAttk.UseVisualStyleBackColor = true;
            this.btnPercentAddAttk.Click += new System.EventHandler(this.BtnPercentAddAttk_Click);
            // 
            // TbType
            // 
            this.TbType.Location = new System.Drawing.Point(154, 213);
            this.TbType.Name = "TbType";
            this.TbType.Size = new System.Drawing.Size(29, 20);
            this.TbType.TabIndex = 25;
            this.TbType.Visible = false;
            this.TbType.TextChanged += new System.EventHandler(this.TbType_TextChanged);
            // 
            // TbGrade
            // 
            this.TbGrade.Location = new System.Drawing.Point(154, 182);
            this.TbGrade.Name = "TbGrade";
            this.TbGrade.Size = new System.Drawing.Size(29, 20);
            this.TbGrade.TabIndex = 24;
            this.TbGrade.Visible = false;
            // 
            // PbAcc
            // 
            this.PbAcc.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.accessory;
            this.PbAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PbAcc.Location = new System.Drawing.Point(124, 241);
            this.PbAcc.Name = "PbAcc";
            this.PbAcc.Size = new System.Drawing.Size(39, 38);
            this.PbAcc.TabIndex = 23;
            this.PbAcc.TabStop = false;
            this.PbAcc.Click += new System.EventHandler(this.PbAcc_Click);
            // 
            // PbArmor
            // 
            this.PbArmor.BackColor = System.Drawing.SystemColors.Control;
            this.PbArmor.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.button10_BackgroundImage;
            this.PbArmor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PbArmor.Location = new System.Drawing.Point(71, 240);
            this.PbArmor.Name = "PbArmor";
            this.PbArmor.Size = new System.Drawing.Size(39, 38);
            this.PbArmor.TabIndex = 22;
            this.PbArmor.TabStop = false;
            this.PbArmor.Click += new System.EventHandler(this.PbArmor_Click);
            // 
            // PbWeapon
            // 
            this.PbWeapon.BackColor = System.Drawing.SystemColors.Control;
            this.PbWeapon.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.weapon;
            this.PbWeapon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PbWeapon.Location = new System.Drawing.Point(20, 241);
            this.PbWeapon.Name = "PbWeapon";
            this.PbWeapon.Size = new System.Drawing.Size(39, 38);
            this.PbWeapon.TabIndex = 21;
            this.PbWeapon.TabStop = false;
            this.PbWeapon.Click += new System.EventHandler(this.PbWeapon_Click);
            // 
            // rstxt
            // 
            this.rstxt.Location = new System.Drawing.Point(49, 150);
            this.rstxt.Name = "rstxt";
            this.rstxt.Size = new System.Drawing.Size(100, 20);
            this.rstxt.TabIndex = 17;
            this.rstxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Rstxt_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Resist";
            // 
            // tdrop
            // 
            this.tdrop.FormattingEnabled = true;
            this.tdrop.Location = new System.Drawing.Point(48, 209);
            this.tdrop.Name = "tdrop";
            this.tdrop.Size = new System.Drawing.Size(100, 21);
            this.tdrop.TabIndex = 15;
            this.tdrop.SelectedIndexChanged += new System.EventHandler(this.Tdrop_SelectedIndexChanged);
            this.tdrop.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tdrop_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Type";
            // 
            // gdrop
            // 
            this.gdrop.FormattingEnabled = true;
            this.gdrop.Location = new System.Drawing.Point(48, 182);
            this.gdrop.Name = "gdrop";
            this.gdrop.Size = new System.Drawing.Size(100, 21);
            this.gdrop.TabIndex = 13;
            this.gdrop.SelectedIndexChanged += new System.EventHandler(this.Gdrop_SelectedIndexChanged);
            this.gdrop.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Gdrop_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Grade";
            // 
            // mtktxt
            // 
            this.mtktxt.Location = new System.Drawing.Point(48, 124);
            this.mtktxt.Name = "mtktxt";
            this.mtktxt.Size = new System.Drawing.Size(100, 20);
            this.mtktxt.TabIndex = 9;
            this.mtktxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Mtktxt_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "MAtk";
            // 
            // deftxt
            // 
            this.deftxt.Location = new System.Drawing.Point(48, 98);
            this.deftxt.Name = "deftxt";
            this.deftxt.Size = new System.Drawing.Size(100, 20);
            this.deftxt.TabIndex = 7;
            this.deftxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Deftxt_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Def";
            // 
            // atktxt
            // 
            this.atktxt.Location = new System.Drawing.Point(48, 72);
            this.atktxt.Name = "atktxt";
            this.atktxt.Size = new System.Drawing.Size(100, 20);
            this.atktxt.TabIndex = 5;
            this.atktxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Atktxt_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Atk";
            // 
            // nametxt
            // 
            this.nametxt.Location = new System.Drawing.Point(48, 46);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(180, 20);
            this.nametxt.TabIndex = 3;
            this.nametxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Nametxt_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name";
            // 
            // idtxt
            // 
            this.idtxt.Location = new System.Drawing.Point(48, 20);
            this.idtxt.Name = "idtxt";
            this.idtxt.Size = new System.Drawing.Size(48, 20);
            this.idtxt.TabIndex = 1;
            this.idtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Idtxt_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.UpdateButton);
            this.groupBox2.Controls.Add(this.remove);
            this.groupBox2.Location = new System.Drawing.Point(192, 336);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(362, 60);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(169, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(88, 20);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(75, 23);
            this.UpdateButton.TabIndex = 1;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // remove
            // 
            this.remove.Location = new System.Drawing.Point(7, 20);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(75, 23);
            this.remove.TabIndex = 0;
            this.remove.Text = "Remove";
            this.remove.UseVisualStyleBackColor = true;
            this.remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(7, 15);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(172, 381);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // RareOptionEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 457);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RareOptionEditor";
            this.Text = "RareOptionEditor By VogelJ1988 Modified By Dethunter12";
            this.Load += new System.EventHandler(this.RareOptionEditor_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbArmor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbWeapon)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rareOptionlodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem strRareOptionusToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox od9;
        private System.Windows.Forms.ComboBox lvl9;
        private System.Windows.Forms.ComboBox s9d;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox od8;
        private System.Windows.Forms.ComboBox lvl8;
        private System.Windows.Forms.ComboBox s8d;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox od7;
        private System.Windows.Forms.ComboBox lvl7;
        private System.Windows.Forms.ComboBox s7d;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox od6;
        private System.Windows.Forms.ComboBox lvl6;
        private System.Windows.Forms.ComboBox s6d;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox od5;
        private System.Windows.Forms.ComboBox lvl5;
        private System.Windows.Forms.ComboBox s5d;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox od4;
        private System.Windows.Forms.ComboBox lvl4;
        private System.Windows.Forms.ComboBox s4d;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox od3;
        private System.Windows.Forms.ComboBox lvl3;
        private System.Windows.Forms.ComboBox s3d;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox od2;
        private System.Windows.Forms.ComboBox lvl2;
        private System.Windows.Forms.ComboBox s2d;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox od1;
        private System.Windows.Forms.ComboBox lvl1;
        private System.Windows.Forms.ComboBox s1d;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox od0;
        private System.Windows.Forms.ComboBox lvl0;
        private System.Windows.Forms.ComboBox s0d;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox rstxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox tdrop;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox gdrop;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox mtktxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox deftxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox atktxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idtxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.Button remove;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox PbAcc;
        private System.Windows.Forms.PictureBox PbArmor;
        private System.Windows.Forms.PictureBox PbWeapon;
        private System.Windows.Forms.Label LblNote;
        private System.Windows.Forms.TextBox TbType;
        private System.Windows.Forms.TextBox TbGrade;
        private System.Windows.Forms.TextBox TbPercent4;
        private System.Windows.Forms.TextBox TbPercent3;
        private System.Windows.Forms.TextBox TbPercent2;
        private System.Windows.Forms.TextBox TbPercent1;
        private System.Windows.Forms.Button btnPercentAddResist;
        private System.Windows.Forms.Button btnPercentAddMattk;
        private System.Windows.Forms.Button btnPercentAddDef;
        private System.Windows.Forms.Button btnPercentAddAttk;
        private System.Windows.Forms.Label LblPercent3;
        private System.Windows.Forms.Label LblPercent4;
        private System.Windows.Forms.Label LblPercent2;
        private System.Windows.Forms.Label LblPercent1;
        private System.Windows.Forms.TextBox TbSeal7;
        private System.Windows.Forms.TextBox TbSeal6;
        private System.Windows.Forms.TextBox TbSeal9;
        private System.Windows.Forms.TextBox TbSeal8;
        private System.Windows.Forms.TextBox TbSeal5;
        private System.Windows.Forms.TextBox TbSeal4;
        private System.Windows.Forms.TextBox TbSeal3;
        private System.Windows.Forms.TextBox TbSeal2;
        private System.Windows.Forms.TextBox TbSeal1;
        private System.Windows.Forms.TextBox TbSeal0;
        private System.Windows.Forms.ToolStripMenuItem exportStringToolStripMenuItem;
        private System.Windows.Forms.Label lblProb1;
        private System.Windows.Forms.Label lblProb10;
        private System.Windows.Forms.Label lblProb9;
        private System.Windows.Forms.Label lblProb8;
        private System.Windows.Forms.Label lblProb7;
        private System.Windows.Forms.Label lblProb6;
        private System.Windows.Forms.Label lblProb5;
        private System.Windows.Forms.Label lblProb4;
        private System.Windows.Forms.Label lblProb3;
        private System.Windows.Forms.Label lblProb2;
    }
}