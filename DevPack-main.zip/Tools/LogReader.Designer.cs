﻿namespace LcDevPack_TeamDamonA.Tools
{
    partial class LogReader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.openLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.listBox9 = new System.Windows.Forms.ListBox();
            this.listBox10 = new System.Windows.Forms.ListBox();
            this.listBox11 = new System.Windows.Forms.ListBox();
            this.listBox12 = new System.Windows.Forms.ListBox();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.listBox13 = new System.Windows.Forms.ListBox();
            this.listBox14 = new System.Windows.Forms.ListBox();
            this.listBox15 = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Location = new System.Drawing.Point(3, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1135, 511);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1127, 485);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "GM Logs";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.ForeColor = System.Drawing.Color.Yellow;
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1127, 485);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Hack Logs";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Black;
            this.tabPage3.Controls.Add(this.listBox3);
            this.tabPage3.ForeColor = System.Drawing.Color.Red;
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1127, 485);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Items Logs";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Black;
            this.tabPage4.Controls.Add(this.listBox4);
            this.tabPage4.ForeColor = System.Drawing.Color.Coral;
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1127, 485);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Char Logs";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Black;
            this.tabPage5.Controls.Add(this.listBox5);
            this.tabPage5.ForeColor = System.Drawing.Color.Lime;
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1127, 485);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Guild Logs";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Black;
            this.tabPage6.Controls.Add(this.listBox6);
            this.tabPage6.ForeColor = System.Drawing.Color.Aqua;
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1127, 485);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Err Logs";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Black;
            this.tabPage7.Controls.Add(this.listBox7);
            this.tabPage7.ForeColor = System.Drawing.Color.Fuchsia;
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1127, 485);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Stash Logs";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.Black;
            this.tabPage8.Controls.Add(this.listBox8);
            this.tabPage8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1127, 485);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Join DC Logs";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openLogToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1139, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // openLogToolStripMenuItem
            // 
            this.openLogToolStripMenuItem.Name = "openLogToolStripMenuItem";
            this.openLogToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.openLogToolStripMenuItem.Text = "Open Log";
            this.openLogToolStripMenuItem.Click += new System.EventHandler(this.openLogToolStripMenuItem_Click);
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.Black;
            this.tabPage9.Controls.Add(this.listBox15);
            this.tabPage9.Controls.Add(this.listBox9);
            this.tabPage9.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(1127, 485);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Quest Logs";
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Black;
            this.tabPage10.Controls.Add(this.listBox10);
            this.tabPage10.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(1127, 485);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Title Logs";
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.Black;
            this.tabPage11.Controls.Add(this.listBox11);
            this.tabPage11.ForeColor = System.Drawing.Color.Pink;
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(1127, 485);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Mobs Logs";
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.Black;
            this.tabPage12.Controls.Add(this.listBox12);
            this.tabPage12.ForeColor = System.Drawing.Color.Orchid;
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(1127, 485);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "Cash Logs";
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.Black;
            this.tabPage14.Controls.Add(this.listBox14);
            this.tabPage14.ForeColor = System.Drawing.Color.GreenYellow;
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(1127, 485);
            this.tabPage14.TabIndex = 13;
            this.tabPage14.Text = "Skills Logs";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Black;
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox1.ForeColor = System.Drawing.Color.Aqua;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(3, 3);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(1121, 479);
            this.listBox1.TabIndex = 0;
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.Black;
            this.listBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox2.ForeColor = System.Drawing.Color.YellowGreen;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(3, 3);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(1121, 479);
            this.listBox2.TabIndex = 1;
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.Color.Black;
            this.listBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox3.ForeColor = System.Drawing.Color.Lime;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(3, 3);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(1121, 479);
            this.listBox3.TabIndex = 1;
            // 
            // listBox4
            // 
            this.listBox4.BackColor = System.Drawing.Color.Black;
            this.listBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox4.ForeColor = System.Drawing.Color.Aqua;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(3, 3);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(1121, 479);
            this.listBox4.TabIndex = 1;
            // 
            // listBox5
            // 
            this.listBox5.BackColor = System.Drawing.Color.Black;
            this.listBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox5.ForeColor = System.Drawing.Color.Fuchsia;
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(3, 3);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(1121, 479);
            this.listBox5.TabIndex = 1;
            // 
            // listBox6
            // 
            this.listBox6.BackColor = System.Drawing.Color.Black;
            this.listBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox6.ForeColor = System.Drawing.Color.Red;
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(3, 3);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(1121, 479);
            this.listBox6.TabIndex = 1;
            // 
            // listBox7
            // 
            this.listBox7.BackColor = System.Drawing.Color.Black;
            this.listBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.listBox7.FormattingEnabled = true;
            this.listBox7.Location = new System.Drawing.Point(3, 3);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(1121, 479);
            this.listBox7.TabIndex = 1;
            // 
            // listBox8
            // 
            this.listBox8.BackColor = System.Drawing.Color.Black;
            this.listBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox8.ForeColor = System.Drawing.Color.White;
            this.listBox8.FormattingEnabled = true;
            this.listBox8.Location = new System.Drawing.Point(3, 3);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(1121, 479);
            this.listBox8.TabIndex = 1;
            // 
            // listBox9
            // 
            this.listBox9.BackColor = System.Drawing.Color.Black;
            this.listBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox9.FormattingEnabled = true;
            this.listBox9.Location = new System.Drawing.Point(0, 0);
            this.listBox9.Name = "listBox9";
            this.listBox9.Size = new System.Drawing.Size(1127, 485);
            this.listBox9.TabIndex = 1;
            // 
            // listBox10
            // 
            this.listBox10.BackColor = System.Drawing.Color.Black;
            this.listBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox10.ForeColor = System.Drawing.Color.Khaki;
            this.listBox10.FormattingEnabled = true;
            this.listBox10.Location = new System.Drawing.Point(0, 0);
            this.listBox10.Name = "listBox10";
            this.listBox10.Size = new System.Drawing.Size(1127, 485);
            this.listBox10.TabIndex = 1;
            // 
            // listBox11
            // 
            this.listBox11.BackColor = System.Drawing.Color.Black;
            this.listBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox11.ForeColor = System.Drawing.Color.LawnGreen;
            this.listBox11.FormattingEnabled = true;
            this.listBox11.Location = new System.Drawing.Point(0, 0);
            this.listBox11.Name = "listBox11";
            this.listBox11.Size = new System.Drawing.Size(1127, 485);
            this.listBox11.TabIndex = 1;
            // 
            // listBox12
            // 
            this.listBox12.BackColor = System.Drawing.Color.Black;
            this.listBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox12.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.listBox12.FormattingEnabled = true;
            this.listBox12.Location = new System.Drawing.Point(0, 0);
            this.listBox12.Name = "listBox12";
            this.listBox12.Size = new System.Drawing.Size(1127, 485);
            this.listBox12.TabIndex = 1;
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.Black;
            this.tabPage13.Controls.Add(this.listBox13);
            this.tabPage13.ForeColor = System.Drawing.Color.SpringGreen;
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Size = new System.Drawing.Size(1127, 485);
            this.tabPage13.TabIndex = 12;
            this.tabPage13.Text = "LuckDraw Logs";
            // 
            // listBox13
            // 
            this.listBox13.BackColor = System.Drawing.Color.Black;
            this.listBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox13.ForeColor = System.Drawing.Color.Silver;
            this.listBox13.FormattingEnabled = true;
            this.listBox13.Location = new System.Drawing.Point(0, 0);
            this.listBox13.Name = "listBox13";
            this.listBox13.Size = new System.Drawing.Size(1127, 485);
            this.listBox13.TabIndex = 1;
            // 
            // listBox14
            // 
            this.listBox14.BackColor = System.Drawing.Color.Black;
            this.listBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox14.ForeColor = System.Drawing.Color.Yellow;
            this.listBox14.FormattingEnabled = true;
            this.listBox14.Location = new System.Drawing.Point(0, 0);
            this.listBox14.Name = "listBox14";
            this.listBox14.Size = new System.Drawing.Size(1127, 485);
            this.listBox14.TabIndex = 1;
            // 
            // listBox15
            // 
            this.listBox15.BackColor = System.Drawing.Color.Black;
            this.listBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox15.ForeColor = System.Drawing.Color.DarkOrange;
            this.listBox15.FormattingEnabled = true;
            this.listBox15.Location = new System.Drawing.Point(0, 0);
            this.listBox15.Name = "listBox15";
            this.listBox15.Size = new System.Drawing.Size(1127, 485);
            this.listBox15.TabIndex = 2;
            // 
            // LogReader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1139, 537);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "LogReader";
            this.Text = "LogReader";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openLogToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.ListBox listBox15;
        private System.Windows.Forms.ListBox listBox9;
        private System.Windows.Forms.ListBox listBox10;
        private System.Windows.Forms.ListBox listBox11;
        private System.Windows.Forms.ListBox listBox12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.ListBox listBox13;
        private System.Windows.Forms.ListBox listBox14;
    }
}