﻿using System.Windows.Forms;

namespace LcDevPack_TeamDamonA.Tools
{
    public partial class MakeItemEditor : Form
    {
        public MakeItemEditor()
        {
            InitializeComponent();
        }
    }
}
