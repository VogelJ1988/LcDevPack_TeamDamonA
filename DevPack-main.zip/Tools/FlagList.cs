﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.Tools.FlagList
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA.Tools
{
    public class FlagList
    {
        public static string[] Skills = new string[18]
        {
      "Singlemode",
      "Help",
      "Not Help",
      "Abstime",
      "Not Duplicate",
      "No Cancel",
      "Combo",
      "Logout",
      "Instant",
      "Guild",
      "Infinite",
      "Zone",
      "Summon Npc",
      "Not Bless",
      "ItemSkill",
      "Not Boss",
      "Not Single",
      "Toggle"
        };
        public static string[] Skills2 = new string[8] //dethunter12 add
        {
      "DEATH",
      "WEAPON",
      "SITDOWN",
      "PEACEZONE",
      "SHIELD",
      "STAND",
      "DARKNESS",
      "NO_COOL_TIME"
        };
        public static string[] Skills3 = new string[18] //dethunter12 add
        {
      "APP_CHARACTER",
      "APP_FIRE",
      "APP_WIND",
      "APP_EARTH",
      "APP_WATER",
      "APP_HELLOUND",
      "APP_ELENEN",
      "APP_APET",
      "APP_ALL",
      "USE_CHARACTER",
      "USE_FIRE",
      "USE_WIND",
      "USE_EARTH",
      "USE_WATER",
      "USE_HELLOUND",
      "USE_ELENEN",
      "USE_APET",
      "USE_ALL"
        };
        public static string[] Npcs = new string[31]
        {
      "Shopper",
      "First Attack",
      "Attack",
      "Moving",
      "Peaceful",
      "Zonemover",
      "Castle Guard",
      "Refiner",
      "Quest",
      "Castle Tower",
      "Mineral",
      "Crops",
      "Eneergy",
      "Eternal",
      "Lord Symbol",
      "Remission",
      "Event",
      "Guard",
      "Keeper",
      "Guild",
      "MBoss",
      "Boss",
      "Resetstat",
      "Change Weapon",
      "Warcastle",
      "Display Map",
      "Quest Collect",
      "Party",
      "Raid",
      "Subcity",
      "Chaocity"
        };
        public static string[] Npcs1 = new string[11]
        {
      "Tradeagent",
      "Collsion",
      "Factory",
      "Trigger Choice",
      "Trigger Kill",
      "Npc Portal",
      "Dont Attack",
      "Affinity",
      "Shadow",
      "Crafting",
      "Totem Item"
        };
        public static string[] NpcsAI = new string[4]
        {
      "Normal",
      "Tanker",
      "Damage Dealer",
      "Healer"
        };
        public static string[] SpecialSkills = new string[11]
        {
      "Mining",
      "Gathering",
      "Charge",
      "Stone",
      "Plant",
      "Element",
      "Make Weapon",
      "Make Wear",
      "Make G B",
      "Make Armor",
      "Make H S"
        };
        public static string[] ItemsEP4 = new string[64]
        {
      "Count",
      "Drop",
      "Upgrade",
      "Exchange",
      "Trade",
      "Not Delete",
      "Made",
      "Mix",
      "Cash",
      "Lord",
      "No Stash",
      "Change",
      "Composite",
      "Duplication",
      "lent",
      "Rare",
      "ABS",
      "Not Reform",
      "ZoneMove Del",
      "Origin",
      "Trigger",
      "Raid Special",
      "Quest",
      "Box",
      "Not TradeAgent",
      "Durability",
      "Costume2",
      "Socket",
      "Seller",
      "Castillan",
      "LetsParty",
      "Non-RVR",
      "Quest Give",
      "Toggle",
      "Compose",
      "NotSingle",
      "Invisible Custom",
      "37 ",
      "38 ",
      "39 ",
      "40 ",
      "41 ",
      "42 ",
      "43 ",
      "44 ",
      "45 ",
      "46 ",
      "47 ",
      "48 ",
      "49 ",
      "50 ",
      "51 ",
      "52 ",
      "53 ",
      "54 ",
      "55 ",
      "56 ",
      "57 ",
      "58 ",
      "59 ",
      "60 ",
      "61 ",
      "62 ",
      "63 "
        };
        public static string[] ItemsEP3 = new string[37]
        {
      "Count",
      "Drop",
      "Upgrade",
      "Exchange",
      "Trade",
      "Not Delete",
      "Made",
      "Mix",
      "Cash",
      "Lord",
      "No Stash",
      "Change",
      "Composite",
      "Duplication",
      "lent",
      "Rare",
      "ABS",
      "Not Reform",
      "ZoneMove Del",
      "Origin",
      "Trigger",
      "Raid Special",
      "Quest",
      "Box",
      "Not TradeAgent",
      "Durability",
      "Costume2",
      "Socket",
      "Seller",
      "Castillan",
      "LetsParty",
      "Non-RVR",
      "Quest Give",
      "Toggle",
      "Compose",
      "NotSingle",
      "Invisible Custom"
        };
    }
}
