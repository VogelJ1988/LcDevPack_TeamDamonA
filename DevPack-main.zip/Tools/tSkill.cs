﻿
namespace LcDevPack_TeamDamonA.Tools
{
    public class tSkill
    {
        public int ItemID;
        public string Name;

    }
}
