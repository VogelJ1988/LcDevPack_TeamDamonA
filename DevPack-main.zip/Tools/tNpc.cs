﻿
namespace LcDevPack_TeamDamonA.Tools
{
    public class tNpc
    {
        public int ItemID;
        public string Name;
        public string SMCPath; //dethunter12 modify
    }
}
