﻿namespace LcDevPack_TeamDamonA.Tools
{
    public class ItemPicker2_items
    {
        public int ID { get; set; }
        public int Amount { get; set; }
    }
}
