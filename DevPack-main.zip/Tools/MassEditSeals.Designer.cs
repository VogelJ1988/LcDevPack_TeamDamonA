﻿namespace LcDevPack_TeamDamonA.Tools
{
    partial class MassEditSeals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MassEditSeals));
            this.gbMassRareOption = new System.Windows.Forms.GroupBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.TbLevel9 = new System.Windows.Forms.TextBox();
            this.lbllevel9 = new System.Windows.Forms.Label();
            this.TbLevel8 = new System.Windows.Forms.TextBox();
            this.lbllevel8 = new System.Windows.Forms.Label();
            this.TbLevel7 = new System.Windows.Forms.TextBox();
            this.lbllevel7 = new System.Windows.Forms.Label();
            this.TbLevel6 = new System.Windows.Forms.TextBox();
            this.lbllevel6 = new System.Windows.Forms.Label();
            this.TbLevel5 = new System.Windows.Forms.TextBox();
            this.lbllevel5 = new System.Windows.Forms.Label();
            this.TbLevel4 = new System.Windows.Forms.TextBox();
            this.lbllevel4 = new System.Windows.Forms.Label();
            this.TbLevel3 = new System.Windows.Forms.TextBox();
            this.lbllevel3 = new System.Windows.Forms.Label();
            this.TbLevel2 = new System.Windows.Forms.TextBox();
            this.lbllevel2 = new System.Windows.Forms.Label();
            this.TbLevel1 = new System.Windows.Forms.TextBox();
            this.lbllevel1 = new System.Windows.Forms.Label();
            this.TbLevel0 = new System.Windows.Forms.TextBox();
            this.lbllevel0 = new System.Windows.Forms.Label();
            this.TbOption9 = new System.Windows.Forms.TextBox();
            this.lblOption9 = new System.Windows.Forms.Label();
            this.TbOption8 = new System.Windows.Forms.TextBox();
            this.lblOption8 = new System.Windows.Forms.Label();
            this.TbOption7 = new System.Windows.Forms.TextBox();
            this.lblOption7 = new System.Windows.Forms.Label();
            this.TbOption6 = new System.Windows.Forms.TextBox();
            this.lblOption6 = new System.Windows.Forms.Label();
            this.TbOption5 = new System.Windows.Forms.TextBox();
            this.lblOption5 = new System.Windows.Forms.Label();
            this.TbOption4 = new System.Windows.Forms.TextBox();
            this.lblOption4 = new System.Windows.Forms.Label();
            this.TbOption3 = new System.Windows.Forms.TextBox();
            this.lblOption3 = new System.Windows.Forms.Label();
            this.TbOption2 = new System.Windows.Forms.TextBox();
            this.lblOption2 = new System.Windows.Forms.Label();
            this.TbOption1 = new System.Windows.Forms.TextBox();
            this.lblOption1 = new System.Windows.Forms.Label();
            this.TbOption0 = new System.Windows.Forms.TextBox();
            this.lblOption0 = new System.Windows.Forms.Label();
            this.GbRange = new System.Windows.Forms.GroupBox();
            this.PbSelectID2 = new System.Windows.Forms.PictureBox();
            this.PbSelectID1 = new System.Windows.Forms.PictureBox();
            this.tbRange2 = new System.Windows.Forms.TextBox();
            this.lblItemRange2 = new System.Windows.Forms.Label();
            this.tbRange1 = new System.Windows.Forms.TextBox();
            this.LblitemRange1 = new System.Windows.Forms.Label();
            this.btnTips = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblNote1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.gbMassRareOption.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.GbRange.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbSelectID2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbSelectID1)).BeginInit();
            this.SuspendLayout();
            // 
            // gbMassRareOption
            // 
            this.gbMassRareOption.Controls.Add(this.pictureBox22);
            this.gbMassRareOption.Controls.Add(this.pictureBox21);
            this.gbMassRareOption.Controls.Add(this.pictureBox20);
            this.gbMassRareOption.Controls.Add(this.pictureBox19);
            this.gbMassRareOption.Controls.Add(this.pictureBox18);
            this.gbMassRareOption.Controls.Add(this.pictureBox17);
            this.gbMassRareOption.Controls.Add(this.pictureBox16);
            this.gbMassRareOption.Controls.Add(this.pictureBox15);
            this.gbMassRareOption.Controls.Add(this.pictureBox14);
            this.gbMassRareOption.Controls.Add(this.pictureBox13);
            this.gbMassRareOption.Controls.Add(this.TbLevel9);
            this.gbMassRareOption.Controls.Add(this.lbllevel9);
            this.gbMassRareOption.Controls.Add(this.TbLevel8);
            this.gbMassRareOption.Controls.Add(this.lbllevel8);
            this.gbMassRareOption.Controls.Add(this.TbLevel7);
            this.gbMassRareOption.Controls.Add(this.lbllevel7);
            this.gbMassRareOption.Controls.Add(this.TbLevel6);
            this.gbMassRareOption.Controls.Add(this.lbllevel6);
            this.gbMassRareOption.Controls.Add(this.TbLevel5);
            this.gbMassRareOption.Controls.Add(this.lbllevel5);
            this.gbMassRareOption.Controls.Add(this.TbLevel4);
            this.gbMassRareOption.Controls.Add(this.lbllevel4);
            this.gbMassRareOption.Controls.Add(this.TbLevel3);
            this.gbMassRareOption.Controls.Add(this.lbllevel3);
            this.gbMassRareOption.Controls.Add(this.TbLevel2);
            this.gbMassRareOption.Controls.Add(this.lbllevel2);
            this.gbMassRareOption.Controls.Add(this.TbLevel1);
            this.gbMassRareOption.Controls.Add(this.lbllevel1);
            this.gbMassRareOption.Controls.Add(this.TbLevel0);
            this.gbMassRareOption.Controls.Add(this.lbllevel0);
            this.gbMassRareOption.Controls.Add(this.TbOption9);
            this.gbMassRareOption.Controls.Add(this.lblOption9);
            this.gbMassRareOption.Controls.Add(this.TbOption8);
            this.gbMassRareOption.Controls.Add(this.lblOption8);
            this.gbMassRareOption.Controls.Add(this.TbOption7);
            this.gbMassRareOption.Controls.Add(this.lblOption7);
            this.gbMassRareOption.Controls.Add(this.TbOption6);
            this.gbMassRareOption.Controls.Add(this.lblOption6);
            this.gbMassRareOption.Controls.Add(this.TbOption5);
            this.gbMassRareOption.Controls.Add(this.lblOption5);
            this.gbMassRareOption.Controls.Add(this.TbOption4);
            this.gbMassRareOption.Controls.Add(this.lblOption4);
            this.gbMassRareOption.Controls.Add(this.TbOption3);
            this.gbMassRareOption.Controls.Add(this.lblOption3);
            this.gbMassRareOption.Controls.Add(this.TbOption2);
            this.gbMassRareOption.Controls.Add(this.lblOption2);
            this.gbMassRareOption.Controls.Add(this.TbOption1);
            this.gbMassRareOption.Controls.Add(this.lblOption1);
            this.gbMassRareOption.Controls.Add(this.TbOption0);
            this.gbMassRareOption.Controls.Add(this.lblOption0);
            this.gbMassRareOption.Location = new System.Drawing.Point(12, 26);
            this.gbMassRareOption.Name = "gbMassRareOption";
            this.gbMassRareOption.Size = new System.Drawing.Size(336, 286);
            this.gbMassRareOption.TabIndex = 1;
            this.gbMassRareOption.TabStop = false;
            this.gbMassRareOption.Text = "Rare Options";
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox22.Location = new System.Drawing.Point(135, 254);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(22, 22);
            this.pictureBox22.TabIndex = 99;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox21.Location = new System.Drawing.Point(135, 228);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(22, 22);
            this.pictureBox21.TabIndex = 98;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox20.Location = new System.Drawing.Point(135, 202);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(22, 22);
            this.pictureBox20.TabIndex = 97;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox19.Location = new System.Drawing.Point(135, 175);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(22, 22);
            this.pictureBox19.TabIndex = 96;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox18.Location = new System.Drawing.Point(135, 149);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(22, 22);
            this.pictureBox18.TabIndex = 95;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox17.Location = new System.Drawing.Point(135, 123);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(22, 22);
            this.pictureBox17.TabIndex = 94;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox16.Location = new System.Drawing.Point(135, 97);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(22, 22);
            this.pictureBox16.TabIndex = 93;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox15.Location = new System.Drawing.Point(135, 71);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(22, 22);
            this.pictureBox15.TabIndex = 92;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox14.Location = new System.Drawing.Point(135, 45);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(22, 22);
            this.pictureBox14.TabIndex = 91;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox13.Location = new System.Drawing.Point(135, 19);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(22, 22);
            this.pictureBox13.TabIndex = 90;
            this.pictureBox13.TabStop = false;
            // 
            // TbLevel9
            // 
            this.TbLevel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel9.Location = new System.Drawing.Point(245, 257);
            this.TbLevel9.Name = "TbLevel9";
            this.TbLevel9.Size = new System.Drawing.Size(61, 20);
            this.TbLevel9.TabIndex = 78;
            this.TbLevel9.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel9, "Option Level/Rareoption Prob");
            // 
            // lbllevel9
            // 
            this.lbllevel9.AutoSize = true;
            this.lbllevel9.Location = new System.Drawing.Point(166, 259);
            this.lbllevel9.Name = "lbllevel9";
            this.lbllevel9.Size = new System.Drawing.Size(73, 13);
            this.lbllevel9.TabIndex = 79;
            this.lbllevel9.Text = "Chance:Level";
            // 
            // TbLevel8
            // 
            this.TbLevel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel8.Location = new System.Drawing.Point(245, 231);
            this.TbLevel8.Name = "TbLevel8";
            this.TbLevel8.Size = new System.Drawing.Size(61, 20);
            this.TbLevel8.TabIndex = 76;
            this.TbLevel8.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel8, "Option Level/Rareoption Prob");
            // 
            // lbllevel8
            // 
            this.lbllevel8.AutoSize = true;
            this.lbllevel8.Location = new System.Drawing.Point(166, 233);
            this.lbllevel8.Name = "lbllevel8";
            this.lbllevel8.Size = new System.Drawing.Size(73, 13);
            this.lbllevel8.TabIndex = 77;
            this.lbllevel8.Text = "Chance:Level";
            // 
            // TbLevel7
            // 
            this.TbLevel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel7.Location = new System.Drawing.Point(245, 205);
            this.TbLevel7.Name = "TbLevel7";
            this.TbLevel7.Size = new System.Drawing.Size(61, 20);
            this.TbLevel7.TabIndex = 74;
            this.TbLevel7.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel7, "Option Level/Rareoption Prob");
            // 
            // lbllevel7
            // 
            this.lbllevel7.AutoSize = true;
            this.lbllevel7.Location = new System.Drawing.Point(166, 207);
            this.lbllevel7.Name = "lbllevel7";
            this.lbllevel7.Size = new System.Drawing.Size(73, 13);
            this.lbllevel7.TabIndex = 75;
            this.lbllevel7.Text = "Chance:Level";
            // 
            // TbLevel6
            // 
            this.TbLevel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel6.Location = new System.Drawing.Point(245, 179);
            this.TbLevel6.Name = "TbLevel6";
            this.TbLevel6.Size = new System.Drawing.Size(61, 20);
            this.TbLevel6.TabIndex = 72;
            this.TbLevel6.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel6, "Option Level/Rareoption Prob");
            // 
            // lbllevel6
            // 
            this.lbllevel6.AutoSize = true;
            this.lbllevel6.Location = new System.Drawing.Point(166, 181);
            this.lbllevel6.Name = "lbllevel6";
            this.lbllevel6.Size = new System.Drawing.Size(73, 13);
            this.lbllevel6.TabIndex = 73;
            this.lbllevel6.Text = "Chance:Level";
            // 
            // TbLevel5
            // 
            this.TbLevel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel5.Location = new System.Drawing.Point(245, 153);
            this.TbLevel5.Name = "TbLevel5";
            this.TbLevel5.Size = new System.Drawing.Size(61, 20);
            this.TbLevel5.TabIndex = 70;
            this.TbLevel5.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel5, "Option Level/Rareoption Prob");
            // 
            // lbllevel5
            // 
            this.lbllevel5.AutoSize = true;
            this.lbllevel5.Location = new System.Drawing.Point(166, 155);
            this.lbllevel5.Name = "lbllevel5";
            this.lbllevel5.Size = new System.Drawing.Size(73, 13);
            this.lbllevel5.TabIndex = 71;
            this.lbllevel5.Text = "Chance:Level";
            // 
            // TbLevel4
            // 
            this.TbLevel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel4.Location = new System.Drawing.Point(245, 126);
            this.TbLevel4.Name = "TbLevel4";
            this.TbLevel4.Size = new System.Drawing.Size(61, 20);
            this.TbLevel4.TabIndex = 68;
            this.TbLevel4.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel4, "Option Level/Rareoption Prob");
            // 
            // lbllevel4
            // 
            this.lbllevel4.AutoSize = true;
            this.lbllevel4.Location = new System.Drawing.Point(166, 131);
            this.lbllevel4.Name = "lbllevel4";
            this.lbllevel4.Size = new System.Drawing.Size(73, 13);
            this.lbllevel4.TabIndex = 69;
            this.lbllevel4.Text = "Chance:Level";
            // 
            // TbLevel3
            // 
            this.TbLevel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel3.Location = new System.Drawing.Point(245, 98);
            this.TbLevel3.Name = "TbLevel3";
            this.TbLevel3.Size = new System.Drawing.Size(61, 20);
            this.TbLevel3.TabIndex = 66;
            this.TbLevel3.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel3, "Option Level/Rareoption Prob");
            // 
            // lbllevel3
            // 
            this.lbllevel3.AutoSize = true;
            this.lbllevel3.Location = new System.Drawing.Point(166, 100);
            this.lbllevel3.Name = "lbllevel3";
            this.lbllevel3.Size = new System.Drawing.Size(73, 13);
            this.lbllevel3.TabIndex = 67;
            this.lbllevel3.Text = "Chance:Level";
            // 
            // TbLevel2
            // 
            this.TbLevel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel2.Location = new System.Drawing.Point(245, 72);
            this.TbLevel2.Name = "TbLevel2";
            this.TbLevel2.Size = new System.Drawing.Size(61, 20);
            this.TbLevel2.TabIndex = 64;
            this.TbLevel2.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel2, "Option Level/Rareoption Prob");
            // 
            // lbllevel2
            // 
            this.lbllevel2.AutoSize = true;
            this.lbllevel2.Location = new System.Drawing.Point(166, 74);
            this.lbllevel2.Name = "lbllevel2";
            this.lbllevel2.Size = new System.Drawing.Size(73, 13);
            this.lbllevel2.TabIndex = 65;
            this.lbllevel2.Text = "Chance:Level";
            // 
            // TbLevel1
            // 
            this.TbLevel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel1.Location = new System.Drawing.Point(245, 46);
            this.TbLevel1.Name = "TbLevel1";
            this.TbLevel1.Size = new System.Drawing.Size(61, 20);
            this.TbLevel1.TabIndex = 62;
            this.TbLevel1.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel1, "Option Level/Rareoption Prob");
            // 
            // lbllevel1
            // 
            this.lbllevel1.AutoSize = true;
            this.lbllevel1.Location = new System.Drawing.Point(166, 48);
            this.lbllevel1.Name = "lbllevel1";
            this.lbllevel1.Size = new System.Drawing.Size(73, 13);
            this.lbllevel1.TabIndex = 63;
            this.lbllevel1.Text = "Chance:Level";
            // 
            // TbLevel0
            // 
            this.TbLevel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbLevel0.Location = new System.Drawing.Point(245, 20);
            this.TbLevel0.Name = "TbLevel0";
            this.TbLevel0.Size = new System.Drawing.Size(61, 20);
            this.TbLevel0.TabIndex = 60;
            this.TbLevel0.Text = "0";
            this.toolTip1.SetToolTip(this.TbLevel0, "Option Level/Rareoption Prob");
            // 
            // lbllevel0
            // 
            this.lbllevel0.AutoSize = true;
            this.lbllevel0.Location = new System.Drawing.Point(165, 22);
            this.lbllevel0.Name = "lbllevel0";
            this.lbllevel0.Size = new System.Drawing.Size(73, 13);
            this.lbllevel0.TabIndex = 61;
            this.lbllevel0.Text = "Chance:Level";
            // 
            // TbOption9
            // 
            this.TbOption9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption9.Location = new System.Drawing.Point(68, 255);
            this.TbOption9.Name = "TbOption9";
            this.TbOption9.Size = new System.Drawing.Size(61, 20);
            this.TbOption9.TabIndex = 58;
            this.TbOption9.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption9, "Option Index/Rareoption Index");
            // 
            // lblOption9
            // 
            this.lblOption9.AutoSize = true;
            this.lblOption9.Location = new System.Drawing.Point(15, 257);
            this.lblOption9.Name = "lblOption9";
            this.lblOption9.Size = new System.Drawing.Size(47, 13);
            this.lblOption9.TabIndex = 59;
            this.lblOption9.Text = "Option9:";
            // 
            // TbOption8
            // 
            this.TbOption8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption8.Location = new System.Drawing.Point(68, 229);
            this.TbOption8.Name = "TbOption8";
            this.TbOption8.Size = new System.Drawing.Size(61, 20);
            this.TbOption8.TabIndex = 56;
            this.TbOption8.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption8, "Option Index/Rareoption Index");
            // 
            // lblOption8
            // 
            this.lblOption8.AutoSize = true;
            this.lblOption8.Location = new System.Drawing.Point(15, 231);
            this.lblOption8.Name = "lblOption8";
            this.lblOption8.Size = new System.Drawing.Size(47, 13);
            this.lblOption8.TabIndex = 57;
            this.lblOption8.Text = "Option8:";
            // 
            // TbOption7
            // 
            this.TbOption7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption7.Location = new System.Drawing.Point(68, 203);
            this.TbOption7.Name = "TbOption7";
            this.TbOption7.Size = new System.Drawing.Size(61, 20);
            this.TbOption7.TabIndex = 54;
            this.TbOption7.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption7, "Option Index/Rareoption Index");
            // 
            // lblOption7
            // 
            this.lblOption7.AutoSize = true;
            this.lblOption7.Location = new System.Drawing.Point(15, 205);
            this.lblOption7.Name = "lblOption7";
            this.lblOption7.Size = new System.Drawing.Size(47, 13);
            this.lblOption7.TabIndex = 55;
            this.lblOption7.Text = "Option7:";
            // 
            // TbOption6
            // 
            this.TbOption6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption6.Location = new System.Drawing.Point(68, 177);
            this.TbOption6.Name = "TbOption6";
            this.TbOption6.Size = new System.Drawing.Size(61, 20);
            this.TbOption6.TabIndex = 52;
            this.TbOption6.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption6, "Option Index/Rareoption Index");
            // 
            // lblOption6
            // 
            this.lblOption6.AutoSize = true;
            this.lblOption6.Location = new System.Drawing.Point(15, 179);
            this.lblOption6.Name = "lblOption6";
            this.lblOption6.Size = new System.Drawing.Size(47, 13);
            this.lblOption6.TabIndex = 53;
            this.lblOption6.Text = "Option6:";
            // 
            // TbOption5
            // 
            this.TbOption5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption5.Location = new System.Drawing.Point(68, 151);
            this.TbOption5.Name = "TbOption5";
            this.TbOption5.Size = new System.Drawing.Size(61, 20);
            this.TbOption5.TabIndex = 50;
            this.TbOption5.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption5, "Option Index/Rareoption Index");
            // 
            // lblOption5
            // 
            this.lblOption5.AutoSize = true;
            this.lblOption5.Location = new System.Drawing.Point(15, 153);
            this.lblOption5.Name = "lblOption5";
            this.lblOption5.Size = new System.Drawing.Size(47, 13);
            this.lblOption5.TabIndex = 51;
            this.lblOption5.Text = "Option5:";
            // 
            // TbOption4
            // 
            this.TbOption4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption4.Location = new System.Drawing.Point(68, 124);
            this.TbOption4.Name = "TbOption4";
            this.TbOption4.Size = new System.Drawing.Size(61, 20);
            this.TbOption4.TabIndex = 48;
            this.TbOption4.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption4, "Option Index/Rareoption Index");
            // 
            // lblOption4
            // 
            this.lblOption4.AutoSize = true;
            this.lblOption4.Location = new System.Drawing.Point(15, 126);
            this.lblOption4.Name = "lblOption4";
            this.lblOption4.Size = new System.Drawing.Size(47, 13);
            this.lblOption4.TabIndex = 49;
            this.lblOption4.Text = "Option4:";
            // 
            // TbOption3
            // 
            this.TbOption3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption3.Location = new System.Drawing.Point(68, 98);
            this.TbOption3.Name = "TbOption3";
            this.TbOption3.Size = new System.Drawing.Size(61, 20);
            this.TbOption3.TabIndex = 46;
            this.TbOption3.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption3, "Option Index/Rareoption Index");
            // 
            // lblOption3
            // 
            this.lblOption3.AutoSize = true;
            this.lblOption3.Location = new System.Drawing.Point(15, 100);
            this.lblOption3.Name = "lblOption3";
            this.lblOption3.Size = new System.Drawing.Size(47, 13);
            this.lblOption3.TabIndex = 47;
            this.lblOption3.Text = "Option3:";
            // 
            // TbOption2
            // 
            this.TbOption2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption2.Location = new System.Drawing.Point(68, 72);
            this.TbOption2.Name = "TbOption2";
            this.TbOption2.Size = new System.Drawing.Size(61, 20);
            this.TbOption2.TabIndex = 44;
            this.TbOption2.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption2, "Option Index/Rareoption Index");
            // 
            // lblOption2
            // 
            this.lblOption2.AutoSize = true;
            this.lblOption2.Location = new System.Drawing.Point(15, 74);
            this.lblOption2.Name = "lblOption2";
            this.lblOption2.Size = new System.Drawing.Size(47, 13);
            this.lblOption2.TabIndex = 45;
            this.lblOption2.Text = "Option2:";
            // 
            // TbOption1
            // 
            this.TbOption1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption1.Location = new System.Drawing.Point(68, 46);
            this.TbOption1.Name = "TbOption1";
            this.TbOption1.Size = new System.Drawing.Size(61, 20);
            this.TbOption1.TabIndex = 42;
            this.TbOption1.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption1, "Option Index/Rareoption Index");
            // 
            // lblOption1
            // 
            this.lblOption1.AutoSize = true;
            this.lblOption1.Location = new System.Drawing.Point(15, 48);
            this.lblOption1.Name = "lblOption1";
            this.lblOption1.Size = new System.Drawing.Size(47, 13);
            this.lblOption1.TabIndex = 43;
            this.lblOption1.Text = "Option1:";
            // 
            // TbOption0
            // 
            this.TbOption0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbOption0.Location = new System.Drawing.Point(68, 20);
            this.TbOption0.Name = "TbOption0";
            this.TbOption0.Size = new System.Drawing.Size(61, 20);
            this.TbOption0.TabIndex = 40;
            this.TbOption0.Text = "-1";
            this.toolTip1.SetToolTip(this.TbOption0, "Option Index/Rareoption Index");
            // 
            // lblOption0
            // 
            this.lblOption0.AutoSize = true;
            this.lblOption0.Location = new System.Drawing.Point(15, 22);
            this.lblOption0.Name = "lblOption0";
            this.lblOption0.Size = new System.Drawing.Size(47, 13);
            this.lblOption0.TabIndex = 41;
            this.lblOption0.Text = "Option0:";
            // 
            // GbRange
            // 
            this.GbRange.Controls.Add(this.PbSelectID2);
            this.GbRange.Controls.Add(this.PbSelectID1);
            this.GbRange.Controls.Add(this.tbRange2);
            this.GbRange.Controls.Add(this.lblItemRange2);
            this.GbRange.Controls.Add(this.tbRange1);
            this.GbRange.Controls.Add(this.LblitemRange1);
            this.GbRange.Location = new System.Drawing.Point(354, 30);
            this.GbRange.Name = "GbRange";
            this.GbRange.Size = new System.Drawing.Size(138, 282);
            this.GbRange.TabIndex = 2;
            this.GbRange.TabStop = false;
            this.GbRange.Text = "Range";
            // 
            // PbSelectID2
            // 
            this.PbSelectID2.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.PbSelectID2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbSelectID2.Location = new System.Drawing.Point(113, 91);
            this.PbSelectID2.Name = "PbSelectID2";
            this.PbSelectID2.Size = new System.Drawing.Size(22, 22);
            this.PbSelectID2.TabIndex = 104;
            this.PbSelectID2.TabStop = false;
            this.PbSelectID2.Click += new System.EventHandler(this.PbSelectID2_Click);
            // 
            // PbSelectID1
            // 
            this.PbSelectID1.BackgroundImage = global::LcDevPack_TeamDamonA.Properties.Resources.oie_transparent;
            this.PbSelectID1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbSelectID1.Location = new System.Drawing.Point(111, 42);
            this.PbSelectID1.Name = "PbSelectID1";
            this.PbSelectID1.Size = new System.Drawing.Size(22, 22);
            this.PbSelectID1.TabIndex = 103;
            this.PbSelectID1.TabStop = false;
            this.PbSelectID1.Click += new System.EventHandler(this.PbSelectID1_Click);
            // 
            // tbRange2
            // 
            this.tbRange2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRange2.Location = new System.Drawing.Point(9, 93);
            this.tbRange2.Name = "tbRange2";
            this.tbRange2.Size = new System.Drawing.Size(98, 20);
            this.tbRange2.TabIndex = 102;
            this.toolTip1.SetToolTip(this.tbRange2, "End Index");
            // 
            // lblItemRange2
            // 
            this.lblItemRange2.AutoSize = true;
            this.lblItemRange2.Location = new System.Drawing.Point(9, 68);
            this.lblItemRange2.Name = "lblItemRange2";
            this.lblItemRange2.Size = new System.Drawing.Size(88, 13);
            this.lblItemRange2.TabIndex = 101;
            this.lblItemRange2.Text = "Item ID Range 2:";
            // 
            // tbRange1
            // 
            this.tbRange1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRange1.Location = new System.Drawing.Point(9, 43);
            this.tbRange1.Name = "tbRange1";
            this.tbRange1.Size = new System.Drawing.Size(98, 20);
            this.tbRange1.TabIndex = 100;
            this.toolTip1.SetToolTip(this.tbRange1, "Start Index");
            // 
            // LblitemRange1
            // 
            this.LblitemRange1.AutoSize = true;
            this.LblitemRange1.Location = new System.Drawing.Point(9, 23);
            this.LblitemRange1.Name = "LblitemRange1";
            this.LblitemRange1.Size = new System.Drawing.Size(88, 13);
            this.LblitemRange1.TabIndex = 0;
            this.LblitemRange1.Text = "Item ID Range 1:";
            // 
            // btnTips
            // 
            this.btnTips.Location = new System.Drawing.Point(44, 318);
            this.btnTips.Name = "btnTips";
            this.btnTips.Size = new System.Drawing.Size(107, 23);
            this.btnTips.TabIndex = 3;
            this.btnTips.Text = "Tips";
            this.btnTips.UseVisualStyleBackColor = true;
            this.btnTips.Click += new System.EventHandler(this.btnTips_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(180, 318);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(107, 23);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // lblNote1
            // 
            this.lblNote1.AutoSize = true;
            this.lblNote1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblNote1.Location = new System.Drawing.Point(13, 7);
            this.lblNote1.Name = "lblNote1";
            this.lblNote1.Size = new System.Drawing.Size(275, 13);
            this.lblNote1.TabIndex = 5;
            this.lblNote1.Text = "Note: check the range of items for items that dont belong";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(294, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Note2: must fill all boxes out.";
            // 
            // MassEditSeals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 342);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblNote1);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnTips);
            this.Controls.Add(this.GbRange);
            this.Controls.Add(this.gbMassRareOption);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MassEditSeals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "MassEdit Seals";
            this.gbMassRareOption.ResumeLayout(false);
            this.gbMassRareOption.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.GbRange.ResumeLayout(false);
            this.GbRange.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbSelectID2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbSelectID1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbMassRareOption;
        public System.Windows.Forms.PictureBox pictureBox22;
        public System.Windows.Forms.PictureBox pictureBox21;
        public System.Windows.Forms.PictureBox pictureBox20;
        public System.Windows.Forms.PictureBox pictureBox19;
        public System.Windows.Forms.PictureBox pictureBox18;
        public System.Windows.Forms.PictureBox pictureBox17;
        public System.Windows.Forms.PictureBox pictureBox16;
        public System.Windows.Forms.PictureBox pictureBox15;
        public System.Windows.Forms.PictureBox pictureBox14;
        public System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.TextBox TbLevel9;
        private System.Windows.Forms.Label lbllevel9;
        private System.Windows.Forms.TextBox TbLevel8;
        private System.Windows.Forms.Label lbllevel8;
        private System.Windows.Forms.TextBox TbLevel7;
        private System.Windows.Forms.Label lbllevel7;
        private System.Windows.Forms.TextBox TbLevel6;
        private System.Windows.Forms.Label lbllevel6;
        private System.Windows.Forms.TextBox TbLevel5;
        private System.Windows.Forms.Label lbllevel5;
        private System.Windows.Forms.TextBox TbLevel4;
        private System.Windows.Forms.Label lbllevel4;
        private System.Windows.Forms.TextBox TbLevel3;
        private System.Windows.Forms.Label lbllevel3;
        private System.Windows.Forms.TextBox TbLevel2;
        private System.Windows.Forms.Label lbllevel2;
        private System.Windows.Forms.TextBox TbLevel1;
        private System.Windows.Forms.Label lbllevel1;
        private System.Windows.Forms.TextBox TbLevel0;
        private System.Windows.Forms.Label lbllevel0;
        private System.Windows.Forms.TextBox TbOption9;
        private System.Windows.Forms.Label lblOption9;
        private System.Windows.Forms.TextBox TbOption8;
        private System.Windows.Forms.Label lblOption8;
        private System.Windows.Forms.TextBox TbOption7;
        private System.Windows.Forms.Label lblOption7;
        private System.Windows.Forms.TextBox TbOption6;
        private System.Windows.Forms.Label lblOption6;
        private System.Windows.Forms.TextBox TbOption5;
        private System.Windows.Forms.Label lblOption5;
        private System.Windows.Forms.TextBox TbOption4;
        private System.Windows.Forms.Label lblOption4;
        private System.Windows.Forms.TextBox TbOption3;
        private System.Windows.Forms.Label lblOption3;
        private System.Windows.Forms.TextBox TbOption2;
        private System.Windows.Forms.Label lblOption2;
        private System.Windows.Forms.TextBox TbOption1;
        private System.Windows.Forms.Label lblOption1;
        private System.Windows.Forms.TextBox TbOption0;
        private System.Windows.Forms.Label lblOption0;
        private System.Windows.Forms.GroupBox GbRange;
        private System.Windows.Forms.Button btnTips;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox tbRange2;
        private System.Windows.Forms.Label lblItemRange2;
        private System.Windows.Forms.TextBox tbRange1;
        private System.Windows.Forms.Label LblitemRange1;
        private System.Windows.Forms.Label lblNote1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox PbSelectID2;
        private System.Windows.Forms.PictureBox PbSelectID1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}