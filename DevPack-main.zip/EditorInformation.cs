﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.EditorInformation
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public class EditorInformation
    {
        public static string[] Editor_Release = new string[8]
        {
      "MagicEditor",
      "MoonstoneEditor",
      "CatalogEditor",
      "ShopEditor",
      "QuestEditor",
      "OptionEditor",
      "TitleEditor",
      "LuckyDrawBoxTool"
        };
        public static string[] Editor_Beta = new string[3]
        {
      "ItemEditor",
      "SkillEditor",
      "MobEditor"
        };
        public static string[] Editor_Alpha = new string[5]
        {
      "RewardEditor",
      "AffinityEditor",
      "BigPetEditor",
      "ItemCollection",
      "ExChange"//By AssasinPL
        };
    }
}
