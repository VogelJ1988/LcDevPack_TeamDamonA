﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.tTextCoord
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public struct tTextCoord
    {
        public float U;
        public float V;

        public tTextCoord(float U, float V)
        {
            this.U = U;
            this.V = V;
        }
    }
}
