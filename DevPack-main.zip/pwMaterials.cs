﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.pwMaterials
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public class pwMaterials
    {
        public byte isClothing { get; set; }

        public byte[] MatHeader { get; set; }

        public float Scale { get; set; }

        public float[] Values { get; set; }
    }
}
