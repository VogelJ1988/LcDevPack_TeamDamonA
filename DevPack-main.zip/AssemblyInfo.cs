﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LcDevPack_TeamDamonA")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("LcDevPack_TeamDamonA")]
[assembly: AssemblyCopyright("Copyright ©  2015")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("47bedff8-7cdb-45ab-8931-924848e91ae9")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
