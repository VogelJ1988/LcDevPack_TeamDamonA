﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.CustomVertex
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

using SlimDX;

namespace LcDevPack_TeamDamonA
{
    internal class CustomVertex
    {
        public struct PositionNormalTextured
        {
            public Vector3 Position;
            public Vector3 Normal;
            public Vector2 Texture;
        }
    }
}
