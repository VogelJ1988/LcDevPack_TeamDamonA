﻿// Decompiled with JetBrains decompiler
// Type: LcDevPack_TeamDamonA.SkillIcon
// Assembly: LcDevPack_TeamDamonA, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B9BC8BF-B510-4945-A515-04135CC0F4A4
// Assembly location: C:\Users\NTServer\Desktop\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA\LcDevPack_TeamDamonA.exe

namespace LcDevPack_TeamDamonA
{
    public class SkillIcon
    {
        public int SkillID;
        public int FileID;
        public int Row;
        public int Col;
        public string Name;
        public string Desc;
        public string Tooltip;
    }
}
