﻿namespace LcDevPack_TeamDamonA
{
    internal class cAnimHeader
    {
        public int AnimCount { get; set; }

        public int Version { get; set; }
    }
}
